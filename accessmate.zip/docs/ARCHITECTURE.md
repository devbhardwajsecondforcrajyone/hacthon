# ACCESSMATE System Architecture & API Documentation

## 1. Architectural Overview

ACCESSMATE uses a modular Next.js 15 App Router full-stack architecture that strictly separates UI presentation, session state, pure domain logic, document extraction, and server-side AI / Workspace proxies.

```
app/
  layout.tsx                  Root layout, accessible fonts (Plus Jakarta Sans, Public Sans, JetBrains Mono), skip link
  globals.css                 Tailwind v4 + @custom-variant dark + 4 accessible theme token sets
  page.tsx                    Single-page workspace router across all 7 navigation sections
  api/
    extract/route.ts          Server-side upload validation (MIME + magic bytes) & PDF/DOCX/TXT/Image extraction
    analyze/route.ts          Gemini structured document analysis with Zod validation & grounding check
    translate/route.ts        13-language translation with RTL metadata & Zod validation
    qa/route.ts               Document-grounded Q&A + optional separated Google Search grounding
    tts/route.ts              Gemini 3.8 Flash Lite TTS returning WAV audio
    transcribe/route.ts       Gemini 3.5 Transcribe for optional spoken command fallback
    workspace/calendar/       Confirmation-gated Google Calendar event creation proxy
    workspace/tasks/          Confirmation-gated Google Tasks checklist export proxy

lib/
  config.ts                   Centralized limits, model IDs, rate limits, 13 languages
  types.ts                    Strict TypeScript interfaces & Zod schemas
  document/
    validation.ts             Filename sanitizer, magic-byte verifier, prompt-injection & scanned-PDF detector
    chunking.ts               Page-preserving smart chunker, content hash, verbatim excerpt verifier
    extraction.ts             PDF (unpdf), DOCX (mammoth), TXT, and pasted-text extractors
    evaluation.ts             Synthetic ground-truth corpus & deterministic AI Accuracy Evaluation Engine
  accessibility/
    preferences.ts            Pure accessibility preference reducer & storage parser
  server/
    gemini.ts                 Server-only @google/genai client, prompt-injection isolation, retry/timeout
    rate-limit.ts             In-memory sliding-window rate limiter
    logger.ts                 Privacy-safe redacting structured logger
  workspace/
    firebase-auth.ts          Client-side Firebase Auth with strictly in-memory OAuth token cache
    keep-export.ts            Structured Google Keep note formatter

contexts/
  AccessibilityContext.tsx    Live root CSS variable & theme class synchronization
  DocumentSessionContext.tsx  Session-only document state, in-memory caches, AbortController cancellation

components/                   Focused UI modules organized by domain (layout, upload, dashboard, document, checklist, accessibility, evaluation, about, workspace)
tests/                        Node built-in test runner suites executed via tsx
```

## 2. Security Boundaries & Data Lifecycle

1. **API Credential Isolation**: `process.env.GEMINI_API_KEY` is accessed exclusively in `lib/server/gemini.ts`. No `NEXT_PUBLIC_` secret variables exist, and no API key inputs appear in the UI.
2. **Untrusted File & Text Handling**:
   - Every upload is validated server-side for extension allowlist, MIME type, byte length (max 8 MB), PDF page count (max 30 pages), and binary magic bytes (`%PDF-`, `PK\x03\x04`, PNG/JPEG/WebP headers, non-binary UTF-8 check for TXT).
   - Document text sent to Gemini is wrapped in per-request cryptographically random XML boundary tags (`<UNTRUSTED_DOCUMENT_<nonce>>`) with explicit system instructions forbidding instruction overrides, secret disclosure, or script output.
3. **Structured Output Validation**: All JSON responses from Gemini are validated against Zod schemas (`DocumentAnalysisSchema`, `TranslatedContentSchema`, `QAResponseSchema`) before being returned to the client.
4. **Zero-Persistence Privacy Model**: Uploaded buffers and extracted text exist solely in volatile memory during the user's active session. No document database or disk writes are performed. Clicking **Delete Document** immediately aborts in-flight requests, stops speech synthesis, and purges all cached analyses, translations, checklist progress, and Q&A history.
5. **Workspace Least-Privilege & User Confirmation**: Client-side Firebase Auth requests only `calendar.events` and `tasks` scopes, caches the access token strictly in JS memory, and requires an explicit confirmation modal listing exact event/task details before any Workspace write occurs.

## 3. Efficiency & Resource Management

- **In-Session Caching**: Analyses are cached in memory by `(contentHash, readingLevel, reasoningDepth)` and translations by `(contentHash, readingLevel, targetLanguageCode)` to eliminate duplicate Gemini calls when toggling tabs or revisiting reading levels.
- **Controlled Page-Preserving Chunking**: Long documents are bounded (`120,000` chars) and split into page-annotated chunks (`[Page N]`, up to 8 chunks of 14,000 chars) so page citations remain intact.
- **Request Cancellation & Timeouts**: Client requests use `AbortController` to cancel obsolete operations when users click Cancel, switch documents, or clear the session; server calls enforce a 45-second timeout with safe retry on transient errors.
