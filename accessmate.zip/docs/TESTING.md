# ACCESSMATE Testing & Verification Strategy

## 1. Automated Test Suites (`node:test` via `tsx`)

Run all automated suites with:

```bash
npx --yes tsx --test tests/validation.test.ts tests/chunking-and-eval.test.ts tests/accessibility-and-security.test.ts tests/api-integration.test.ts
```

### Suite Coverage

1. **`tests/validation.test.ts` (Unit & Security)**
   - Malicious filename sanitization (path traversal `../../`, Windows paths, `<script>` tags).
   - Magic-byte binary signature validation for PDF, DOCX, TXT, PNG, JPEG, WebP.
   - Rejection of spoofed PDF files containing HTML/XSS, binary files disguised as TXT, unsupported `.exe` extensions, empty files, and oversized (> 8 MB) files.
   - Prompt-injection signal detection (instruction override, API key exfiltration, embedded `<script>`).
   - Document quality warning generation (scanned PDF detection, truncation warning, injection warning).
   - URL scheme validation blocking `javascript:` and `data:` URLs.

2. **`tests/chunking-and-eval.test.ts` (Efficiency, Grounding & AI Evaluation)**
   - Controlled multi-page chunking preserving `[Page N]` markers and respecting chunk limits.
   - Deterministic token estimation, word counts, and content fingerprinting.
   - Verbatim and normalized excerpt grounding checks vs. fabricated excerpts.
   - Strict Zod rejection of malformed JSON and incomplete AI responses.
   - Deterministic verification of the **AI Accuracy Evaluation Engine** against synthetic ground-truth documents, confirming it passes grounded outputs and catches injected fake deadlines (`$999` / `attacker@evil.example`) and hallucinated dates.

3. **`tests/accessibility-and-security.test.ts` (Accessibility, Rate Limiting & Privacy)**
   - Accessibility preference reducer across all 4 theme modes, font scale clamping (`0.85`–`1.45`), line/letter spacing, reduced motion, privacy mode, reset, and corrupted `localStorage` recovery.
   - Sliding-window rate limiter enforcement (HTTP 429 + `Retry-After`) and window expiry recovery.
   - Privacy-safe server logger redaction of API keys (`AIza...`), Bearer tokens, document text, and email addresses.
   - Document extraction pipeline for pasted text and UTF-8 TXT buffers, including empty-document error handling.
   - Google Keep formatted note export generation.

4. **`tests/api-integration.test.ts` (Server-Side API Integration)**
   - Invokes Next.js Route Handlers directly (`POST /api/extract`, `/api/analyze`, `/api/translate`, `/api/qa`, `/api/workspace/calendar`, `/api/workspace/tasks`).
   - Verifies happy-path extraction, empty-input rejection (400), spoofed-PDF signature rejection (400), short-document analysis rejection (400), unsupported-language rejection (400), short-question rejection (400), and unauthenticated Workspace request rejection (401).

## 2. Live AI Evaluation Engine (In-App)

The **Verification & Quality** section lets evaluators run live Gemini analyses against 4 synthetic ground-truth documents:
- National Merit Scholarship Renewal Notice (publication date vs. real deadlines, required documents, monetary conditions).
- Hospital Outpatient Diagnostic Procedure Notice (fasting rules, medication warnings, appointment checks).
- Municipal Tenant Inspection Notice (ambiguous relative dates and omitted phone number).
- Adversarial Prompt-Injection Security Test Notice (embedded jailbreak + fake `$999` payment + `<script>` payload).

## 3. Real Browser E2E & Accessibility Verification

Browser verification is performed in headless Chromium (`playwright-cli`) against `http://localhost:3000`:
- Desktop (`1440x900`) and Mobile (`390x844`) layout inspection.
- Complete user journey: Dashboard → Paste/Sample Document → Live Gemini Analysis → Overview → Original vs. Simple Comparison → Source Evidence Verification → Translation (including Arabic RTL) → Deadlines → Action Checklist → Listen → Accessibility Theme & Font Scaling → Delete Document & Clear Session.
- Accessibility tree inspection (roles, labels, tab panels, switches, keyboard focus, contrast across Light, Midnight Navy Dark, Comfortable Reading, and High Contrast).
