'use client';

import React from 'react';
import { ArrowRight, ShieldCheck } from 'lucide-react';
import { APP_CONFIG } from '@/lib/config';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';

const PROBLEM_SOLUTION_ROWS = [
  {
    problem: 'Complicated official or technical documents',
    solution: 'Simple, Standard, and Detailed reading levels plus side-by-side Original vs. Simplified comparison',
  },
  {
    problem: 'Language barriers across communities',
    solution: 'Multilingual translation into 13 languages (including Arabic RTL) while preserving dates and numbers',
  },
  {
    problem: 'Difficulty reading dense or long text',
    solution: 'Accessible Text-to-Speech reader with speed, voice selection, section highlights, and optional Neural Audio',
  },
  {
    problem: 'Missing critical deadlines or dates',
    solution: 'Structured deadline extraction separating publication dates from due dates, with ambiguity warnings and optional Calendar sync',
  },
  {
    problem: 'Confusing multi-step instructions',
    solution: 'Traceable Document-to-Action checklist with source excerpts, print/copy, Google Tasks sync, and Keep note export',
  },
  {
    problem: 'Visual accessibility barriers',
    solution: 'Live Accessibility Control Center: font scaling (85%–145%), spacing, Light, Midnight Navy, Comfortable Reading, and High Contrast',
  },
  {
    problem: 'Keyboard and screen-reader barriers',
    solution: 'WCAG 2.2 AA semantic HTML, skip-to-content link, unmistakable focus indicators, ARIA live regions, and optional voice input',
  },
];

const JOURNEY_STEPS = [
  'Open ACCESSMATE and review privacy transparency.',
  'Upload a PDF, DOCX, TXT, or document photo — or paste text directly.',
  'Server validates file signature, MIME type, size, and extracts readable text.',
  'Gemini analyzes untrusted document data with prompt-injection boundaries.',
  'Read the plain-language summary at Simple, Standard, or Detailed depth.',
  'Verify every claim against verbatim quotes in the Source Evidence panel.',
  'Choose from 13 languages (including right-to-left Arabic) to translate outputs.',
  'Review extracted deadlines and verify any ambiguous dates.',
  'Follow your traceable Action Checklist and optionally export to Google Tasks or Calendar.',
  'Listen aloud using accessible Text-to-Speech controls.',
  'Tune contrast, text size, spacing, and reduced motion in Accessibility Settings.',
  'Click Delete Document to wipe temporary session data immediately.',
];

export function AboutAccessmateView() {
  const { setActiveNav } = useDocumentSession();

  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6 sm:p-8">
        <p className="text-sm font-semibold text-[var(--am-accent)]">Why ACCESSMATE Exists</p>
        <h1 className="mt-2 text-2xl font-bold text-[var(--am-text)] sm:text-3xl">
          {APP_CONFIG.tagline}
        </h1>
        <p className="mt-3 max-w-3xl text-sm text-[var(--am-text-secondary)]">
          Millions of people struggle to understand notices, scholarship renewals, healthcare letters, application forms, and public-service documents because of language barriers, dense terminology, and inaccessible formats. ACCESSMATE closes the gap between receiving important information and knowing exactly what to do next.
        </p>
        <div className="mt-5">
          <button
            type="button"
            onClick={() => setActiveNav('dashboard')}
            className="inline-flex min-h-[42px] items-center gap-2 rounded-lg bg-[var(--am-accent)] px-5 py-2 text-sm font-semibold text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)]"
          >
            <span>Try ACCESSMATE Now</span>
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </section>

      {/* Problem-to-Solution Alignment Table */}
      <section className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6">
        <h2 className="text-lg font-semibold text-[var(--am-text)]">
          Direct Problem Statement Alignment
        </h2>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full border-collapse text-left text-sm">
            <thead>
              <tr className="border-b border-[var(--am-border)] text-xs text-[var(--am-text-muted)]">
                <th className="py-2.5 pr-4 font-semibold">Real-World Barrier</th>
                <th className="py-2.5 font-semibold">ACCESSMATE Solution</th>
              </tr>
            </thead>
            <tbody>
              {PROBLEM_SOLUTION_ROWS.map((row, idx) => (
                <tr key={idx} className="border-b border-[var(--am-border)] last:border-b-0">
                  <td className="py-3 pr-4 font-medium text-[var(--am-text)]">{row.problem}</td>
                  <td className="py-3 text-[var(--am-text-secondary)]">{row.solution}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* 12-Step Complete User Journey */}
      <section className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6">
        <h2 className="text-lg font-semibold text-[var(--am-text)]">
          Complete 12-Step Document-to-Action Journey
        </h2>
        <ol className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {JOURNEY_STEPS.map((step, idx) => (
            <li
              key={idx}
              className="rounded-lg border border-[var(--am-border)] bg-[var(--am-surface-muted)] p-3.5 text-xs text-[var(--am-text-secondary)]"
            >
              <span className="font-mono-tabular font-semibold text-[var(--am-accent)]">
                {String(idx + 1).padStart(2, '0')}.
              </span>{' '}
              <span className="text-[var(--am-text)]">{step}</span>
            </li>
          ))}
        </ol>
      </section>

      {/* Security & Privacy Transparency */}
      <section className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-[var(--am-accent)]" aria-hidden="true" />
          <h2 className="text-lg font-semibold text-[var(--am-text)]">
            Security & Privacy Architecture
          </h2>
        </div>
        <ul className="mt-3 space-y-2 text-sm text-[var(--am-text-secondary)]">
          <li>
            • <strong className="text-[var(--am-text)]">Server-Side API Credentials:</strong> Gemini API keys are read strictly on the server via environment variables and never exposed to browser code.
          </li>
          <li>
            • <strong className="text-[var(--am-text)]">Binary File Validation:</strong> Uploaded files are verified server-side for extension, MIME type, size limit (8 MB), page limit (30 pages), and magic-byte file signature.
          </li>
          <li>
            • <strong className="text-[var(--am-text)]">Prompt-Injection Isolation:</strong> Document text is wrapped in per-request randomized boundary tags and treated strictly as untrusted data; AI responses are validated via Zod schemas before rendering.
          </li>
          <li>
            • <strong className="text-[var(--am-text)]">Honest Privacy Model:</strong> Extracted text is sent to the configured Gemini AI API during analysis and translation. ACCESSMATE itself stores zero documents in any database or disk and provides one-click Delete Document & Clear Session.
          </li>
        </ul>
      </section>
    </div>
  );
}
