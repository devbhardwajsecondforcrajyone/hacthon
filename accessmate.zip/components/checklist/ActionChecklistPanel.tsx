'use client';

import React, { useState } from 'react';
import {
  Check,
  CheckSquare,
  Copy,
  ListTodo,
  Printer,
  RotateCcw,
  StickyNote,
} from 'lucide-react';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';
import { formatDocumentForGoogleKeep } from '@/lib/workspace/keep-export';
import { GoogleSignInButton } from '@/components/workspace/GoogleSignInButton';
import { WorkspaceConfirmModal } from '@/components/workspace/WorkspaceConfirmModal';

export function ActionChecklistPanel() {
  const {
    document,
    analysis,
    completedChecklistIds,
    toggleChecklistItem,
    resetChecklist,
    setActiveNav,
    announce,
    workspaceUser,
    workspaceToken,
    isSigningInWorkspace,
    connectGoogleWorkspace,
  } = useDocumentSession();

  const [copiedType, setCopiedType] = useState<'checklist' | 'keep' | null>(null);
  const [tasksModalOpen, setTasksModalOpen] = useState(false);
  const [exportingTasks, setExportingTasks] = useState(false);
  const [tasksFeedback, setTasksFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  if (!document || !analysis) {
    return (
      <section className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-8 text-center">
        <CheckSquare className="mx-auto h-8 w-8 text-[var(--am-accent)]" aria-hidden="true" />
        <h2 className="mt-3 text-lg font-semibold text-[var(--am-text)]">
          No Action Checklist Yet
        </h2>
        <p className="mt-1 text-sm text-[var(--am-text-muted)]">
          Upload or paste a document first. ACCESSMATE converts explicit requirements and deadlines into a traceable step-by-step checklist.
        </p>
        <button
          type="button"
          onClick={() => setActiveNav('dashboard')}
          className="mt-4 min-h-[42px] rounded-lg bg-[var(--am-accent)] px-5 py-2 text-sm font-semibold text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)]"
        >
          Go to Upload Dashboard
        </button>
      </section>
    );
  }

  const totalCount = analysis.actionChecklist.length;
  const doneCount = analysis.actionChecklist.filter((i) =>
    completedChecklistIds.has(i.id)
  ).length;
  const remainingCount = Math.max(0, totalCount - doneCount);
  const progressPct = totalCount > 0 ? Math.round((doneCount / totalCount) * 100) : 0;

  const handleCopyChecklist = async () => {
    const lines = analysis.actionChecklist.map((item) => {
      const box = completedChecklistIds.has(item.id) ? '[x]' : '[ ]';
      const due = item.dueDate ? ` (Due: ${item.dueDate})` : '';
      const page = item.pageNumber ? ` [Page ${item.pageNumber}]` : '';
      return `${box} ${item.title}${due}${page}\n    ${item.explanation}`;
    });
    const text = `ACCESSMATE Action Checklist — ${document.fileName}\n\n${lines.join('\n\n')}`;
    try {
      await navigator.clipboard.writeText(text);
      setCopiedType('checklist');
      announce('Action checklist copied to clipboard.');
      window.setTimeout(() => setCopiedType(null), 2500);
    } catch {
      announce('Unable to access clipboard in this browser context.');
    }
  };

  const handleCopyForKeep = async () => {
    const keepNote = formatDocumentForGoogleKeep(
      document.fileName,
      analysis,
      completedChecklistIds
    );
    const fullNote = `${keepNote.title}\n\n${keepNote.body}`;
    try {
      await navigator.clipboard.writeText(fullNote);
      setCopiedType('keep');
      announce('Formatted Google Keep note copied to clipboard.');
      window.setTimeout(() => setCopiedType(null), 3000);
    } catch {
      announce('Unable to access clipboard.');
    }
  };

  const handleConfirmExportTasks = async () => {
    const uncompleted = analysis.actionChecklist.filter(
      (item) => !completedChecklistIds.has(item.id)
    );
    const toExport = uncompleted.length > 0 ? uncompleted : analysis.actionChecklist;
    if (toExport.length === 0) return;

    setExportingTasks(true);
    setTasksFeedback(null);

    try {
      const token = workspaceToken || (await connectGoogleWorkspace());
      if (!token) {
        setTasksFeedback({
          type: 'error',
          message: 'Sign in with Google first to export your checklist to Google Tasks.',
        });
        setExportingTasks(false);
        return;
      }

      const itemsPayload = toExport.map((item) => ({
        title: item.title,
        notes: `${item.explanation}\nSource (${document.fileName}${item.pageNumber ? `, Page ${item.pageNumber}` : ''}): "${item.sourceExcerpt}"`,
        dueDate:
          item.dueDate && /^\d{4}-\d{2}-\d{2}$/.test(item.dueDate)
            ? item.dueDate
            : null,
      }));

      const res = await fetch('/api/workspace/tasks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ items: itemsPayload }),
      });

      const payload = (await res.json().catch(() => ({}))) as {
        createdCount?: number;
        error?: string;
      };

      if (!res.ok) {
        throw new Error(payload.error || 'Failed to export tasks to Google Tasks.');
      }

      setTasksFeedback({
        type: 'success',
        message: `Exported ${payload.createdCount ?? toExport.length} action item(s) to your default Google Tasks list.`,
      });
      announce(`Exported ${payload.createdCount ?? toExport.length} tasks to Google Tasks.`);
      setTasksModalOpen(false);
    } catch (error) {
      setTasksFeedback({
        type: 'error',
        message: error instanceof Error ? error.message : 'Google Tasks export failed.',
      });
    } finally {
      setExportingTasks(false);
    }
  };

  return (
    <section aria-labelledby="checklist-heading" className="space-y-6">
      {/* Header & Progress */}
      <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 id="checklist-heading" className="text-lg font-semibold text-[var(--am-text)]">
              Document-to-Action Checklist
            </h2>
            <p className="mt-1 text-sm text-[var(--am-text-muted)]">
              Every task below is traced directly to explicit instructions in {document.fileName}.
            </p>
          </div>
          <div className="text-right">
            <div className="font-mono-tabular text-2xl font-bold text-[var(--am-text)]">
              {doneCount}/{totalCount}
            </div>
            <div className="text-xs text-[var(--am-text-muted)]">
              {remainingCount} task{remainingCount === 1 ? '' : 's'} remaining
            </div>
          </div>
        </div>

        {/* Accessible Progress Bar */}
        <div className="mt-4">
          <div
            role="progressbar"
            aria-label="Checklist completion progress"
            aria-valuenow={progressPct}
            aria-valuemin={0}
            aria-valuemax={100}
            className="h-2.5 w-full overflow-hidden rounded-full bg-[var(--am-surface-muted)]"
          >
            <div
              className="h-full bg-[var(--am-accent)] transition-all"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>

        {/* Action Toolbar */}
        <div className="no-print mt-5 flex flex-wrap items-center gap-2.5 border-t border-[var(--am-border)] pt-4">
          <button
            type="button"
            onClick={handleCopyChecklist}
            disabled={totalCount === 0}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3.5 py-2 text-xs font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap disabled:opacity-50"
          >
            {copiedType === 'checklist' ? (
              <Check className="h-4 w-4 text-[var(--am-success)]" aria-hidden="true" />
            ) : (
              <Copy className="h-4 w-4" aria-hidden="true" />
            )}
            <span>{copiedType === 'checklist' ? 'Copied Checklist' : 'Copy Checklist'}</span>
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            disabled={totalCount === 0}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3.5 py-2 text-xs font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap disabled:opacity-50"
          >
            <Printer className="h-4 w-4" aria-hidden="true" />
            <span>Print Checklist</span>
          </button>

          <button
            type="button"
            onClick={resetChecklist}
            disabled={doneCount === 0}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3.5 py-2 text-xs font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap disabled:opacity-50"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" />
            <span>Reset Progress</span>
          </button>

          <button
            type="button"
            onClick={() => setTasksModalOpen(true)}
            disabled={totalCount === 0}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-lg bg-[var(--am-accent)] px-4 py-2 text-xs font-semibold text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)] whitespace-nowrap disabled:opacity-50"
          >
            <ListTodo className="h-4 w-4" aria-hidden="true" />
            <span>Export to Google Tasks</span>
          </button>

          <button
            type="button"
            onClick={handleCopyForKeep}
            disabled={totalCount === 0}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3.5 py-2 text-xs font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap disabled:opacity-50"
          >
            <StickyNote className="h-4 w-4 text-[var(--am-accent)]" aria-hidden="true" />
            <span>
              {copiedType === 'keep' ? 'Copied for Google Keep' : 'Copy Note for Google Keep'}
            </span>
          </button>
        </div>

        {/* Google Workspace Connection + Keep API Transparency */}
        <div className="no-print mt-4 flex flex-wrap items-center justify-between gap-3 rounded-lg bg-[var(--am-surface-muted)] px-4 py-3 text-xs text-[var(--am-text-secondary)]">
          <p className="max-w-2xl">
            <strong className="text-[var(--am-text)]">Google Tasks & Keep:</strong>{' '}
            Direct export to Google Tasks is enabled with your confirmation. Because the Google Keep REST API is limited by Google to enterprise domain-wide delegation accounts, use &ldquo;Copy Note for Google Keep&rdquo; to paste your formatted checklist directly into Keep.
          </p>
          {!workspaceUser || !workspaceToken ? (
            <GoogleSignInButton
              onClick={() => void connectGoogleWorkspace()}
              disabled={isSigningInWorkspace}
              label={isSigningInWorkspace ? 'Connecting...' : 'Sign in with Google'}
            />
          ) : (
            <span className="font-medium text-[var(--am-success)]">
              Connected: {workspaceUser.email}
            </span>
          )}
        </div>
      </div>

      {tasksFeedback && (
        <div
          role={tasksFeedback.type === 'error' ? 'alert' : 'status'}
          className={`rounded-lg border p-4 text-sm ${
            tasksFeedback.type === 'success'
              ? 'border-[var(--am-success)] bg-[var(--am-success-bg)] text-[var(--am-text)]'
              : 'border-[var(--am-danger)] bg-[var(--am-danger-bg)] text-[var(--am-danger)]'
          }`}
        >
          {tasksFeedback.message}
        </div>
      )}

      {/* Checklist Items */}
      {totalCount === 0 ? (
        <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6 text-sm text-[var(--am-text-muted)]">
          No explicit action tasks were required by this document.
        </div>
      ) : (
        <ul className="space-y-3">
          {analysis.actionChecklist.map((item) => {
            const checked = completedChecklistIds.has(item.id);
            return (
              <li
                key={item.id}
                className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5"
              >
                <div className="flex items-start gap-3.5">
                  <input
                    id={`task-${item.id}`}
                    type="checkbox"
                    checked={checked}
                    onChange={() => toggleChecklistItem(item.id)}
                    className="mt-1 h-5 w-5 shrink-0 cursor-pointer accent-[var(--am-accent)]"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <label
                        htmlFor={`task-${item.id}`}
                        className={`cursor-pointer text-base font-semibold ${
                          checked
                            ? 'line-through text-[var(--am-text-muted)]'
                            : 'text-[var(--am-text)]'
                        }`}
                      >
                        {item.title}
                      </label>
                      <span className="font-mono-tabular text-xs text-[var(--am-text-muted)]">
                        Priority: {item.priority}
                        {item.dueDate ? ` · Due ${item.dueDate}` : ''}
                        {item.pageNumber ? ` · Page ${item.pageNumber}` : ''}
                      </span>
                    </div>

                    <p className="mt-1.5 text-sm text-[var(--am-text-secondary)]">
                      {item.explanation}
                    </p>

                    {item.requiredDocuments.length > 0 && (
                      <p className="mt-2 text-xs text-[var(--am-text-secondary)]">
                        <strong className="text-[var(--am-text)]">Required items:</strong>{' '}
                        {item.requiredDocuments.join(', ')}
                      </p>
                    )}

                    <blockquote className="mt-2.5 rounded-lg bg-[var(--am-surface-muted)] px-3.5 py-2 text-xs text-[var(--am-text-secondary)]">
                      Source excerpt: &ldquo;{item.sourceExcerpt}&rdquo;
                    </blockquote>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      {/* Explicit Confirmation Modal before creating Google Tasks */}
      <WorkspaceConfirmModal
        open={tasksModalOpen}
        title="Confirm Export to Google Tasks"
        description="ACCESSMATE will add the following action items to your default Google Tasks list. Confirm before proceeding."
        items={analysis.actionChecklist
          .filter((i) => !completedChecklistIds.has(i.id) || remainingCount === 0)
          .map((i) => `${i.title}${i.dueDate ? ` (Due: ${i.dueDate})` : ''}`)}
        confirmLabel="Confirm & Export Tasks"
        busy={exportingTasks}
        onConfirm={handleConfirmExportTasks}
        onCancel={() => setTasksModalOpen(false)}
      />
    </section>
  );
}
