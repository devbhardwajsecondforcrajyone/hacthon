'use client';

import React, { useRef, useState } from 'react';
import {
  AlertCircle,
  ClipboardPaste,
  FileImage,
  FileText,
  FileUp,
  Loader2,
  ShieldCheck,
  X,
} from 'lucide-react';
import { APP_CONFIG, READING_LEVELS } from '@/lib/config';
import { SYNTHETIC_GROUND_TRUTH_DOCUMENTS } from '@/lib/document/evaluation';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';

export function DocumentUploader() {
  const {
    readingLevel,
    switchReadingLevel,
    deepReasoning,
    setDeepReasoning,
    status,
    errorMessage,
    clearError,
    processUploadedFile,
    processPastedText,
    cancelActiveRequest,
  } = useDocumentSession();

  const [mode, setMode] = useState<'upload' | 'paste'>('upload');
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [localError, setLocalError] = useState<string | null>(null);

  const [pasteTitle, setPasteTitle] = useState('');
  const [pasteText, setPasteText] = useState('');

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const isBusy = status.phase !== 'idle';

  const handleFileSelection = (file: File | null) => {
    setLocalError(null);
    clearError();
    if (!file) {
      setSelectedFile(null);
      return;
    }

    if (file.size === 0) {
      setLocalError('The selected file is empty. Choose a readable document or paste text.');
      return;
    }

    if (file.size > APP_CONFIG.limits.maxFileSizeBytes) {
      const maxMb = Math.round(APP_CONFIG.limits.maxFileSizeBytes / (1024 * 1024));
      setLocalError(`File exceeds the ${maxMb} MB limit. Choose a smaller document or paste text.`);
      return;
    }

    const lowerName = file.name.toLowerCase();
    const hasAllowedExt = APP_CONFIG.allowedExtensions.some((ext) => lowerName.endsWith(ext));
    if (!hasAllowedExt) {
      setLocalError(
        'Unsupported file format. Upload a PDF, TXT, DOCX, or document photo (PNG, JPG, WebP).'
      );
      return;
    }

    setSelectedFile(file);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (isBusy) return;
    const dropped = e.dataTransfer.files?.[0] ?? null;
    handleFileSelection(dropped);
  };

  const handleStartUploadAnalysis = async () => {
    if (!selectedFile) {
      setLocalError('Choose a PDF, TXT, DOCX, or document image first.');
      return;
    }
    setLocalError(null);
    await processUploadedFile(selectedFile);
  };

  const handleStartPasteAnalysis = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    if (pasteText.trim().length < APP_CONFIG.limits.minMeaningfulCharacters) {
      setLocalError(
        `Please paste at least ${APP_CONFIG.limits.minMeaningfulCharacters} characters of document text so ACCESSMATE can analyze it accurately.`
      );
      return;
    }
    await processPastedText(pasteText, pasteTitle || 'Pasted Document');
  };

  const handleLoadSample = (sampleId: string) => {
    const sample = SYNTHETIC_GROUND_TRUTH_DOCUMENTS.find((d) => d.id === sampleId);
    if (!sample) return;
    setLocalError(null);
    clearError();
    setMode('paste');
    setPasteTitle(sample.title);
    setPasteText(sample.text);
  };

  const activeError = localError || errorMessage;

  return (
    <section
      aria-labelledby="upload-section-heading"
      className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6"
    >
      <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[var(--am-border)] pb-5">
        <div>
          <h2 id="upload-section-heading" className="text-xl font-semibold text-[var(--am-text)]">
            Start Understanding a Document
          </h2>
          <p className="mt-1 text-sm text-[var(--am-text-muted)]">
            Upload a PDF, DOCX, TXT file, or photo of a paper notice — or paste text directly.
          </p>
        </div>

        {/* Mode Segmented Control */}
        <div
          role="tablist"
          aria-label="Document input method"
          className="inline-flex rounded-lg border border-[var(--am-border)] bg-[var(--am-surface-muted)] p-1"
        >
          <button
            type="button"
            role="tab"
            id="tab-upload-file"
            aria-selected={mode === 'upload'}
            aria-controls="panel-upload-file"
            onClick={() => {
              setMode('upload');
              setLocalError(null);
            }}
            className={`inline-flex min-h-[38px] items-center gap-2 rounded-md px-3.5 py-1.5 text-sm font-medium transition-colors whitespace-nowrap ${
              mode === 'upload'
                ? 'bg-[var(--am-surface)] text-[var(--am-text)] font-semibold'
                : 'text-[var(--am-text-muted)] hover:text-[var(--am-text)]'
            }`}
          >
            <FileUp className="h-4 w-4 shrink-0" aria-hidden="true" />
            <span>Upload File</span>
          </button>
          <button
            type="button"
            role="tab"
            id="tab-paste-text"
            aria-selected={mode === 'paste'}
            aria-controls="panel-paste-text"
            onClick={() => {
              setMode('paste');
              setLocalError(null);
            }}
            className={`inline-flex min-h-[38px] items-center gap-2 rounded-md px-3.5 py-1.5 text-sm font-medium transition-colors whitespace-nowrap ${
              mode === 'paste'
                ? 'bg-[var(--am-surface)] text-[var(--am-text)] font-semibold'
                : 'text-[var(--am-text-muted)] hover:text-[var(--am-text)]'
            }`}
          >
            <ClipboardPaste className="h-4 w-4 shrink-0" aria-hidden="true" />
            <span>Paste Text</span>
          </button>
        </div>
      </div>

      {/* Analysis Preferences Row: Reading Level + Deep Reasoning */}
      <div className="mt-5 grid items-stretch gap-4 md:grid-cols-12">
        <fieldset className="flex flex-col md:col-span-8">
          <legend className="text-xs font-semibold text-[var(--am-text-secondary)]">
            Preferred Reading Level
          </legend>
          <div className="mt-2 grid flex-1 grid-cols-3 gap-2">
            {READING_LEVELS.map((lvl) => {
              const selected = readingLevel === lvl.id;
              return (
                <button
                  key={lvl.id}
                  type="button"
                  disabled={isBusy}
                  onClick={() => switchReadingLevel(lvl.id)}
                  aria-pressed={selected}
                  className={`flex min-h-[48px] items-center justify-center rounded-lg border px-3 py-2 text-center transition-colors ${
                    selected
                      ? 'border-[var(--am-accent)] bg-[var(--am-accent-soft)] text-[var(--am-accent)]'
                      : 'border-[var(--am-border)] bg-[var(--am-surface)] text-[var(--am-text)] hover:bg-[var(--am-surface-muted)]'
                  }`}
                >
                  <span className="text-sm font-semibold">{lvl.label}</span>
                </button>
              );
            })}
          </div>
        </fieldset>

        <div className="md:col-span-4 flex flex-col justify-end">
          <label className="flex min-h-[48px] cursor-pointer items-center justify-between gap-3 rounded-lg border border-[var(--am-border)] bg-[var(--am-surface-muted)] px-3.5 py-2">
            <div>
              <span className="block text-sm font-medium text-[var(--am-text)]">
                Deep Reasoning Mode
              </span>
              <span className="block text-xs text-[var(--am-text-muted)]">
                Gemini 4 reasoning for dense legal/policy clauses
              </span>
            </div>
            <input
              type="checkbox"
              checked={deepReasoning}
              disabled={isBusy}
              onChange={(e) => setDeepReasoning(e.target.checked)}
              className="h-5 w-5 accent-[var(--am-accent)]"
            />
          </label>
        </div>
      </div>

      {/* Error Announcement */}
      {activeError && (
        <div
          role="alert"
          className="mt-5 flex items-start justify-between gap-3 rounded-lg border border-[var(--am-danger)] bg-[var(--am-danger-bg)] p-4 text-sm text-[var(--am-danger)]"
        >
          <div className="flex items-start gap-2.5">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
            <div>
              <p className="font-semibold">Unable to process input</p>
              <p className="mt-0.5">{activeError}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              setLocalError(null);
              clearError();
            }}
            aria-label="Dismiss error message"
            className="rounded p-1 hover:opacity-80"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      )}

      {/* Upload File Panel */}
      {mode === 'upload' && (
        <div id="panel-upload-file" role="tabpanel" aria-labelledby="tab-upload-file" className="mt-5">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              if (!isBusy) setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            className={`rounded-xl border-2 border-dashed p-8 text-center transition-colors ${
              isDragging
                ? 'border-[var(--am-accent)] bg-[var(--am-accent-soft)]'
                : 'border-[var(--am-border-strong)] bg-[var(--am-surface-muted)]'
            }`}
          >
            <input
              ref={fileInputRef}
              id="document-file-input"
              type="file"
              accept=".pdf,.txt,.docx,.png,.jpg,.jpeg,.webp"
              disabled={isBusy}
              onChange={(e) => handleFileSelection(e.target.files?.[0] ?? null)}
              className="sr-only"
            />

            <div className="mx-auto flex max-w-md flex-col items-center">
              <div className="flex items-center gap-2 text-[var(--am-accent)]">
                <FileText className="h-7 w-7" aria-hidden="true" />
                <FileImage className="h-7 w-7" aria-hidden="true" />
              </div>
              <p className="mt-3 text-base font-semibold text-[var(--am-text)]">
                Drag and drop a document or photo here
              </p>
              <p className="mt-1 text-sm text-[var(--am-text-muted)]">
                PDF (up to {APP_CONFIG.limits.maxPdfPages} pages), DOCX, TXT, or PNG/JPG/WebP photo · Max 8 MB
              </p>
              <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => fileInputRef.current?.click()}
                  className="min-h-[42px] rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-4 py-2 text-sm font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap"
                >
                  Browse Files
                </button>
              </div>
            </div>
          </div>

          {selectedFile && (
            <div className="mt-4 flex flex-wrap items-center justify-between gap-4 rounded-lg border border-[var(--am-border)] bg-[var(--am-surface-muted)] px-4 py-3">
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-[var(--am-text)]">
                  {selectedFile.name}
                </p>
                <p className="font-mono-tabular text-xs text-[var(--am-text-muted)]">
                  {(selectedFile.size / 1024).toFixed(1)} KB · {selectedFile.type || 'Detected by signature'}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => {
                    setSelectedFile(null);
                    if (fileInputRef.current) fileInputRef.current.value = '';
                  }}
                  className="min-h-[40px] rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3 py-2 text-sm font-medium text-[var(--am-text)] hover:bg-[var(--am-surface-muted)]"
                >
                  Remove
                </button>
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={handleStartUploadAnalysis}
                  className="min-h-[40px] rounded-lg bg-[var(--am-accent)] px-5 py-2 text-sm font-semibold text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)] whitespace-nowrap disabled:opacity-60"
                >
                  Analyze Document
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Paste Text Panel */}
      {mode === 'paste' && (
        <form
          id="panel-paste-text"
          role="tabpanel"
          aria-labelledby="tab-paste-text"
          onSubmit={handleStartPasteAnalysis}
          className="mt-5 space-y-4"
        >
          <div>
            <label
              htmlFor="paste-doc-title"
              className="block text-sm font-medium text-[var(--am-text)]"
            >
              Document Title (optional)
            </label>
            <input
              id="paste-doc-title"
              type="text"
              value={pasteTitle}
              disabled={isBusy}
              onChange={(e) => setPasteTitle(e.target.value)}
              placeholder="e.g., Scholarship Renewal Notice or Clinic Appointment Letter"
              className="mt-1.5 w-full rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3.5 py-2.5 text-sm text-[var(--am-text)] placeholder:text-[var(--am-text-muted)]"
            />
          </div>

          <div>
            <div className="flex items-center justify-between">
              <label
                htmlFor="paste-doc-text"
                className="block text-sm font-medium text-[var(--am-text)]"
              >
                Document Text
              </label>
              <span className="font-mono-tabular text-xs text-[var(--am-text-muted)]">
                {pasteText.length.toLocaleString()} / {APP_CONFIG.limits.maxTextCharacters.toLocaleString()} chars
              </span>
            </div>
            <textarea
              id="paste-doc-text"
              rows={8}
              value={pasteText}
              disabled={isBusy}
              onChange={(e) => {
                setPasteText(e.target.value);
                if (localError) setLocalError(null);
              }}
              placeholder="Paste the full notice, instructions, form requirements, or letter here..."
              className="mt-1.5 w-full rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] p-3.5 text-sm text-[var(--am-text)] placeholder:text-[var(--am-text-muted)]"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              disabled={isBusy || !pasteText}
              onClick={() => {
                setPasteText('');
                setPasteTitle('');
                setLocalError(null);
              }}
              className="min-h-[42px] rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-4 py-2 text-sm font-medium text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] disabled:opacity-50"
            >
              Clear Text
            </button>
            <button
              type="submit"
              disabled={isBusy}
              className="min-h-[42px] rounded-lg bg-[var(--am-accent)] px-6 py-2.5 text-sm font-semibold text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)] whitespace-nowrap disabled:opacity-60"
            >
              Analyze Pasted Text
            </button>
          </div>
        </form>
      )}

      {/* Live Processing Indicator + Cancellation */}
      {isBusy && (
        <div
          role="status"
          aria-live="polite"
          className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[var(--am-accent)] bg-[var(--am-accent-soft)] p-4"
        >
          <div className="flex items-center gap-3 text-sm font-medium text-[var(--am-text)]">
            <Loader2 className="h-4 w-4 animate-spin text-[var(--am-accent)] shrink-0" aria-hidden="true" />
            <span>{status.message}</span>
          </div>
          <button
            type="button"
            onClick={cancelActiveRequest}
            className="min-h-[36px] rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3 py-1.5 text-xs font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap"
          >
            Cancel Request
          </button>
        </div>
      )}

      {/* Privacy Transparency Notice */}
      <div className="mt-5 flex items-start gap-3 rounded-lg border border-[var(--am-border)] bg-[var(--am-surface-muted)] p-4 text-xs text-[var(--am-text-secondary)]">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[var(--am-accent)]" aria-hidden="true" />
        <p>
          <strong className="font-semibold text-[var(--am-text)]">Privacy & Processing Disclosure:</strong>{' '}
          Extracted document text is sent securely through ACCESSMATE&apos;s server-side API to the configured Gemini AI service for simplification, date extraction, and translation. ACCESSMATE does not save your document to any database or disk; all data stays in temporary session memory and is wiped immediately when you click Delete Document.
        </p>
      </div>

      {/* Curated Synthetic Test Documents for Quick Real-AI Testing */}
      <div className="mt-6 border-t border-[var(--am-border)] pt-5">
        <p className="text-xs font-semibold text-[var(--am-text-secondary)]">
          Try a Realistic Synthetic Test Document (Runs Live Gemini Analysis)
        </p>
        <div className="mt-2.5 grid gap-2.5 sm:grid-cols-2">
          {SYNTHETIC_GROUND_TRUTH_DOCUMENTS.map((sample) => (
            <button
              key={sample.id}
              type="button"
              disabled={isBusy}
              onClick={() => handleLoadSample(sample.id)}
              className="rounded-lg border border-[var(--am-border)] bg-[var(--am-surface)] p-3 text-left transition-colors hover:border-[var(--am-accent)] hover:bg-[var(--am-surface-muted)] disabled:opacity-50"
            >
              <div className="text-sm font-semibold text-[var(--am-text)]">{sample.title}</div>
              <p className="mt-1 text-xs text-[var(--am-text-muted)] line-clamp-2">
                {sample.description}
              </p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
