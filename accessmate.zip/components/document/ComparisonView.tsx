'use client';

import React from 'react';
import { READING_LEVELS } from '@/lib/config';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';

export function ComparisonView() {
  const { analysis, readingLevel, switchReadingLevel, status } = useDocumentSession();

  if (!analysis) return null;

  return (
    <section aria-labelledby="comparison-heading" className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h2 id="comparison-heading" className="text-lg font-semibold text-[var(--am-text)]">
            Original Text vs. Simplified Explanation
          </h2>
          <p className="mt-1 text-sm text-[var(--am-text-muted)]">
            Inspect side by side how each section of the original document was simplified without altering numbers, dates, or conditions.
          </p>
        </div>

        <div className="inline-flex rounded-lg border border-[var(--am-border)] bg-[var(--am-surface-muted)] p-1">
          {READING_LEVELS.map((lvl) => (
            <button
              key={lvl.id}
              type="button"
              disabled={status.phase !== 'idle'}
              onClick={() => switchReadingLevel(lvl.id)}
              aria-pressed={readingLevel === lvl.id}
              className={`min-h-[36px] rounded-md px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                readingLevel === lvl.id
                  ? 'bg-[var(--am-surface)] text-[var(--am-text)] font-semibold'
                  : 'text-[var(--am-text-muted)] hover:text-[var(--am-text)]'
              }`}
            >
              {lvl.label}
            </button>
          ))}
        </div>
      </div>

      {analysis.comparisonSegments.length === 0 ? (
        <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6 text-sm text-[var(--am-text-muted)]">
          No section-by-section comparison segments were returned for this document. Try re-analyzing with Deep Reasoning enabled.
        </div>
      ) : (
        <div className="space-y-4">
          {analysis.comparisonSegments.map((seg, idx) => (
            <article
              key={idx}
              className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--am-border)] pb-3">
                <h3 className="text-base font-semibold text-[var(--am-text)]">
                  {idx + 1}. {seg.sectionTitle}
                </h3>
                <span className="font-mono-tabular text-xs text-[var(--am-text-muted)]">
                  {seg.pageNumber ? `Page ${seg.pageNumber}` : 'Source section'}
                </span>
              </div>

              <div className="mt-4 grid gap-6 md:grid-cols-2">
                <div>
                  <p className="text-xs font-semibold text-[var(--am-text-muted)]">
                    Original Document Excerpt
                  </p>
                  <blockquote className="mt-2 rounded-lg border border-[var(--am-border)] bg-[var(--am-surface-muted)] p-4 text-sm text-[var(--am-text-secondary)]">
                    &ldquo;{seg.originalExcerpt}&rdquo;
                  </blockquote>
                </div>

                <div>
                  <p className="text-xs font-semibold text-[var(--am-accent)]">
                    ACCESSMATE {readingLevel.charAt(0).toUpperCase() + readingLevel.slice(1)} Explanation
                  </p>
                  <div className="mt-2 rounded-lg border border-[var(--am-border)] bg-[var(--am-surface)] p-4 text-sm text-[var(--am-text)]">
                    {seg.simplifiedExplanation}
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
