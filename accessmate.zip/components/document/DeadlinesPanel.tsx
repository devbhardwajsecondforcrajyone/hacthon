'use client';

import React, { useState } from 'react';
import {
  AlertTriangle,
  CalendarPlus,
  CheckCircle2,
  ExternalLink,
  Phone,
} from 'lucide-react';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';
import type { DeadlineItem } from '@/lib/types';
import { GoogleSignInButton } from '@/components/workspace/GoogleSignInButton';
import { WorkspaceConfirmModal } from '@/components/workspace/WorkspaceConfirmModal';
import { isSafeHttpUrl } from '@/lib/document/validation';

const DATE_TYPE_LABELS: Record<DeadlineItem['dateType'], string> = {
  submission_deadline: 'Submission Deadline',
  application_date: 'Application Date',
  appointment_date: 'Appointment Date',
  payment_date: 'Payment Date',
  examination_date: 'Examination Date',
  validity_period: 'Validity Period',
  renewal_date: 'Renewal Date',
  other_important_date: 'Important Date',
};

export function DeadlinesPanel() {
  const {
    document,
    analysis,
    workspaceUser,
    workspaceToken,
    isSigningInWorkspace,
    workspaceAuthError,
    connectGoogleWorkspace,
    disconnectGoogleWorkspace,
    announce,
  } = useDocumentSession();

  const [pendingDeadline, setPendingDeadline] = useState<DeadlineItem | null>(null);
  const [savingCalendar, setSavingCalendar] = useState(false);
  const [calendarFeedback, setCalendarFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
    link?: string;
  } | null>(null);
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());

  if (!document || !analysis) return null;

  const handleConfirmSaveToCalendar = async () => {
    if (!pendingDeadline || !pendingDeadline.normalizedDate) return;
    setSavingCalendar(true);
    setCalendarFeedback(null);

    try {
      const token = workspaceToken || (await connectGoogleWorkspace());
      if (!token) {
        setCalendarFeedback({
          type: 'error',
          message: 'Sign in with Google first to save this confirmed deadline to Google Calendar.',
        });
        setSavingCalendar(false);
        return;
      }

      const res = await fetch('/api/workspace/calendar', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          summary: `${pendingDeadline.label} (${document.fileName})`,
          description: `Extracted by ACCESSMATE from ${document.fileName}.\nOriginal wording: "${pendingDeadline.originalText}"\nSource excerpt: "${pendingDeadline.sourceExcerpt}"`,
          date: pendingDeadline.normalizedDate,
        }),
      });

      const payload = (await res.json().catch(() => ({}))) as {
        error?: string;
        htmlLink?: string | null;
      };

      if (!res.ok) {
        throw new Error(payload.error || 'Could not save event to Google Calendar.');
      }

      setSavedIds((prev) => new Set(prev).add(pendingDeadline.id));
      setCalendarFeedback({
        type: 'success',
        message: `Saved "${pendingDeadline.label}" (${pendingDeadline.normalizedDate}) to Google Calendar.`,
        link: payload.htmlLink && isSafeHttpUrl(payload.htmlLink) ? payload.htmlLink : undefined,
      });
      announce(`Saved ${pendingDeadline.label} to Google Calendar.`);
      setPendingDeadline(null);
    } catch (error) {
      setCalendarFeedback({
        type: 'error',
        message: error instanceof Error ? error.message : 'Calendar save failed.',
      });
    } finally {
      setSavingCalendar(false);
    }
  };

  return (
    <section aria-labelledby="deadlines-heading" className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4 rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5">
        <div>
          <h2 id="deadlines-heading" className="text-lg font-semibold text-[var(--am-text)]">
            Important Dates, Deadlines & Contacts
          </h2>
          <p className="mt-1 text-sm text-[var(--am-text-muted)]">
            Publication dates are separated from real deadlines. Ambiguous dates are flagged for verification and never auto-scheduled without your explicit confirmation.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {workspaceUser && workspaceToken ? (
            <div className="flex items-center gap-3 text-xs text-[var(--am-text-secondary)]">
              <span>Google connected ({workspaceUser.email})</span>
              <button
                type="button"
                onClick={disconnectGoogleWorkspace}
                className="underline hover:text-[var(--am-text)]"
              >
                Sign out
              </button>
            </div>
          ) : (
            <GoogleSignInButton
              onClick={() => void connectGoogleWorkspace()}
              disabled={isSigningInWorkspace}
              label={isSigningInWorkspace ? 'Connecting...' : 'Sign in with Google'}
            />
          )}
        </div>
      </div>

      {(calendarFeedback || workspaceAuthError) && (
        <div
          role={calendarFeedback?.type === 'error' || workspaceAuthError ? 'alert' : 'status'}
          className={`flex flex-wrap items-center justify-between gap-3 rounded-lg border p-4 text-sm ${
            calendarFeedback?.type === 'success'
              ? 'border-[var(--am-success)] bg-[var(--am-success-bg)] text-[var(--am-text)]'
              : 'border-[var(--am-danger)] bg-[var(--am-danger-bg)] text-[var(--am-danger)]'
          }`}
        >
          <span>{calendarFeedback?.message || workspaceAuthError}</span>
          {calendarFeedback?.link && (
            <a
              href={calendarFeedback.link}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 font-semibold underline"
            >
              <span>Open in Google Calendar</span>
              <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
            </a>
          )}
        </div>
      )}

      {/* Deadlines List */}
      {analysis.deadlines.length === 0 ? (
        <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6 text-sm text-[var(--am-text-secondary)]">
          No explicit deadlines or action dates were found in this document. Review the original text if you expected a due date.
        </div>
      ) : (
        <div className="space-y-4">
          {analysis.deadlines.map((item) => {
            const canSaveCalendar = Boolean(item.normalizedDate && /^\d{4}-\d{2}-\d{2}$/.test(item.normalizedDate));
            const isSaved = savedIds.has(item.id);

            return (
              <article
                key={item.id}
                className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5"
              >
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-[var(--am-text-muted)]">
                      <span>{DATE_TYPE_LABELS[item.dateType]}</span>
                      <span aria-hidden="true">·</span>
                      <span>Confidence: {item.confidence}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-tabular">
                        {item.pageNumber ? `Page ${item.pageNumber}` : 'Page not specified'}
                      </span>
                    </div>
                    <h3 className="text-base font-semibold text-[var(--am-text)]">{item.label}</h3>
                    <p className="text-sm text-[var(--am-text-secondary)]">
                      Original expression:{' '}
                      <strong className="font-semibold text-[var(--am-text)]">{item.originalText}</strong>
                      {item.normalizedDate && (
                        <span className="ml-2 font-mono-tabular text-xs text-[var(--am-accent)]">
                          (Normalized: {item.normalizedDate})
                        </span>
                      )}
                    </p>
                  </div>

                  <div>
                    {canSaveCalendar ? (
                      <button
                        type="button"
                        disabled={isSaved}
                        onClick={() => setPendingDeadline(item)}
                        className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3.5 py-2 text-xs font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap disabled:opacity-60"
                      >
                        {isSaved ? (
                          <>
                            <CheckCircle2 className="h-4 w-4 text-[var(--am-success)]" aria-hidden="true" />
                            <span>Saved to Calendar</span>
                          </>
                        ) : (
                          <>
                            <CalendarPlus className="h-4 w-4 text-[var(--am-accent)]" aria-hidden="true" />
                            <span>Add to Google Calendar</span>
                          </>
                        )}
                      </button>
                    ) : (
                      <span className="text-xs font-medium text-[var(--am-warning)]">
                        Exact calendar date unavailable
                      </span>
                    )}
                  </div>
                </div>

                {item.needsVerification && (
                  <div className="mt-3 flex items-start gap-2 rounded-lg border border-[var(--am-warning)] bg-[var(--am-warning-bg)] p-3 text-xs text-[var(--am-text)]">
                    <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-[var(--am-warning)]" aria-hidden="true" />
                    <span>
                      <strong>Needs User Verification:</strong>{' '}
                      {item.verificationReason ||
                        'This date expression is relative or missing an explicit year/time. Confirm the exact date with the issuing office.'}
                    </span>
                  </div>
                )}

                <blockquote className="mt-3 rounded-lg bg-[var(--am-surface-muted)] px-3.5 py-2.5 text-xs text-[var(--am-text-secondary)]">
                  Source excerpt: &ldquo;{item.sourceExcerpt}&rdquo;
                </blockquote>
              </article>
            );
          })}
        </div>
      )}

      {/* Important Contacts & Required Documents */}
      <div className="grid gap-6 md:grid-cols-2">
        <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5">
          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4 text-[var(--am-accent)]" aria-hidden="true" />
            <h3 className="text-base font-semibold text-[var(--am-text)]">
              Important Contact Information
            </h3>
          </div>
          {analysis.contactInformation.length === 0 ? (
            <p className="mt-3 text-sm text-[var(--am-text-muted)]">
              No phone numbers, emails, or office addresses were found in this document.
            </p>
          ) : (
            <ul className="mt-3 space-y-3">
              {analysis.contactInformation.map((c, idx) => (
                <li key={idx} className="border-b border-[var(--am-border)] pb-3 last:border-b-0 last:pb-0">
                  <div className="text-xs text-[var(--am-text-muted)]">
                    {c.label} {c.pageNumber ? `· Page ${c.pageNumber}` : ''}
                  </div>
                  <div className="mt-0.5 font-mono-tabular text-sm font-semibold text-[var(--am-text)]">
                    {c.value}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5">
          <h3 className="text-base font-semibold text-[var(--am-text)]">
            Required Supporting Documents
          </h3>
          {analysis.requiredDocuments.length === 0 ? (
            <p className="mt-3 text-sm text-[var(--am-text-muted)]">
              No specific supporting documents were listed as required.
            </p>
          ) : (
            <ul className="mt-3 space-y-2 text-sm text-[var(--am-text)]">
              {analysis.requiredDocuments.map((docName, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span aria-hidden="true" className="text-[var(--am-accent)] font-bold">
                    •
                  </span>
                  <span>{docName}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Explicit User Confirmation Modal before creating any Google Calendar event */}
      <WorkspaceConfirmModal
        open={Boolean(pendingDeadline)}
        title="Confirm Google Calendar Event"
        description="ACCESSMATE never adds calendar events automatically. Review the exact event details below before saving to your primary Google Calendar."
        items={
          pendingDeadline
            ? [
                `Title: ${pendingDeadline.label} (${document.fileName})`,
                `Date: ${pendingDeadline.normalizedDate}`,
                `Original wording: "${pendingDeadline.originalText}"`,
              ]
            : []
        }
        confirmLabel="Confirm & Save Event"
        busy={savingCalendar}
        onConfirm={handleConfirmSaveToCalendar}
        onCancel={() => setPendingDeadline(null)}
      />
    </section>
  );
}
