'use client';

import React, { useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle2, HelpCircle, Search } from 'lucide-react';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';
import { verifyExcerptAgainstDocument } from '@/lib/document/chunking';

interface VerificationEntry {
  id: string;
  section: string;
  statement: string;
  sourceExcerpt: string;
  pageNumber: number | null;
  matchType: 'exact' | 'normalized' | 'unverified';
}

export function SourceEvidencePanel() {
  const { document, analysis } = useDocumentSession();
  const [filter, setFilter] = useState<'all' | 'verified' | 'unverified'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const entries: VerificationEntry[] = useMemo(() => {
    if (!document || !analysis) return [];
    const list: VerificationEntry[] = [];

    const pushGroup = (
      section: string,
      items: { statement: string; sourceExcerpt: string; pageNumber: number | null }[]
    ) => {
      items.forEach((item, idx) => {
        const check = verifyExcerptAgainstDocument(item.sourceExcerpt, document.fullText);
        list.push({
          id: `${section}-${idx}`,
          section,
          statement: item.statement,
          sourceExcerpt: item.sourceExcerpt,
          pageNumber: item.pageNumber,
          matchType: check.matchType,
        });
      });
    };

    pushGroup('Key Points', analysis.keyPoints);
    pushGroup('Important Instructions', analysis.importantInstructions);
    pushGroup('Requirements', analysis.keyRequirements);
    pushGroup('Warnings', analysis.importantWarnings);
    pushGroup('Responsibilities', analysis.responsibilities);
    pushGroup('Conditions', analysis.relevantConditions);

    analysis.deadlines.forEach((d, idx) => {
      const check = verifyExcerptAgainstDocument(d.sourceExcerpt, document.fullText);
      list.push({
        id: `deadline-${idx}`,
        section: 'Important Date',
        statement: `${d.label}: ${d.originalText}`,
        sourceExcerpt: d.sourceExcerpt,
        pageNumber: d.pageNumber,
        matchType: check.matchType,
      });
    });

    analysis.actionChecklist.forEach((c, idx) => {
      const check = verifyExcerptAgainstDocument(c.sourceExcerpt, document.fullText);
      list.push({
        id: `task-${idx}`,
        section: 'Action Task',
        statement: `${c.title} — ${c.explanation}`,
        sourceExcerpt: c.sourceExcerpt,
        pageNumber: c.pageNumber,
        matchType: check.matchType,
      });
    });

    return list;
  }, [document, analysis]);

  if (!document || !analysis) return null;

  const verifiedCount = entries.filter((e) => e.matchType !== 'unverified').length;
  const verificationPct = entries.length > 0 ? Math.round((verifiedCount / entries.length) * 100) : 100;

  const filtered = entries.filter((e) => {
    if (filter === 'verified' && e.matchType === 'unverified') return false;
    if (filter === 'unverified' && e.matchType !== 'unverified') return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        e.statement.toLowerCase().includes(q) ||
        e.sourceExcerpt.toLowerCase().includes(q) ||
        e.section.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <section aria-labelledby="evidence-panel-heading" className="space-y-6">
      <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 id="evidence-panel-heading" className="text-lg font-semibold text-[var(--am-text)]">
              Source Evidence & Verification Panel
            </h2>
            <p className="mt-1 text-sm text-[var(--am-text-muted)]">
              Every major AI claim is cross-checked programmatically against the extracted source text so you can verify exact wording and page references.
            </p>
          </div>
          <div className="text-right">
            <div className="font-mono-tabular text-2xl font-bold text-[var(--am-text)]">
              {verificationPct}%
            </div>
            <div className="font-mono-tabular text-xs text-[var(--am-text-muted)]">
              {verifiedCount}/{entries.length} excerpts matched
            </div>
          </div>
        </div>

        {/* Document Quality & Extraction Warnings */}
        {document.warnings.length > 0 && (
          <div className="mt-5 space-y-2.5 border-t border-[var(--am-border)] pt-4">
            <h3 className="text-sm font-semibold text-[var(--am-text)]">
              Document Quality & Extraction Warnings
            </h3>
            {document.warnings.map((w) => (
              <div
                key={w.id}
                className="rounded-lg border border-[var(--am-warning)] bg-[var(--am-warning-bg)] p-3.5 text-sm"
              >
                <div className="flex items-start gap-2.5">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-[var(--am-warning)]" aria-hidden="true" />
                  <div>
                    <p className="font-semibold text-[var(--am-text)]">{w.title}</p>
                    <p className="mt-0.5 text-xs text-[var(--am-text-secondary)]">{w.message}</p>
                    <p className="mt-1 text-xs font-medium text-[var(--am-text)]">
                      Recommendation: {w.recommendation}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Filter & Search Bar */}
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-[var(--am-border)] pt-4">
          <div className="inline-flex rounded-lg border border-[var(--am-border)] bg-[var(--am-surface-muted)] p-1">
            {(['all', 'verified', 'unverified'] as const).map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setFilter(f)}
                aria-pressed={filter === f}
                className={`min-h-[34px] rounded-md px-3 py-1 text-xs font-medium capitalize ${
                  filter === f
                    ? 'bg-[var(--am-surface)] text-[var(--am-text)] font-semibold'
                    : 'text-[var(--am-text-muted)] hover:text-[var(--am-text)]'
                }`}
              >
                {f}
              </button>
            ))}
          </div>

          <div className="relative flex-1 min-w-[220px] max-w-sm">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--am-text-muted)]"
              aria-hidden="true"
            />
            <label htmlFor="evidence-search" className="sr-only">
              Filter source evidence
            </label>
            <input
              id="evidence-search"
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search statements or source quotes..."
              className="w-full rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] py-2 pl-9 pr-3 text-sm text-[var(--am-text)]"
            />
          </div>
        </div>
      </div>

      {/* Evidence Table / Cards */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6 text-sm text-[var(--am-text-muted)]">
            No evidence items match your current filter.
          </div>
        ) : (
          filtered.map((entry) => (
            <article
              key={entry.id}
              className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-4"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[var(--am-text-muted)]">
                <span>
                  {entry.section} · {entry.pageNumber ? `Page ${entry.pageNumber}` : 'Page not specified'}
                </span>
                <span className="inline-flex items-center gap-1.5 font-medium">
                  {entry.matchType !== 'unverified' ? (
                    <>
                      <CheckCircle2 className="h-3.5 w-3.5 text-[var(--am-success)]" aria-hidden="true" />
                      <span className="text-[var(--am-success)]">
                        {entry.matchType === 'exact' ? 'Verified verbatim quote' : 'Verified normalized match'}
                      </span>
                    </>
                  ) : (
                    <>
                      <HelpCircle className="h-3.5 w-3.5 text-[var(--am-warning)]" aria-hidden="true" />
                      <span className="text-[var(--am-warning)]">Verify against original text</span>
                    </>
                  )}
                </span>
              </div>
              <p className="mt-2 text-sm font-medium text-[var(--am-text)]">{entry.statement}</p>
              <blockquote className="mt-2 rounded-lg bg-[var(--am-surface-muted)] px-3.5 py-2.5 text-xs text-[var(--am-text-secondary)]">
                Source excerpt: &ldquo;{entry.sourceExcerpt}&rdquo;
              </blockquote>
            </article>
          ))
        )}
      </div>
    </section>
  );
}
