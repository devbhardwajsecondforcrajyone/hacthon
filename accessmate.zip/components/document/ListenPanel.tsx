'use client';

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Loader2, Pause, Play, Square, Volume2 } from 'lucide-react';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';
import { getLanguageByCode } from '@/lib/config';

interface ReadableSection {
  id: string;
  title: string;
  text: string;
}

export function ListenPanel() {
  const { analysis, translation, selectedLanguageCode, announce } = useDocumentSession();

  const [speechSupported] = useState(
    () => typeof window !== 'undefined' && 'speechSynthesis' in window
  );
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceUri, setSelectedVoiceUri] = useState<string>('');
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [activeSectionId, setActiveSectionId] = useState<string | null>(null);
  const [playbackState, setPlaybackState] = useState<'idle' | 'playing' | 'paused'>('idle');

  // Optional Gemini Neural TTS audio state
  const [aiVoiceName, setAiVoiceName] = useState<'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr'>('Kore');
  const [aiAudioLoading, setAiAudioLoading] = useState(false);
  const [aiAudioUrl, setAiAudioUrl] = useState<string | null>(null);
  const [aiAudioError, setAiAudioError] = useState<string | null>(null);
  const aiAudioRef = useRef<HTMLAudioElement | null>(null);

  const sections: ReadableSection[] = useMemo(() => {
    if (!analysis) return [];

    if (translation) {
      return [
        {
          id: 'overview',
          title: `Document Overview (${translation.targetLanguageName})`,
          text: translation.documentOverview,
        },
        {
          id: 'summary',
          title: `Simplified Summary (${translation.targetLanguageName})`,
          text: translation.summary,
        },
        {
          id: 'instructions',
          title: 'Important Instructions & Warnings',
          text: [...translation.importantInstructions, ...translation.importantWarnings].join('. '),
        },
        {
          id: 'checklist',
          title: 'Action Checklist',
          text: translation.checklistItems
            .map((c, idx) => `Step ${idx + 1}: ${c.title}. ${c.explanation}`)
            .join(' '),
        },
      ].filter((s) => s.text.trim().length > 0);
    }

    return [
      {
        id: 'overview',
        title: 'Document Overview',
        text: analysis.documentOverview,
      },
      {
        id: 'summary',
        title: 'Simplified Summary',
        text: analysis.summary,
      },
      {
        id: 'deadlines',
        title: 'Important Dates & Deadlines',
        text:
          analysis.deadlines.length > 0
            ? analysis.deadlines
                .map(
                  (d) =>
                    `${d.label}: ${d.originalText}.${
                      d.needsVerification ? ' Note: verify this date carefully.' : ''
                    }`
                )
                .join(' ')
            : 'No explicit deadlines were found in this document.',
      },
      {
        id: 'instructions',
        title: 'Instructions & Warnings',
        text: [
          ...analysis.importantInstructions.map((i) => i.statement),
          ...analysis.importantWarnings.map((w) => `Warning: ${w.statement}`),
        ].join(' '),
      },
      {
        id: 'checklist',
        title: 'Action Checklist',
        text: analysis.actionChecklist
          .map(
            (c, idx) =>
              `Task ${idx + 1}: ${c.title}. ${c.explanation}${
                c.dueDate ? ` Due ${c.dueDate}.` : ''
              }`
          )
          .join(' '),
      },
    ].filter((s) => s.text.trim().length > 0);
  }, [analysis, translation]);

  useEffect(() => {
    if (!speechSupported || typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }

    const loadVoices = () => {
      const available = window.speechSynthesis.getVoices();
      setVoices(available);
      if (available.length > 0) {
        setSelectedVoiceUri((prev) => {
          if (prev) return prev;
          const targetLang = getLanguageByCode(selectedLanguageCode)?.bcp47 ?? 'en-US';
          const match =
            available.find((v) =>
              v.lang.toLowerCase().startsWith(targetLang.slice(0, 2).toLowerCase())
            ) ?? available[0];
          return match?.voiceURI ?? '';
        });
      }
    };

    const timer = window.setTimeout(loadVoices, 0);
    window.speechSynthesis.onvoiceschanged = loadVoices;
    return () => {
      window.clearTimeout(timer);
      window.speechSynthesis.cancel();
    };
  }, [selectedLanguageCode, speechSupported]);

  useEffect(() => {
    return () => {
      if (aiAudioUrl) URL.revokeObjectURL(aiAudioUrl);
    };
  }, [aiAudioUrl]);

  if (!analysis) return null;

  const handleStopBrowserSpeech = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setPlaybackState('idle');
    setActiveSectionId(null);
    announce('Stopped reading aloud.');
  };

  const handleSpeakText = (sectionId: string, text: string, title: string) => {
    if (!speechSupported || typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = speechRate;

    const chosenVoice = voices.find((v) => v.voiceURI === selectedVoiceUri);
    if (chosenVoice) {
      utterance.voice = chosenVoice;
      utterance.lang = chosenVoice.lang;
    } else {
      utterance.lang = getLanguageByCode(selectedLanguageCode)?.bcp47 ?? 'en-US';
    }

    utterance.onstart = () => {
      setActiveSectionId(sectionId);
      setPlaybackState('playing');
      announce(`Reading ${title}.`);
    };
    utterance.onend = () => {
      setPlaybackState('idle');
      setActiveSectionId(null);
    };
    utterance.onerror = () => {
      setPlaybackState('idle');
      setActiveSectionId(null);
    };

    window.speechSynthesis.speak(utterance);
  };

  const handleReadAll = () => {
    const combined = sections.map((s) => `${s.title}. ${s.text}`).join(' ');
    handleSpeakText('all', combined, 'full simplified document');
  };

  const handlePauseResume = () => {
    if (!speechSupported || typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }
    if (playbackState === 'playing') {
      window.speechSynthesis.pause();
      setPlaybackState('paused');
      announce('Paused reading.');
    } else if (playbackState === 'paused') {
      window.speechSynthesis.resume();
      setPlaybackState('playing');
      announce('Resumed reading.');
    }
  };

  const handleGenerateGeminiAudio = async () => {
    setAiAudioLoading(true);
    setAiAudioError(null);
    try {
      const script = sections
        .slice(0, 3)
        .map((s) => `${s.title}. ${s.text}`)
        .join('\n\n');

      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: script,
          voiceName: aiVoiceName,
        }),
      });
      const payload = (await res.json().catch(() => ({}))) as {
        audioBase64?: string;
        mimeType?: string;
        error?: string;
      };
      if (!res.ok || !payload.audioBase64) {
        throw new Error(payload.error || 'Could not generate AI narration.');
      }

      const binary = atob(payload.audioBase64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: payload.mimeType || 'audio/wav' });
      if (aiAudioUrl) URL.revokeObjectURL(aiAudioUrl);
      const url = URL.createObjectURL(blob);
      setAiAudioUrl(url);
      announce('Gemini Neural Audio ready to play.');
    } catch (error) {
      setAiAudioError(
        error instanceof Error ? error.message : 'AI audio generation failed.'
      );
    } finally {
      setAiAudioLoading(false);
    }
  };

  return (
    <section aria-labelledby="listen-heading" className="space-y-6">
      <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 id="listen-heading" className="text-lg font-semibold text-[var(--am-text)]">
              Listen to Document (Accessible Text-to-Speech)
            </h2>
            <p className="mt-1 text-sm text-[var(--am-text-muted)]">
              Audio never starts automatically. Read the full simplified document or individual sections aloud using your browser&apos;s built-in speech engine or optional Gemini Neural Voice.
            </p>
          </div>
          {activeSectionId && (
            <span className="font-mono-tabular text-xs font-semibold text-[var(--am-accent)]">
              {playbackState === 'paused' ? 'Paused' : 'Reading'}: {activeSectionId}
            </span>
          )}
        </div>

        {/* Browser Speech Controls */}
        {speechSupported ? (
          <div className="mt-5 space-y-4 border-t border-[var(--am-border)] pt-4">
            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={handleReadAll}
                className="inline-flex min-h-[42px] items-center gap-2 rounded-lg bg-[var(--am-accent)] px-4 py-2 text-sm font-semibold text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)] whitespace-nowrap"
              >
                <Play className="h-4 w-4" aria-hidden="true" />
                <span>Read Full Summary Aloud</span>
              </button>

              <button
                type="button"
                disabled={playbackState === 'idle'}
                onClick={handlePauseResume}
                className="inline-flex min-h-[42px] items-center gap-2 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-4 py-2 text-sm font-medium text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap disabled:opacity-50"
              >
                <Pause className="h-4 w-4" aria-hidden="true" />
                <span>{playbackState === 'paused' ? 'Resume' : 'Pause'}</span>
              </button>

              <button
                type="button"
                disabled={playbackState === 'idle'}
                onClick={handleStopBrowserSpeech}
                className="inline-flex min-h-[42px] items-center gap-2 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-4 py-2 text-sm font-medium text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap disabled:opacity-50"
              >
                <Square className="h-4 w-4" aria-hidden="true" />
                <span>Stop</span>
              </button>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label
                  htmlFor="speech-rate-slider"
                  className="flex items-center justify-between text-xs font-semibold text-[var(--am-text-secondary)]"
                >
                  <span>Reading Speed</span>
                  <span className="font-mono-tabular">{speechRate.toFixed(2)}x</span>
                </label>
                <input
                  id="speech-rate-slider"
                  type="range"
                  min="0.6"
                  max="1.6"
                  step="0.1"
                  value={speechRate}
                  onChange={(e) => setSpeechRate(Number(e.target.value))}
                  className="mt-2 w-full accent-[var(--am-accent)]"
                />
              </div>

              <div>
                <label
                  htmlFor="voice-selector"
                  className="block text-xs font-semibold text-[var(--am-text-secondary)]"
                >
                  Browser Voice ({voices.length} available)
                </label>
                <select
                  id="voice-selector"
                  value={selectedVoiceUri}
                  onChange={(e) => setSelectedVoiceUri(e.target.value)}
                  className="mt-1.5 min-h-[40px] w-full rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3 py-1.5 text-sm text-[var(--am-text)]"
                >
                  {voices.length === 0 ? (
                    <option value="">System Default Voice</option>
                  ) : (
                    voices.map((v) => (
                      <option key={v.voiceURI} value={v.voiceURI}>
                        {v.name} ({v.lang})
                      </option>
                    ))
                  )}
                </select>
              </div>
            </div>
          </div>
        ) : (
          <div className="mt-4 rounded-lg border border-[var(--am-warning)] bg-[var(--am-warning-bg)] p-4 text-sm text-[var(--am-text)]">
            Browser Speech Synthesis is not available in this browser. You can use the Gemini Neural Audio generator below or your operating system&apos;s built-in screen reader (NVDA, JAWS, VoiceOver, TalkBack).
          </div>
        )}

        {/* Optional Gemini Neural TTS */}
        <div className="mt-5 border-t border-[var(--am-border)] pt-4">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h3 className="text-sm font-semibold text-[var(--am-text)]">
                Optional Gemini Neural Audio (WAV)
              </h3>
              <p className="mt-0.5 text-xs text-[var(--am-text-muted)]">
                Generate natural spoken narration via server-side Gemini TTS if browser voices sound robotic or unavailable.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2.5">
              <label htmlFor="ai-voice-select" className="sr-only">
                Select Gemini TTS voice
              </label>
              <select
                id="ai-voice-select"
                value={aiVoiceName}
                onChange={(e) =>
                  setAiVoiceName(e.target.value as 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr')
                }
                className="min-h-[40px] rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3 py-1.5 text-xs text-[var(--am-text)]"
              >
                <option value="Kore">Kore (Clear Neutral)</option>
                <option value="Zephyr">Zephyr (Calm)</option>
                <option value="Puck">Puck (Warm)</option>
                <option value="Charon">Charon (Deep)</option>
                <option value="Fenrir">Fenrir (Articulate)</option>
              </select>
              <button
                type="button"
                disabled={aiAudioLoading}
                onClick={handleGenerateGeminiAudio}
                className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-4 py-2 text-xs font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap disabled:opacity-60"
              >
                {aiAudioLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                ) : (
                  <Volume2 className="h-4 w-4 text-[var(--am-accent)]" aria-hidden="true" />
                )}
                <span>{aiAudioLoading ? 'Generating Audio...' : 'Generate Neural Audio'}</span>
              </button>
            </div>
          </div>

          {aiAudioError && (
            <p role="alert" className="mt-3 text-xs text-[var(--am-danger)]">
              {aiAudioError}
            </p>
          )}

          {aiAudioUrl && (
            <div className="mt-4">
              <audio ref={aiAudioRef} controls src={aiAudioUrl} className="w-full" />
            </div>
          )}
        </div>
      </div>

      {/* Individual Section Readers */}
      <div className="space-y-3">
        {sections.map((section) => {
          const isReadingThis = activeSectionId === section.id && playbackState !== 'idle';
          return (
            <article
              key={section.id}
              className={`rounded-xl border p-5 transition-colors ${
                isReadingThis
                  ? 'border-[var(--am-accent)] bg-[var(--am-accent-soft)]'
                  : 'border-[var(--am-border)] bg-[var(--am-surface)]'
              }`}
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h3 className="text-base font-semibold text-[var(--am-text)]">
                  {section.title}
                </h3>
                {speechSupported && (
                  <button
                    type="button"
                    onClick={() => handleSpeakText(section.id, section.text, section.title)}
                    className="inline-flex min-h-[38px] items-center gap-2 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3.5 py-1.5 text-xs font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap"
                  >
                    <Play className="h-3.5 w-3.5 text-[var(--am-accent)]" aria-hidden="true" />
                    <span>{isReadingThis ? 'Restart Section' : 'Read This Section'}</span>
                  </button>
                )}
              </div>
              <p className="mt-2.5 text-sm text-[var(--am-text-secondary)]">{section.text}</p>
            </article>
          );
        })}
      </div>
    </section>
  );
}
