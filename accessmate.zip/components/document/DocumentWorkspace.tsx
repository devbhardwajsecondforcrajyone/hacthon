'use client';

import React from 'react';
import {
  AlertTriangle,
  CalendarClock,
  CheckSquare,
  Columns2,
  FileSearch,
  FileText,
  Languages,
  Loader2,
  MessageSquareText,
  RefreshCw,
  Volume2,
} from 'lucide-react';
import { READING_LEVELS } from '@/lib/config';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';
import type { EvidenceItem, WorkspaceTab } from '@/lib/types';
import { ComparisonView } from '@/components/document/ComparisonView';
import { SourceEvidencePanel } from '@/components/document/SourceEvidencePanel';
import { TranslationPanel } from '@/components/document/TranslationPanel';
import { DeadlinesPanel } from '@/components/document/DeadlinesPanel';
import { ActionChecklistPanel } from '@/components/checklist/ActionChecklistPanel';
import { DocumentQAPanel } from '@/components/document/DocumentQAPanel';
import { ListenPanel } from '@/components/document/ListenPanel';

const WORKSPACE_TABS: readonly {
  id: WorkspaceTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  { id: 'overview', label: 'Overview', icon: FileText },
  { id: 'comparison', label: 'Compare', icon: Columns2 },
  { id: 'evidence', label: 'Evidence', icon: FileSearch },
  { id: 'translation', label: 'Translate', icon: Languages },
  { id: 'deadlines', label: 'Dates', icon: CalendarClock },
  { id: 'checklist', label: 'Checklist', icon: CheckSquare },
  { id: 'qa', label: 'Ask & Voice', icon: MessageSquareText },
  { id: 'listen', label: 'Listen', icon: Volume2 },
];

function EvidenceListCard({
  title,
  items,
  emptyText,
  tone = 'normal',
}: {
  title: string;
  items: EvidenceItem[];
  emptyText: string;
  tone?: 'normal' | 'warning';
}) {
  return (
    <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5">
      <h3
        className={`text-base font-semibold ${
          tone === 'warning' ? 'text-[var(--am-warning)]' : 'text-[var(--am-text)]'
        }`}
      >
        {title}
      </h3>
      {items.length === 0 ? (
        <p className="mt-2.5 text-sm text-[var(--am-text-muted)]">{emptyText}</p>
      ) : (
        <ul className="mt-3 space-y-3">
          {items.map((item, idx) => (
            <li
              key={idx}
              className="border-b border-[var(--am-border)] pb-3 last:border-b-0 last:pb-0"
            >
              <p className="text-sm font-medium text-[var(--am-text)]">{item.statement}</p>
              <p className="mt-1 text-xs text-[var(--am-text-muted)]">
                Source{item.pageNumber ? ` (Page ${item.pageNumber})` : ''}: &ldquo;
                {item.sourceExcerpt}&rdquo;
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export function DocumentWorkspace() {
  const {
    document,
    analysis,
    analysisMeta,
    readingLevel,
    deepReasoning,
    switchReadingLevel,
    reanalyzeCurrentDocument,
    activeTab,
    setActiveTab,
    status,
    errorMessage,
    cancelActiveRequest,
    setActiveNav,
  } = useDocumentSession();

  if (!document) {
    return (
      <section className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-8 text-center">
        <FileText className="mx-auto h-9 w-9 text-[var(--am-accent)]" aria-hidden="true" />
        <h1 className="mt-3 text-xl font-bold text-[var(--am-text)]">
          No Document Loaded Yet
        </h1>
        <p className="mx-auto mt-2 max-w-lg text-sm text-[var(--am-text-muted)]">
          Upload a PDF, DOCX, TXT, or document image — or paste text — on the Dashboard to generate plain-language summaries, verified deadlines, translations, and an actionable checklist.
        </p>
        <button
          type="button"
          onClick={() => setActiveNav('dashboard')}
          className="mt-5 min-h-[44px] rounded-lg bg-[var(--am-accent)] px-5 py-2.5 text-sm font-semibold text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)]"
        >
          Upload or Paste Document
        </button>
      </section>
    );
  }

  const isBusy = status.phase !== 'idle';

  return (
    <div className="space-y-6">
      {/* Document Header Summary */}
      <section className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0">
            <h1 className="truncate text-xl font-bold text-[var(--am-text)]">
              {document.fileName}
            </h1>
            <p className="mt-1 font-mono-tabular text-xs text-[var(--am-text-muted)]">
              {document.pageCount} page(s) · {document.wordCount.toLocaleString()} words · ~
              {document.estimatedTokens.toLocaleString()} tokens
              {analysisMeta
                ? ` · ${analysisMeta.cached ? 'Cached' : `${analysisMeta.durationMs} ms`} · ${analysisMeta.groundingVerification.verificationRate}% citations matched`
                : ''}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <div
              role="group"
              aria-label="Reading level"
              className="inline-flex rounded-lg border border-[var(--am-border)] bg-[var(--am-surface-muted)] p-1"
            >
              {READING_LEVELS.map((lvl) => (
                <button
                  key={lvl.id}
                  type="button"
                  disabled={isBusy}
                  aria-pressed={readingLevel === lvl.id}
                  onClick={() => void switchReadingLevel(lvl.id)}
                  className={`min-h-[34px] rounded-md px-3 py-1 text-xs font-medium whitespace-nowrap ${
                    readingLevel === lvl.id
                      ? 'bg-[var(--am-surface)] text-[var(--am-text)] font-semibold'
                      : 'text-[var(--am-text-muted)] hover:text-[var(--am-text)]'
                  }`}
                >
                  {lvl.label}
                </button>
              ))}
            </div>

            <button
              type="button"
              disabled={isBusy}
              onClick={() => void reanalyzeCurrentDocument(!deepReasoning)}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3 py-1.5 text-xs font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap disabled:opacity-50"
            >
              <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>{deepReasoning ? 'Deep Reasoning On' : 'Run Deep Reasoning'}</span>
            </button>
          </div>
        </div>

        {/* Quality Warnings Banner */}
        {document.warnings.length > 0 && (
          <div className="mt-4 flex items-start gap-2.5 rounded-lg border border-[var(--am-warning)] bg-[var(--am-warning-bg)] p-3.5 text-xs text-[var(--am-text)]">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-[var(--am-warning)]" aria-hidden="true" />
            <div>
              <strong>
                {document.warnings.length} Document Quality Notice
                {document.warnings.length > 1 ? 's' : ''}:
              </strong>{' '}
              {document.warnings.map((w) => w.title).join(' · ')}.{' '}
              <button
                type="button"
                onClick={() => setActiveTab('evidence')}
                className="font-semibold underline"
              >
                Inspect details
              </button>
            </div>
          </div>
        )}
      </section>

      {/* Live Loading / Error State */}
      {isBusy && (
        <div
          role="status"
          aria-live="polite"
          className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[var(--am-accent)] bg-[var(--am-accent-soft)] p-5"
        >
          <div className="flex items-center gap-3 text-sm font-medium text-[var(--am-text)]">
            <Loader2 className="h-5 w-5 animate-spin text-[var(--am-accent)]" aria-hidden="true" />
            <span>{status.message}</span>
          </div>
          <button
            type="button"
            onClick={cancelActiveRequest}
            className="min-h-[36px] rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3 py-1.5 text-xs font-semibold text-[var(--am-text)]"
          >
            Cancel
          </button>
        </div>
      )}

      {errorMessage && !isBusy && (
        <div
          role="alert"
          className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[var(--am-danger)] bg-[var(--am-danger-bg)] p-4 text-sm text-[var(--am-danger)]"
        >
          <span>{errorMessage}</span>
          <button
            type="button"
            onClick={() => void reanalyzeCurrentDocument()}
            className="min-h-[36px] rounded-lg border border-[var(--am-danger)] bg-[var(--am-surface)] px-3.5 py-1.5 text-xs font-semibold text-[var(--am-danger)]"
          >
            Retry Analysis
          </button>
        </div>
      )}

      {/* Workspace Tab Bar */}
      <div className="no-print overflow-x-auto border-b border-[var(--am-border)]">
        <div role="tablist" aria-label="Document analysis sections" className="flex min-w-max gap-1 pb-2">
          {WORKSPACE_TABS.map((tab) => {
            const Icon = tab.icon;
            const selected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                id={`ws-tab-${tab.id}`}
                aria-selected={selected}
                aria-controls={`ws-panel-${tab.id}`}
                onClick={() => setActiveTab(tab.id)}
                className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
                  selected
                    ? 'bg-[var(--am-accent)] text-[var(--am-accent-ink)] font-semibold'
                    : 'text-[var(--am-text-secondary)] hover:bg-[var(--am-surface-muted)] hover:text-[var(--am-text)]'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>{tab.label}</span>
                {tab.id === 'deadlines' && analysis && (
                  <span className="font-mono-tabular text-xs opacity-80">
                    ({analysis.deadlines.length})
                  </span>
                )}
                {tab.id === 'checklist' && analysis && (
                  <span className="font-mono-tabular text-xs opacity-80">
                    ({analysis.actionChecklist.length})
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Tab Content */}
      {analysis && (
        <div
          id={`ws-panel-${activeTab}`}
          role="tabpanel"
          aria-labelledby={`ws-tab-${activeTab}`}
        >
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Primary Overview & Simplified Explanation */}
              <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[var(--am-text-muted)]">
                  <span>
                    Detected language: {analysis.detectedLanguage} · Reading level:{' '}
                    {analysis.readingLevel}
                  </span>
                  <span>AI explanation grounded in uploaded document</span>
                </div>

                <div>
                  <h2 className="text-lg font-semibold text-[var(--am-text)]">
                    Document Overview
                  </h2>
                  <p className="mt-2 text-base text-[var(--am-text)]">
                    {analysis.documentOverview}
                  </p>
                </div>

                <div className="border-t border-[var(--am-border)] pt-4">
                  <h3 className="text-base font-semibold text-[var(--am-text)]">
                    Plain-Language Summary
                  </h3>
                  <p className="mt-2 whitespace-pre-line text-sm text-[var(--am-text-secondary)]">
                    {analysis.summary}
                  </p>
                </div>
              </div>

              {/* Structured Breakdown Grid */}
              <div className="grid gap-6 md:grid-cols-2">
                <EvidenceListCard
                  title="Key Points"
                  items={analysis.keyPoints}
                  emptyText="No key points extracted."
                />
                <EvidenceListCard
                  title="Important Warnings"
                  items={analysis.importantWarnings}
                  emptyText="No explicit warnings or penalties were stated in this document."
                  tone="warning"
                />
                <EvidenceListCard
                  title="Important Instructions"
                  items={analysis.importantInstructions}
                  emptyText="No explicit instructions found."
                />
                <EvidenceListCard
                  title="Key Requirements & Eligibility"
                  items={analysis.keyRequirements}
                  emptyText="No formal eligibility requirements found."
                />
                <EvidenceListCard
                  title="Your Responsibilities"
                  items={analysis.responsibilities}
                  emptyText="No separate responsibilities listed."
                />
                <EvidenceListCard
                  title="Relevant Conditions & Exceptions"
                  items={analysis.relevantConditions}
                  emptyText="No special conditions or exceptions noted."
                />
              </div>

              {/* Uncertainties & Missing Information */}
              {(analysis.uncertainties.length > 0 || analysis.missingInformation.length > 0) && (
                <div className="rounded-xl border border-[var(--am-warning)] bg-[var(--am-warning-bg)] p-5 space-y-3">
                  <h3 className="text-base font-semibold text-[var(--am-text)]">
                    Uncertain or Missing Information (Verify Before Acting)
                  </h3>
                  {analysis.uncertainties.length > 0 && (
                    <div>
                      <p className="text-xs font-semibold text-[var(--am-text-secondary)]">
                        Uncertain or Ambiguous Details
                      </p>
                      <ul className="mt-1 space-y-1 text-sm text-[var(--am-text)]">
                        {analysis.uncertainties.map((u, idx) => (
                          <li key={idx}>• {u}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {analysis.missingInformation.length > 0 && (
                    <div>
                      <p className="text-xs font-semibold text-[var(--am-text-secondary)]">
                        Information Not Stated in This Document
                      </p>
                      <ul className="mt-1 space-y-1 text-sm text-[var(--am-text)]">
                        {analysis.missingInformation.map((m, idx) => (
                          <li key={idx}>• {m}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {activeTab === 'comparison' && <ComparisonView />}
          {activeTab === 'evidence' && <SourceEvidencePanel />}
          {activeTab === 'translation' && <TranslationPanel />}
          {activeTab === 'deadlines' && <DeadlinesPanel />}
          {activeTab === 'checklist' && <ActionChecklistPanel />}
          {activeTab === 'qa' && <DocumentQAPanel />}
          {activeTab === 'listen' && <ListenPanel />}
        </div>
      )}
    </div>
  );
}
