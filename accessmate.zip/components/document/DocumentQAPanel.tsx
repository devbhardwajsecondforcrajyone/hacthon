'use client';

import React, { useRef, useState } from 'react';
import {
  ExternalLink,
  Globe,
  Loader2,
  Mic,
  MicOff,
  Send,
} from 'lucide-react';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';
import { SUPPORTED_LANGUAGES } from '@/lib/config';
import { isSafeHttpUrl } from '@/lib/document/validation';

const SUGGESTED_QUESTIONS = [
  'What is the submission deadline?',
  'Which documents do I need to submit?',
  'Are there any penalties, fees, or warnings?',
  'Who do I contact if I have a question?',
];

export function DocumentQAPanel() {
  const {
    document,
    qaMessages,
    askDocumentQuestion,
    translateToLanguage,
    setActiveTab,
    status,
    announce,
  } = useDocumentSession();

  const [question, setQuestion] = useState('');
  const [includeSearchContext, setIncludeSearchContext] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [voiceFeedback, setVoiceFeedback] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  if (!document) return null;

  const isBusy = status.phase !== 'idle';

  /**
   * Routes high-intent voice or text commands (e.g. "Translate this into Hindi",
   * "Create my action checklist") directly into real workspace actions, or sends
   * document questions to Gemini Q&A.
   */
  const executeCommandOrQuestion = async (rawInput: string) => {
    const trimmed = rawInput.trim();
    if (!trimmed) return;

    const lower = trimmed.toLowerCase();

    // Command 1: Translation voice/text command
    const translateMatch = SUPPORTED_LANGUAGES.find(
      (lang) =>
        lower.includes('translate') &&
        (lower.includes(lang.name.toLowerCase()) || lower.includes(lang.nativeName.toLowerCase()))
    );
    if (translateMatch) {
      setVoiceFeedback(`Translating document into ${translateMatch.name}...`);
      setActiveTab('translation');
      await translateToLanguage(translateMatch.code);
      return;
    }

    // Command 2: Open action checklist
    if (/(open|show|create|view)\s+(my\s+)?(action\s+)?checklist/i.test(lower)) {
      setActiveTab('checklist');
      announce('Switched to Action Checklist tab.');
      setVoiceFeedback('Opened your Action Checklist.');
      return;
    }

    // Command 3: Summarize / overview
    if (/^(summarize|show overview|explain this document)/i.test(lower)) {
      setActiveTab('overview');
      announce('Switched to Document Overview.');
      setVoiceFeedback('Opened the plain-language overview.');
      return;
    }

    // Default: Document-grounded Q&A
    setVoiceFeedback(null);
    await askDocumentQuestion(trimmed, includeSearchContext);
    setQuestion('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await executeCommandOrQuestion(question);
  };

  /**
   * Optional voice interaction: requests microphone permission ONLY when the user
   * explicitly clicks "Voice Input". Uses browser Web Speech API when available,
   * or falls back cleanly to MediaRecorder + server-side Gemini 3.5 Transcribe.
   */
  const handleToggleVoiceInput = async () => {
    setVoiceFeedback(null);

    // Stop active recording if already listening
    if (isListening && mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsListening(false);
      return;
    }

    // Prefer native browser SpeechRecognition if supported
    const win = window as unknown as {
      SpeechRecognition?: new () => {
        lang: string;
        interimResults: boolean;
        maxAlternatives: number;
        onresult: (event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
        onerror: (event: { error: string }) => void;
        onend: () => void;
        start: () => void;
      };
      webkitSpeechRecognition?: new () => {
        lang: string;
        interimResults: boolean;
        maxAlternatives: number;
        onresult: (event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
        onerror: (event: { error: string }) => void;
        onend: () => void;
        start: () => void;
      };
    };

    const SpeechRecognitionCtor = win.SpeechRecognition || win.webkitSpeechRecognition;

    if (SpeechRecognitionCtor) {
      try {
        const recognition = new SpeechRecognitionCtor();
        recognition.lang = 'en-US';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;
        setIsListening(true);
        setVoiceFeedback('Listening... Speak a question or command like "What is the submission deadline?"');

        recognition.onresult = (event) => {
          const spoken = event.results[0]?.[0]?.transcript?.trim() ?? '';
          if (spoken) {
            setQuestion(spoken);
            setVoiceFeedback(`Heard: "${spoken}"`);
            void executeCommandOrQuestion(spoken);
          }
        };
        recognition.onerror = (event) => {
          setIsListening(false);
          setVoiceFeedback(
            event.error === 'not-allowed'
              ? 'Microphone permission was denied. You can type your question below at any time.'
              : 'Voice recognition could not hear speech clearly. Try again or type your question.'
          );
        };
        recognition.onend = () => {
          setIsListening(false);
        };
        recognition.start();
        return;
      } catch {
        setIsListening(false);
      }
    }

    // Fallback: record short audio clip and send to /api/transcribe (Gemini 3.5 Transcribe)
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
      setVoiceFeedback(
        'Voice input is not supported in this browser. Use the accessible text input box below.'
      );
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (evt) => {
        if (evt.data.size > 0) audioChunksRef.current.push(evt.data);
      };

      recorder.onstop = async () => {
        stream.getTracks().forEach((track) => track.stop());
        const blob = new Blob(audioChunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        setVoiceFeedback('Transcribing spoken command...');
        try {
          const formData = new FormData();
          formData.append('audio', blob, 'voice-command.webm');
          const res = await fetch('/api/transcribe', { method: 'POST', body: formData });
          const payload = (await res.json().catch(() => ({}))) as {
            transcript?: string;
            error?: string;
          };
          if (!res.ok || !payload.transcript) {
            throw new Error(payload.error || 'Could not transcribe audio.');
          }
          setQuestion(payload.transcript);
          setVoiceFeedback(`Transcribed: "${payload.transcript}"`);
          await executeCommandOrQuestion(payload.transcript);
        } catch (err) {
          setVoiceFeedback(
            err instanceof Error ? err.message : 'Transcription failed. Please type your question.'
          );
        }
      };

      recorder.start();
      setIsListening(true);
      setVoiceFeedback('Recording voice command... Click "Stop Voice" when finished.');
    } catch {
      setVoiceFeedback(
        'Microphone access was blocked or unavailable. Use the text input below instead.'
      );
    }
  };

  return (
    <section aria-labelledby="qa-heading" className="space-y-6">
      <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5">
        <h2 id="qa-heading" className="text-lg font-semibold text-[var(--am-text)]">
          Ask Questions & Optional Voice Interaction
        </h2>
        <p className="mt-1 text-sm text-[var(--am-text-muted)]">
          Answers are strictly grounded in {document.fileName}. If an answer is not in your document, ACCESSMATE tells you honestly instead of guessing.
        </p>

        <form onSubmit={handleSubmit} className="mt-4 space-y-3">
          <div>
            <label htmlFor="document-qa-input" className="block text-xs font-semibold text-[var(--am-text-secondary)]">
              Type a question or voice command
            </label>
            <div className="mt-1.5 flex flex-wrap gap-2">
              <input
                id="document-qa-input"
                type="text"
                value={question}
                disabled={isBusy}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder='e.g., "What is the submission deadline?" or "Translate this into Hindi"'
                className="min-h-[44px] flex-1 min-w-[240px] rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3.5 py-2 text-sm text-[var(--am-text)]"
              />
              <button
                type="button"
                disabled={isBusy}
                onClick={handleToggleVoiceInput}
                aria-pressed={isListening}
                className={`inline-flex min-h-[44px] items-center gap-2 rounded-lg border px-4 py-2 text-sm font-medium whitespace-nowrap ${
                  isListening
                    ? 'border-[var(--am-danger)] bg-[var(--am-danger-bg)] text-[var(--am-danger)]'
                    : 'border-[var(--am-border-strong)] bg-[var(--am-surface)] text-[var(--am-text)] hover:bg-[var(--am-surface-muted)]'
                }`}
              >
                {isListening ? (
                  <>
                    <MicOff className="h-4 w-4" aria-hidden="true" />
                    <span>Stop Voice</span>
                  </>
                ) : (
                  <>
                    <Mic className="h-4 w-4 text-[var(--am-accent)]" aria-hidden="true" />
                    <span>Voice Input</span>
                  </>
                )}
              </button>
              <button
                type="submit"
                disabled={isBusy || question.trim().length < 2}
                className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-[var(--am-accent)] px-5 py-2 text-sm font-semibold text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)] whitespace-nowrap disabled:opacity-50"
              >
                {status.phase === 'answering' ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                ) : (
                  <Send className="h-4 w-4" aria-hidden="true" />
                )}
                <span>Ask Document</span>
              </button>
            </div>
          </div>

          <label className="inline-flex cursor-pointer items-center gap-2.5 text-xs text-[var(--am-text-secondary)]">
            <input
              type="checkbox"
              checked={includeSearchContext}
              disabled={isBusy}
              onChange={(e) => setIncludeSearchContext(e.target.checked)}
              className="h-4 w-4 accent-[var(--am-accent)]"
            />
            <span>
              Also attach separate general public reference via Google Search (never mixed into document facts)
            </span>
          </label>
        </form>

        {voiceFeedback && (
          <p role="status" aria-live="polite" className="mt-3 text-xs font-medium text-[var(--am-accent)]">
            {voiceFeedback}
          </p>
        )}

        {/* Quick Questions */}
        <div className="mt-4 flex flex-wrap gap-2">
          {SUGGESTED_QUESTIONS.map((q) => (
            <button
              key={q}
              type="button"
              disabled={isBusy}
              onClick={() => void executeCommandOrQuestion(q)}
              className="min-h-[34px] rounded-lg border border-[var(--am-border)] bg-[var(--am-surface-muted)] px-3 py-1.5 text-xs font-medium text-[var(--am-text-secondary)] hover:border-[var(--am-accent)] hover:text-[var(--am-text)]"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Q&A Transcript */}
      {qaMessages.length === 0 ? (
        <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6 text-sm text-[var(--am-text-muted)]">
          Ask any question about dates, eligibility, required forms, or definitions. Every answer cites supporting quotes from your document.
        </div>
      ) : (
        <div className="space-y-4">
          {qaMessages.map((msg) => (
            <article
              key={msg.id}
              className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5 space-y-4"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--am-border)] pb-3">
                <h3 className="text-sm font-semibold text-[var(--am-text)]">Q: {msg.question}</h3>
                <span className="font-mono-tabular text-xs text-[var(--am-text-muted)]">
                  {msg.response.foundInDocument ? 'Grounded in document' : 'Not stated in document'} · {msg.durationMs} ms
                </span>
              </div>

              <div>
                <p className="text-xs font-semibold text-[var(--am-accent)]">
                  Document-Grounded Answer
                </p>
                <p className="mt-1 text-sm text-[var(--am-text)]">{msg.response.directAnswer}</p>
              </div>

              {msg.response.quotedEvidence.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-[var(--am-text-muted)]">
                    Quoted Document Evidence
                  </p>
                  {msg.response.quotedEvidence.map((ev, idx) => (
                    <blockquote
                      key={idx}
                      className="rounded-lg bg-[var(--am-surface-muted)] px-3.5 py-2.5 text-xs text-[var(--am-text-secondary)]"
                    >
                      &ldquo;{ev.excerpt}&rdquo;
                      {ev.pageNumber ? ` (Page ${ev.pageNumber})` : ''}
                    </blockquote>
                  ))}
                </div>
              )}

              {msg.response.generalExplanation && (
                <div className="rounded-lg border border-[var(--am-border)] bg-[var(--am-surface-muted)] p-3.5 text-xs text-[var(--am-text-secondary)]">
                  <strong className="text-[var(--am-text)]">
                    General Plain-Language Note (Not from your document):
                  </strong>{' '}
                  {msg.response.generalExplanation}
                </div>
              )}

              {msg.response.externalWebContext && (
                <div className="rounded-lg border border-[var(--am-border)] bg-[var(--am-surface-muted)] p-4 text-xs">
                  <div className="flex items-center gap-1.5 font-semibold text-[var(--am-text)]">
                    <Globe className="h-3.5 w-3.5 text-[var(--am-accent)]" aria-hidden="true" />
                    <span>External Public Web Reference (Google Search Grounding)</span>
                  </div>
                  <p className="mt-1.5 text-[var(--am-text-secondary)]">
                    {msg.response.externalWebContext.summary}
                  </p>
                  {msg.response.externalWebContext.sources.length > 0 && (
                    <ul className="mt-2 space-y-1">
                      {msg.response.externalWebContext.sources
                        .filter((s) => isSafeHttpUrl(s.uri))
                        .map((src, idx) => (
                          <li key={idx}>
                            <a
                              href={src.uri}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-[var(--am-accent)] underline"
                            >
                              <span>{src.title}</span>
                              <ExternalLink className="h-3 w-3" aria-hidden="true" />
                            </a>
                          </li>
                        ))}
                    </ul>
                  )}
                </div>
              )}
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
