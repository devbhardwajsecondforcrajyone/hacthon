'use client';

import React from 'react';
import { AlertCircle, Globe, Loader2 } from 'lucide-react';
import { SUPPORTED_LANGUAGES } from '@/lib/config';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';

export function TranslationPanel() {
  const {
    document,
    analysis,
    selectedLanguageCode,
    translation,
    translateToLanguage,
    status,
    errorMessage,
    setActiveNav,
  } = useDocumentSession();

  if (!document || !analysis) {
    return (
      <section className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-8 text-center">
        <Globe className="mx-auto h-8 w-8 text-[var(--am-accent)]" aria-hidden="true" />
        <h2 className="mt-3 text-lg font-semibold text-[var(--am-text)]">
          Upload a Document to Translate It
        </h2>
        <p className="mt-1 text-sm text-[var(--am-text-muted)]">
          ACCESSMATE translates simplified explanations, key warnings, deadlines, and checklists into 13 languages including Hindi, Bengali, Tamil, Arabic (RTL), French, and Spanish.
        </p>
        <button
          type="button"
          onClick={() => setActiveNav('dashboard')}
          className="mt-4 min-h-[42px] rounded-lg bg-[var(--am-accent)] px-5 py-2 text-sm font-semibold text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)]"
        >
          Go to Upload Dashboard
        </button>
      </section>
    );
  }

  const isTranslating = status.phase === 'translating';
  const dir = translation?.direction ?? 'ltr';

  return (
    <section aria-labelledby="translation-heading" className="space-y-6">
      <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 id="translation-heading" className="text-lg font-semibold text-[var(--am-text)]">
              Multilingual Translation
            </h2>
            <p className="mt-1 text-sm text-[var(--am-text-muted)]">
              Choose your preferred language. Exact numbers, dates, monetary values, and official names are preserved.
            </p>
          </div>

          <div className="min-w-[220px]">
            <label
              htmlFor="language-selector"
              className="block text-xs font-semibold text-[var(--am-text-secondary)]"
            >
              Target Language
            </label>
            <select
              id="language-selector"
              value={selectedLanguageCode}
              disabled={isTranslating}
              onChange={(e) => void translateToLanguage(e.target.value)}
              className="mt-1.5 min-h-[42px] w-full rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3 py-2 text-sm text-[var(--am-text)]"
            >
              {SUPPORTED_LANGUAGES.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.name} ({lang.nativeName}){lang.dir === 'rtl' ? ' — RTL' : ''}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick-select language buttons */}
        <div className="mt-4 flex flex-wrap gap-2" role="group" aria-label="Quick language buttons">
          {SUPPORTED_LANGUAGES.map((lang) => {
            const active = selectedLanguageCode === lang.code;
            return (
              <button
                key={lang.code}
                type="button"
                disabled={isTranslating}
                aria-pressed={active}
                onClick={() => void translateToLanguage(lang.code)}
                className={`min-h-[36px] rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'border-[var(--am-accent)] bg-[var(--am-accent-soft)] text-[var(--am-accent)] font-semibold'
                    : 'border-[var(--am-border)] bg-[var(--am-surface)] text-[var(--am-text-secondary)] hover:bg-[var(--am-surface-muted)]'
                }`}
              >
                {lang.name} · {lang.nativeName}
              </button>
            );
          })}
        </div>
      </div>

      {isTranslating && (
        <div
          role="status"
          aria-live="polite"
          className="flex items-center gap-3 rounded-xl border border-[var(--am-accent)] bg-[var(--am-accent-soft)] p-5 text-sm font-medium text-[var(--am-text)]"
        >
          <Loader2 className="h-4 w-4 animate-spin text-[var(--am-accent)]" aria-hidden="true" />
          <span>{status.message}</span>
        </div>
      )}

      {errorMessage && (
        <div
          role="alert"
          className="flex items-start gap-2.5 rounded-xl border border-[var(--am-danger)] bg-[var(--am-danger-bg)] p-4 text-sm text-[var(--am-danger)]"
        >
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
          <div>
            <p className="font-semibold">Translation could not be completed</p>
            <p className="mt-0.5">{errorMessage} The original summary remains visible below.</p>
          </div>
        </div>
      )}

      {/* Translated Output or Original English Fallback */}
      {translation ? (
        <div
          dir={dir}
          lang={translation.targetLanguageCode}
          className="space-y-5 rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6"
        >
          <div className="border-b border-[var(--am-border)] pb-4">
            <div className="text-xs text-[var(--am-text-muted)]">
              {translation.targetLanguageName} · {dir === 'rtl' ? 'Right-to-Left (RTL)' : 'Left-to-Right'}
            </div>
            <p className="mt-2 rounded-lg border border-[var(--am-warning)] bg-[var(--am-warning-bg)] p-3 text-xs text-[var(--am-text)]">
              {translation.disclaimer}
            </p>
          </div>

          <div>
            <h3 className="text-base font-semibold text-[var(--am-text)]">Overview</h3>
            <p className="mt-2 text-sm text-[var(--am-text-secondary)]">
              {translation.documentOverview}
            </p>
          </div>

          <div className="border-t border-[var(--am-border)] pt-4">
            <h3 className="text-base font-semibold text-[var(--am-text)]">Simplified Summary</h3>
            <p className="mt-2 whitespace-pre-line text-sm text-[var(--am-text)]">
              {translation.summary}
            </p>
          </div>

          {translation.importantInstructions.length > 0 && (
            <div className="border-t border-[var(--am-border)] pt-4">
              <h3 className="text-base font-semibold text-[var(--am-text)]">
                Important Instructions
              </h3>
              <ul className="mt-2 space-y-2 text-sm text-[var(--am-text)]">
                {translation.importantInstructions.map((inst, idx) => (
                  <li key={idx}>• {inst}</li>
                ))}
              </ul>
            </div>
          )}

          {translation.importantWarnings.length > 0 && (
            <div className="border-t border-[var(--am-border)] pt-4">
              <h3 className="text-base font-semibold text-[var(--am-warning)]">
                Important Warnings
              </h3>
              <ul className="mt-2 space-y-2 text-sm text-[var(--am-text)]">
                {translation.importantWarnings.map((warn, idx) => (
                  <li key={idx}>• {warn}</li>
                ))}
              </ul>
            </div>
          )}

          {translation.checklistItems.length > 0 && (
            <div className="border-t border-[var(--am-border)] pt-4">
              <h3 className="text-base font-semibold text-[var(--am-text)]">
                Translated Action Checklist
              </h3>
              <ul className="mt-3 space-y-3">
                {translation.checklistItems.map((item) => (
                  <li
                    key={item.id}
                    className="rounded-lg border border-[var(--am-border)] bg-[var(--am-surface-muted)] p-3.5 text-sm"
                  >
                    <div className="font-semibold text-[var(--am-text)]">{item.title}</div>
                    <p className="mt-1 text-xs text-[var(--am-text-secondary)]">
                      {item.explanation}
                    </p>
                    {item.dueDate && (
                      <p className="mt-1 font-mono-tabular text-xs text-[var(--am-accent)]">
                        {item.dueDate}
                      </p>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      ) : (
        <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6">
          <p className="text-xs text-[var(--am-text-muted)]">
            Currently viewing original language ({analysis.detectedLanguage}). Select any language above to generate a translated explanation and checklist.
          </p>
          <p className="mt-3 text-sm text-[var(--am-text)]">{analysis.summary}</p>
        </div>
      )}
    </section>
  );
}
