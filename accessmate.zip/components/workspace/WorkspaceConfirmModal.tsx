'use client';

import React, { useEffect, useRef } from 'react';
import { X } from 'lucide-react';

interface WorkspaceConfirmModalProps {
  open: boolean;
  title: string;
  description: string;
  items?: string[];
  confirmLabel: string;
  cancelLabel?: string;
  destructive?: boolean;
  busy?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export function WorkspaceConfirmModal({
  open,
  title,
  description,
  items = [],
  confirmLabel,
  cancelLabel = 'Cancel',
  destructive = false,
  busy = false,
  onConfirm,
  onCancel,
}: WorkspaceConfirmModalProps) {
  const cancelBtnRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    if (!open) return;
    cancelBtnRef.current?.focus();
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !busy) {
        onCancel();
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [open, busy, onCancel]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
      role="presentation"
      onClick={() => {
        if (!busy) onCancel();
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="confirm-modal-title"
        aria-describedby="confirm-modal-desc"
        className="w-full max-w-lg rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6 text-[var(--am-text)]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4">
          <h2 id="confirm-modal-title" className="text-lg font-semibold">
            {title}
          </h2>
          <button
            type="button"
            onClick={onCancel}
            disabled={busy}
            aria-label="Close confirmation dialog"
            className="rounded-lg p-2 text-[var(--am-text-muted)] hover:bg-[var(--am-surface-muted)] hover:text-[var(--am-text)]"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        <p id="confirm-modal-desc" className="mt-3 text-sm text-[var(--am-text-secondary)]">
          {description}
        </p>

        {items.length > 0 && (
          <ul className="mt-4 max-h-48 space-y-1.5 overflow-y-auto rounded-lg border border-[var(--am-border)] bg-[var(--am-surface-muted)] p-3 text-sm">
            {items.map((item, idx) => (
              <li key={idx} className="text-[var(--am-text)]">
                • {item}
              </li>
            ))}
          </ul>
        )}

        <div className="mt-6 flex flex-wrap items-center justify-end gap-3">
          <button
            ref={cancelBtnRef}
            type="button"
            onClick={onCancel}
            disabled={busy}
            className="min-h-[42px] rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-4 py-2 text-sm font-medium text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={busy}
            className={`min-h-[42px] rounded-lg px-4 py-2 text-sm font-semibold transition-colors whitespace-nowrap disabled:opacity-60 ${
              destructive
                ? 'bg-[var(--am-danger)] text-white hover:opacity-90'
                : 'bg-[var(--am-accent)] text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)]'
            }`}
          >
            {busy ? 'Working...' : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
