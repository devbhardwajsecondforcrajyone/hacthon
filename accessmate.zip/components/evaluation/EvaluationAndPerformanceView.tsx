'use client';

import React, { useState } from 'react';
import { CheckCircle2, FlaskConical, Loader2, Play, XCircle } from 'lucide-react';
import {
  evaluateAnalysisAgainstGroundTruth,
  SYNTHETIC_GROUND_TRUTH_DOCUMENTS,
  type EvaluationReport,
  type GroundTruthDocument,
} from '@/lib/document/evaluation';
import type { AnalyzeApiResponse } from '@/lib/types';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';

export function EvaluationAndPerformanceView() {
  const { metrics, announce } = useDocumentSession();
  const [runningId, setRunningId] = useState<string | null>(null);
  const [reports, setReports] = useState<Record<string, EvaluationReport>>({});
  const [evalError, setEvalError] = useState<string | null>(null);

  const runLiveEvaluation = async (doc: GroundTruthDocument) => {
    setRunningId(doc.id);
    setEvalError(null);
    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileName: doc.fileName,
          fullText: doc.text,
          pages: [{ pageNumber: 1, text: doc.text, charCount: doc.text.length }],
          readingLevel: 'simple',
          deepReasoning: false,
        }),
      });

      const payload = (await res.json().catch(() => ({}))) as Partial<AnalyzeApiResponse> & {
        error?: string;
      };
      if (!res.ok || !payload.analysis) {
        throw new Error(payload.error || 'Evaluation request failed.');
      }

      const report = evaluateAnalysisAgainstGroundTruth(doc, payload.analysis);
      setReports((prev) => ({ ...prev, [doc.id]: report }));
      announce(
        `Evaluated ${doc.title}: ${report.passedChecks} of ${report.totalChecks} checks passed.`
      );
    } catch (error) {
      setEvalError(error instanceof Error ? error.message : 'Evaluation failed.');
    } finally {
      setRunningId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* AI Accuracy Evaluation Engine */}
      <section className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[var(--am-border)] pb-5">
          <div>
            <div className="flex items-center gap-2">
              <FlaskConical className="h-5 w-5 text-[var(--am-accent)]" aria-hidden="true" />
              <h1 className="text-2xl font-bold text-[var(--am-text)]">
                AI Accuracy Evaluation Engine & Performance Report
              </h1>
            </div>
            <p className="mt-1 text-sm text-[var(--am-text-muted)]">
              Run real, live evaluations against synthetic ground-truth documents to verify citation grounding, deadline extraction, ambiguous date honesty, and prompt-injection defense. No metrics are fabricated.
            </p>
          </div>
        </div>

        {evalError && (
          <div
            role="alert"
            className="mt-4 rounded-lg border border-[var(--am-danger)] bg-[var(--am-danger-bg)] p-4 text-sm text-[var(--am-danger)]"
          >
            {evalError}
          </div>
        )}

        <div className="mt-5 grid gap-4 md:grid-cols-2">
          {SYNTHETIC_GROUND_TRUTH_DOCUMENTS.map((doc) => {
            const report = reports[doc.id];
            const isRunning = runningId === doc.id;
            return (
              <article
                key={doc.id}
                className="flex flex-col justify-between rounded-xl border border-[var(--am-border)] bg-[var(--am-surface-muted)] p-4"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 text-xs text-[var(--am-text-muted)]">
                    <span className="capitalize">{doc.category.replace('_', ' ')}</span>
                    <span className="font-mono-tabular">{doc.text.length} chars</span>
                  </div>
                  <h2 className="mt-1 text-base font-semibold text-[var(--am-text)]">
                    {doc.title}
                  </h2>
                  <p className="mt-1 text-xs text-[var(--am-text-secondary)]">
                    {doc.description}
                  </p>
                </div>

                {report && (
                  <div className="mt-4 space-y-2 border-t border-[var(--am-border)] pt-3">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="text-[var(--am-text)]">
                        Checks Passed: {report.passedChecks}/{report.totalChecks}
                      </span>
                      <span className="font-mono-tabular text-[var(--am-accent)]">
                        Grounding: {report.citationVerificationRate}%
                      </span>
                    </div>
                    <ul className="space-y-1.5 text-xs">
                      {report.checks.map((chk, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          {chk.passed ? (
                            <CheckCircle2
                              className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[var(--am-success)]"
                              aria-hidden="true"
                            />
                          ) : (
                            <XCircle
                              className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[var(--am-danger)]"
                              aria-hidden="true"
                            />
                          )}
                          <span>
                            <strong className="text-[var(--am-text)]">{chk.checkName}:</strong>{' '}
                            <span className="text-[var(--am-text-secondary)]">{chk.details}</span>
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="mt-4 pt-2">
                  <button
                    type="button"
                    disabled={runningId !== null}
                    onClick={() => void runLiveEvaluation(doc)}
                    className="inline-flex min-h-[40px] w-full items-center justify-center gap-2 rounded-lg bg-[var(--am-accent)] px-4 py-2 text-xs font-semibold text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)] disabled:opacity-50"
                  >
                    {isRunning ? (
                      <>
                        <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                        <span>Running Live Evaluation...</span>
                      </>
                    ) : (
                      <>
                        <Play className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>{report ? 'Re-Run Evaluation' : 'Run Live Ground-Truth Eval'}</span>
                      </>
                    )}
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* Real Measured Session Performance Table */}
      <section className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6">
        <h2 className="text-lg font-semibold text-[var(--am-text)]">
          Real Session Performance Telemetry
        </h2>
        <p className="mt-1 text-sm text-[var(--am-text-muted)]">
          Actual processing times, chunk counts, and session cache hits recorded during your current session.
        </p>

        {metrics.length === 0 ? (
          <p className="mt-4 rounded-lg bg-[var(--am-surface-muted)] p-4 text-sm text-[var(--am-text-muted)]">
            No operations measured yet in this session. Upload or paste a document to record real extraction and AI timings.
          </p>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full border-collapse text-left text-sm">
              <thead>
                <tr className="border-b border-[var(--am-border)] text-xs text-[var(--am-text-muted)]">
                  <th className="py-2.5 pr-4 font-semibold">Operation</th>
                  <th className="py-2.5 pr-4 font-semibold">Duration</th>
                  <th className="py-2.5 pr-4 font-semibold">Cache</th>
                  <th className="py-2.5 pr-4 font-semibold">Model</th>
                  <th className="py-2.5 pr-4 font-semibold text-right">Input Size</th>
                  <th className="py-2.5 font-semibold text-right">Output Size</th>
                </tr>
              </thead>
              <tbody>
                {metrics.map((m) => (
                  <tr key={m.id} className="border-b border-[var(--am-border)] last:border-b-0">
                    <td className="py-2.5 pr-4 font-medium capitalize text-[var(--am-text)]">
                      {m.operation}
                      {m.chunksProcessed ? ` (${m.chunksProcessed} chunk${m.chunksProcessed > 1 ? 's' : ''})` : ''}
                    </td>
                    <td className="py-2.5 pr-4 font-mono-tabular text-[var(--am-text)]">
                      {m.durationMs} ms
                    </td>
                    <td className="py-2.5 pr-4 text-xs text-[var(--am-text-secondary)]">
                      {m.cached ? 'Session Cache Hit' : 'Live Run'}
                    </td>
                    <td className="py-2.5 pr-4 font-mono-tabular text-xs text-[var(--am-text-muted)]">
                      {m.modelUsed || 'Local Parser'}
                    </td>
                    <td className="py-2.5 pr-4 text-right font-mono-tabular text-xs text-[var(--am-text-secondary)]">
                      {m.inputChars.toLocaleString()}
                    </td>
                    <td className="py-2.5 text-right font-mono-tabular text-xs text-[var(--am-text-secondary)]">
                      {m.outputChars.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
