'use client';

import React from 'react';
import {
  ArrowRight,
  CalendarClock,
  CheckSquare,
  Eye,
  FileText,
  Languages,
  Shield,
  Volume2,
} from 'lucide-react';
import { APP_CONFIG } from '@/lib/config';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';
import { DocumentUploader } from '@/components/upload/DocumentUploader';
import type { ThemeMode } from '@/lib/types';

export function DashboardView() {
  const { document, analysis, setActiveNav, completedChecklistIds } = useDocumentSession();
  const { prefs, dispatch } = useAccessibility();

  const quickThemes: { id: ThemeMode; label: string }[] = [
    { id: 'light', label: 'Light' },
    { id: 'dark', label: 'Midnight Navy' },
    { id: 'comfortable', label: 'Reading' },
    { id: 'high-contrast', label: 'High Contrast' },
  ];

  return (
    <div className="space-y-8">
      {/* Hero / Why ACCESSMATE Exists */}
      <section className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6 sm:p-8">
        <div className="max-w-3xl">
          <p className="text-sm font-semibold text-[var(--am-accent)]">
            Why ACCESSMATE Exists
          </p>
          <h1 className="mt-2 text-2xl font-bold tracking-tight text-[var(--am-text)] sm:text-4xl">
            Turn complicated documents into clear, accessible next steps.
          </h1>
          <p className="mt-3 text-base text-[var(--am-text-secondary)]">
            {APP_CONFIG.tagline} Upload notices, application forms, medical instructions, or public-service letters to get verified plain-language explanations, translations across 13 languages, extracted deadlines, audio reading, and an actionable checklist.
          </p>

          <div className="mt-5 flex flex-wrap items-center gap-3">
            {document && analysis ? (
              <button
                type="button"
                onClick={() => setActiveNav('workspace')}
                className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-[var(--am-accent)] px-5 py-2.5 text-sm font-semibold text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)] whitespace-nowrap"
              >
                <span>Resume Active Document</span>
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </button>
            ) : (
              <a
                href="#upload-section-heading"
                className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-[var(--am-accent)] px-5 py-2.5 text-sm font-semibold text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)] whitespace-nowrap"
              >
                <span>Upload or Paste a Document</span>
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            )}
            <button
              type="button"
              onClick={() => setActiveNav('about')}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-4 py-2.5 text-sm font-medium text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap"
            >
              <span>How the 12-Step Journey Works</span>
            </button>
          </div>
        </div>
      </section>

      {/* Main Grid: Upload Workspace + Quick Accessibility & Session Status */}
      <div className="grid gap-6 lg:grid-cols-12">
        <div className="lg:col-span-8">
          <DocumentUploader />
        </div>

        <aside className="space-y-6 lg:col-span-4" aria-label="Session and accessibility shortcuts">
          {/* Active Session Summary Card */}
          <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold text-[var(--am-text)]">Current Session</h2>
              <Shield className="h-4 w-4 text-[var(--am-accent)]" aria-hidden="true" />
            </div>

            {document ? (
              <div className="mt-3 space-y-3">
                <div>
                  <p className="truncate text-sm font-semibold text-[var(--am-text)]">
                    {document.fileName}
                  </p>
                  <p className="mt-0.5 font-mono-tabular text-xs text-[var(--am-text-muted)]">
                    {document.pageCount} page(s) · {document.wordCount.toLocaleString()} words · Extracted in {document.extractionTimeMs} ms
                  </p>
                </div>

                {analysis && (
                  <div className="grid grid-cols-2 gap-3 border-t border-[var(--am-border)] pt-3">
                    <div>
                      <div className="font-mono-tabular text-xl font-bold text-[var(--am-text)]">
                        {analysis.deadlines.length}
                      </div>
                      <div className="text-xs text-[var(--am-text-muted)]">Important Dates</div>
                    </div>
                    <div>
                      <div className="font-mono-tabular text-xl font-bold text-[var(--am-text)]">
                        {completedChecklistIds.size}/{analysis.actionChecklist.length}
                      </div>
                      <div className="text-xs text-[var(--am-text-muted)]">Tasks Completed</div>
                    </div>
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => setActiveNav('workspace')}
                  className="mt-2 min-h-[40px] w-full rounded-lg bg-[var(--am-accent)] px-4 py-2 text-sm font-semibold text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)]"
                >
                  Open Document Workspace
                </button>
              </div>
            ) : (
              <div className="mt-3 text-sm text-[var(--am-text-muted)]">
                <p>No document loaded in this session.</p>
                <p className="mt-2 text-xs">
                  Documents are processed strictly in temporary session memory and never persisted to a server database by default.
                </p>
              </div>
            )}
          </div>

          {/* Quick Accessibility Controls */}
          <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold text-[var(--am-text)]">
                Quick Accessibility Controls
              </h2>
              <Eye className="h-4 w-4 text-[var(--am-accent)]" aria-hidden="true" />
            </div>

            <div className="mt-4 space-y-4">
              <div>
                <p className="text-xs font-medium text-[var(--am-text-secondary)]">Display Theme</p>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  {quickThemes.map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      aria-pressed={prefs.theme === t.id}
                      onClick={() => dispatch({ type: 'SET_THEME', theme: t.id })}
                      className={`min-h-[38px] rounded-lg border px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                        prefs.theme === t.id
                          ? 'border-[var(--am-accent)] bg-[var(--am-accent-soft)] text-[var(--am-accent)] font-semibold'
                          : 'border-[var(--am-border)] bg-[var(--am-surface)] text-[var(--am-text)] hover:bg-[var(--am-surface-muted)]'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between border-t border-[var(--am-border)] pt-3">
                <span className="text-xs font-medium text-[var(--am-text-secondary)]">
                  Reduced Motion
                </span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={prefs.reducedMotion}
                  onClick={() => dispatch({ type: 'TOGGLE_REDUCED_MOTION' })}
                  className={`min-h-[34px] rounded-lg border px-3 py-1 text-xs font-semibold ${
                    prefs.reducedMotion
                      ? 'border-[var(--am-accent)] bg-[var(--am-accent)] text-[var(--am-accent-ink)]'
                      : 'border-[var(--am-border-strong)] bg-[var(--am-surface)] text-[var(--am-text)]'
                  }`}
                >
                  {prefs.reducedMotion ? 'On' : 'Off'}
                </button>
              </div>

              <button
                type="button"
                onClick={() => setActiveNav('accessibility')}
                className="min-h-[40px] w-full rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3 py-2 text-xs font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)]"
              >
                Open Full Accessibility Control Center
              </button>
            </div>
          </div>
        </aside>
      </div>

      {/* Problem-to-Action Workflow Overview */}
      <section aria-labelledby="capabilities-heading" className="border-t border-[var(--am-border)] pt-6">
        <h2 id="capabilities-heading" className="text-lg font-semibold text-[var(--am-text)]">
          From Receiving a Document to Knowing Exactly What to Do
        </h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-4">
            <FileText className="h-5 w-5 text-[var(--am-accent)]" aria-hidden="true" />
            <h3 className="mt-3 text-sm font-semibold text-[var(--am-text)]">
              01. Plain-Language Clarity
            </h3>
            <p className="mt-1 text-xs text-[var(--am-text-muted)]">
              Switch between Simple, Standard, and Detailed views with side-by-side original comparison and verbatim source quotes.
            </p>
          </div>
          <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-4">
            <Languages className="h-5 w-5 text-[var(--am-accent)]" aria-hidden="true" />
            <h3 className="mt-3 text-sm font-semibold text-[var(--am-text)]">
              02. 13-Language Access
            </h3>
            <p className="mt-1 text-xs text-[var(--am-text-muted)]">
              Translate summaries, warnings, and checklists across English, Indian languages, French, Spanish, and Arabic (RTL).
            </p>
          </div>
          <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-4">
            <CalendarClock className="h-5 w-5 text-[var(--am-accent)]" aria-hidden="true" />
            <h3 className="mt-3 text-sm font-semibold text-[var(--am-text)]">
              03. Verified Deadlines & Tasks
            </h3>
            <p className="mt-1 text-xs text-[var(--am-text-muted)]">
              Separates publication dates from real deadlines, flags ambiguous dates, and generates a traceable action checklist.
            </p>
          </div>
          <div className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-4">
            <Volume2 className="h-5 w-5 text-[var(--am-accent)]" aria-hidden="true" />
            <h3 className="mt-3 text-sm font-semibold text-[var(--am-text)]">
              04. Audio & Voice Access
            </h3>
            <p className="mt-1 text-xs text-[var(--am-text-muted)]">
              Listen to any section with speed controls and active section highlighting, or ask follow-up questions by text or voice.
            </p>
          </div>
        </div>
        <div className="mt-4 flex items-center gap-2 text-xs text-[var(--am-text-muted)]">
          <CheckSquare className="h-4 w-4 text-[var(--am-accent)] shrink-0" aria-hidden="true" />
          <span>
            Every extracted deadline and action item links directly back to its source quote and page number.
          </span>
        </div>
      </section>
    </div>
  );
}
