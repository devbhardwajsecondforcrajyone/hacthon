'use client';

import React, { useState } from 'react';
import {
  BookOpen,
  CheckSquare,
  FileText,
  FlaskConical,
  Info,
  Languages,
  LayoutDashboard,
  Menu,
  SlidersHorizontal,
  Trash2,
  X,
} from 'lucide-react';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import type { NavSection } from '@/lib/types';
import { WorkspaceConfirmModal } from '@/components/workspace/WorkspaceConfirmModal';

const NAV_ITEMS: readonly {
  id: NavSection;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'workspace', label: 'Understand Document', icon: FileText },
  { id: 'translations', label: 'Translations', icon: Languages },
  { id: 'checklist', label: 'Action Checklist', icon: CheckSquare },
  { id: 'accessibility', label: 'Accessibility Settings', icon: SlidersHorizontal },
  { id: 'evaluation', label: 'Verification & Quality', icon: FlaskConical },
  { id: 'about', label: 'About ACCESSMATE', icon: Info },
];

const SECTION_LABELS: Record<NavSection, string> = {
  dashboard: 'Dashboard',
  workspace: 'Understand Document',
  translations: 'Multilingual Translations',
  checklist: 'Action Checklist',
  accessibility: 'Accessibility Control Center',
  evaluation: 'Verification & Quality Report',
  about: 'About ACCESSMATE',
};

export function AppShell({ children }: { children: React.ReactNode }) {
  const {
    activeNav,
    setActiveNav,
    document,
    analysis,
    completedChecklistIds,
    clearSession,
    announcement,
  } = useDocumentSession();
  const { prefs, dispatch } = useAccessibility();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);

  const remainingTasks = analysis
    ? Math.max(0, analysis.actionChecklist.length - completedChecklistIds.size)
    : 0;

  const handleSelectNav = (nav: NavSection) => {
    setActiveNav(nav);
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-[var(--am-bg)] text-[var(--am-text)]">
      {/* Screen-reader live announcement region */}
      <div className="sr-only" role="status" aria-live="polite" aria-atomic="true">
        {announcement}
      </div>

      {/* Desktop Left Sidebar */}
      <aside
        aria-label="Primary navigation"
        className="no-print fixed inset-y-0 left-0 z-30 hidden w-[264px] flex-col border-r border-[var(--am-border)] bg-[var(--am-surface)] lg:flex"
      >
        <div className="flex h-16 items-center gap-2.5 border-b border-[var(--am-border)] px-5">
          <BookOpen className="h-5 w-5 text-[var(--am-accent)] shrink-0" aria-hidden="true" />
          <span className="font-display text-lg font-bold tracking-tight text-[var(--am-text)] whitespace-nowrap">
            ACCESSMATE
          </span>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4" aria-label="Main sections">
          <ul className="space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isCurrent = activeNav === item.id;
              return (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => handleSelectNav(item.id)}
                    aria-current={isCurrent ? 'page' : undefined}
                    className={`flex min-h-[42px] w-full items-center justify-between gap-3 rounded-lg px-3.5 py-2 text-left text-sm font-medium transition-colors whitespace-nowrap ${
                      isCurrent
                        ? 'bg-[var(--am-accent-soft)] text-[var(--am-accent)] font-semibold'
                        : 'text-[var(--am-text-secondary)] hover:bg-[var(--am-surface-muted)] hover:text-[var(--am-text)]'
                    }`}
                  >
                    <span className="flex items-center gap-3 truncate">
                      <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                      <span className="truncate">{item.label}</span>
                    </span>
                    {item.id === 'checklist' && analysis && (
                      <span className="font-mono-tabular text-xs text-[var(--am-text-muted)]">
                        {remainingTasks}/{analysis.actionChecklist.length}
                      </span>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Active session status & quick font controls in sidebar footer */}
        <div className="border-t border-[var(--am-border)] p-4 pb-14 space-y-3">
          <div className="flex items-center justify-between text-xs text-[var(--am-text-muted)]">
            <span>Text Size</span>
            <span className="font-mono-tabular">{Math.round(prefs.fontScale * 100)}%</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => dispatch({ type: 'DECREASE_FONT' })}
              aria-label="Decrease text size"
              className="flex-1 min-h-[38px] rounded-lg border border-[var(--am-border)] bg-[var(--am-surface)] px-3 py-1.5 text-sm font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)]"
            >
              A-
            </button>
            <button
              type="button"
              onClick={() => dispatch({ type: 'INCREASE_FONT' })}
              aria-label="Increase text size"
              className="flex-1 min-h-[38px] rounded-lg border border-[var(--am-border)] bg-[var(--am-surface)] px-3 py-1.5 text-sm font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)]"
            >
              A+
            </button>
          </div>
          <p className="text-xs text-[var(--am-text-muted)]">
            {prefs.privacyMode
              ? 'Privacy Mode active · Session-only memory'
              : 'Standard session · No server storage'}
          </p>
        </div>
      </aside>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div
          className="no-print fixed inset-0 z-40 bg-black/60 lg:hidden"
          role="presentation"
          onClick={() => setMobileMenuOpen(false)}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-label="Navigation menu"
            className="flex h-full w-[280px] flex-col bg-[var(--am-surface)] border-r border-[var(--am-border)]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex h-16 items-center justify-between border-b border-[var(--am-border)] px-5">
              <span className="font-display text-lg font-bold">ACCESSMATE</span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close navigation menu"
                className="rounded-lg p-2 text-[var(--am-text-muted)] hover:bg-[var(--am-surface-muted)]"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto px-3 py-4" aria-label="Mobile sections">
              <ul className="space-y-1">
                {NAV_ITEMS.map((item) => {
                  const Icon = item.icon;
                  const isCurrent = activeNav === item.id;
                  return (
                    <li key={item.id}>
                      <button
                        type="button"
                        onClick={() => handleSelectNav(item.id)}
                        aria-current={isCurrent ? 'page' : undefined}
                        className={`flex min-h-[44px] w-full items-center gap-3 rounded-lg px-3.5 py-2.5 text-left text-sm font-medium ${
                          isCurrent
                            ? 'bg-[var(--am-accent-soft)] text-[var(--am-accent)] font-semibold'
                            : 'text-[var(--am-text-secondary)] hover:bg-[var(--am-surface-muted)]'
                        }`}
                      >
                        <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                        <span>{item.label}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </nav>
          </div>
        </div>
      )}

      {/* Main Column */}
      <div className="flex min-h-screen flex-col lg:pl-[264px]">
        {/* Top Bar (Clean single row, breadcrumb + primary session action) */}
        <header className="no-print sticky top-0 z-20 flex h-16 items-center justify-between gap-4 border-b border-[var(--am-border)] bg-[var(--am-surface)] px-4 sm:px-6 lg:px-8">
          <div className="flex min-w-0 items-center gap-3">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation menu"
              className="inline-flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg border border-[var(--am-border)] text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] lg:hidden"
            >
              <Menu className="h-5 w-5" aria-hidden="true" />
            </button>
            <nav aria-label="Breadcrumb" className="flex min-w-0 items-center gap-2 text-sm">
              <span className="font-semibold text-[var(--am-text)] whitespace-nowrap">
                {SECTION_LABELS[activeNav]}
              </span>
              {document && (
                <>
                  <span aria-hidden="true" className="text-[var(--am-text-muted)]">
                    /
                  </span>
                  <span
                    className="truncate max-w-[180px] sm:max-w-[320px] text-[var(--am-text-muted)]"
                    title={document.fileName}
                  >
                    {document.fileName}
                  </span>
                </>
              )}
            </nav>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {document ? (
              <button
                type="button"
                onClick={() => setDeleteModalOpen(true)}
                className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3.5 py-2 text-sm font-medium text-[var(--am-danger)] hover:bg-[var(--am-danger-bg)] whitespace-nowrap shrink-0"
              >
                <Trash2 className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span className="hidden sm:inline">Delete Document</span>
                <span className="sm:hidden">Clear</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setActiveNav('accessibility')}
                className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-3.5 py-2 text-sm font-medium text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap shrink-0"
              >
                <SlidersHorizontal className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Display Settings</span>
              </button>
            )}
          </div>
        </header>

        {/* Main Viewport */}
        <main
          id="main-content"
          tabIndex={-1}
          className="mx-auto w-full max-w-[1160px] flex-1 px-4 py-6 sm:px-6 lg:px-8 lg:py-8 focus:outline-none"
        >
          {children}
        </main>
      </div>

      <WorkspaceConfirmModal
        open={deleteModalOpen}
        title="Delete document and clear session?"
        description="This immediately removes the uploaded document, extracted text, AI explanations, translations, checklist progress, and Q&A history from browser memory. ACCESSMATE does not store uploaded documents on a server database."
        confirmLabel="Delete & Clear Session"
        destructive
        onConfirm={() => {
          setDeleteModalOpen(false);
          clearSession();
        }}
        onCancel={() => setDeleteModalOpen(false)}
      />
    </div>
  );
}
