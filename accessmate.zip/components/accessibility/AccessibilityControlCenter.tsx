'use client';

import React from 'react';
import { Eye, Keyboard, RotateCcw, Shield, Type } from 'lucide-react';
import { useAccessibility } from '@/contexts/AccessibilityContext';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';
import type { ThemeMode } from '@/lib/types';

const THEME_OPTIONS: readonly {
  id: ThemeMode;
  label: string;
  description: string;
}[] = [
  {
    id: 'light',
    label: 'High-Clarity Light',
    description: 'Clean white surfaces with deep slate ink and accessible cobalt accents.',
  },
  {
    id: 'dark',
    label: 'Midnight Navy Dark',
    description: 'Low-glare midnight navy canvas with optically compensated bright text.',
  },
  {
    id: 'comfortable',
    label: 'Comfortable Reading',
    description: 'Soft warm paper tone designed to reduce glare during longer reading.',
  },
  {
    id: 'high-contrast',
    label: 'High-Contrast Mode',
    description: 'Pure black background, white ink, crisp borders, and gold focus highlights (WCAG AAA).',
  },
];

export function AccessibilityControlCenter() {
  const { prefs, dispatch } = useAccessibility();
  const { announce } = useDocumentSession();

  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-6">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[var(--am-border)] pb-5">
          <div>
            <h1 className="text-2xl font-bold text-[var(--am-text)]">
              Accessibility Control Center
            </h1>
            <p className="mt-1 text-sm text-[var(--am-text-muted)]">
              Every control below updates the entire interface immediately. Only non-sensitive visual preferences are saved locally in your browser.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              dispatch({ type: 'RESET' });
              announce('Accessibility settings reset to defaults.');
            }}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-4 py-2 text-xs font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)] whitespace-nowrap"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" />
            <span>Reset to Defaults</span>
          </button>
        </div>

        {/* Theme Selection */}
        <fieldset className="mt-6">
          <legend className="flex items-center gap-2 text-base font-semibold text-[var(--am-text)]">
            <Eye className="h-4 w-4 text-[var(--am-accent)]" aria-hidden="true" />
            <span>Visual Theme & Contrast</span>
          </legend>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            {THEME_OPTIONS.map((option) => {
              const active = prefs.theme === option.id;
              return (
                <button
                  key={option.id}
                  type="button"
                  aria-pressed={active}
                  onClick={() => {
                    dispatch({ type: 'SET_THEME', theme: option.id });
                    announce(`Switched display theme to ${option.label}.`);
                  }}
                  className={`rounded-xl border p-4 text-left transition-colors ${
                    active
                      ? 'border-[var(--am-accent)] bg-[var(--am-accent-soft)]'
                      : 'border-[var(--am-border)] bg-[var(--am-surface)] hover:bg-[var(--am-surface-muted)]'
                  }`}
                >
                  <div className="text-sm font-semibold text-[var(--am-text)]">
                    {option.label} {active ? '(Active)' : ''}
                  </div>
                  <p className="mt-1 text-xs text-[var(--am-text-muted)]">{option.description}</p>
                </button>
              );
            })}
          </div>
        </fieldset>

        {/* Typography & Spacing Controls */}
        <div className="mt-8 grid gap-6 border-t border-[var(--am-border)] pt-6 md:grid-cols-2">
          <div>
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 text-base font-semibold text-[var(--am-text)]">
                <Type className="h-4 w-4 text-[var(--am-accent)]" aria-hidden="true" />
                <span>Text Size</span>
              </span>
              <span className="font-mono-tabular text-sm font-semibold text-[var(--am-accent)]">
                {Math.round(prefs.fontScale * 100)}%
              </span>
            </div>
            <p className="mt-1 text-xs text-[var(--am-text-muted)]">
              Scale text smoothly from 85% up to 145% without breaking page layout.
            </p>
            <div className="mt-3 flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => {
                  dispatch({ type: 'DECREASE_FONT' });
                  announce('Decreased font size.');
                }}
                className="min-h-[42px] flex-1 rounded-lg border border-[var(--am-border-strong)] bg-[var(--am-surface)] px-4 py-2 text-sm font-semibold text-[var(--am-text)] hover:bg-[var(--am-surface-muted)]"
              >
                Decrease Text (A-)
              </button>
              <button
                type="button"
                onClick={() => {
                  dispatch({ type: 'INCREASE_FONT' });
                  announce('Increased font size.');
                }}
                className="min-h-[42px] flex-1 rounded-lg bg-[var(--am-accent)] px-4 py-2 text-sm font-semibold text-[var(--am-accent-ink)] hover:bg-[var(--am-accent-hover)]"
              >
                Increase Text (A+)
              </button>
            </div>
          </div>

          <div className="space-y-4">
            <fieldset>
              <legend className="text-sm font-semibold text-[var(--am-text)]">Line Spacing</legend>
              <div className="mt-2 grid grid-cols-3 gap-2">
                {(['normal', 'relaxed', 'spacious'] as const).map((spacing) => (
                  <button
                    key={spacing}
                    type="button"
                    aria-pressed={prefs.lineSpacing === spacing}
                    onClick={() => dispatch({ type: 'SET_LINE_SPACING', spacing })}
                    className={`min-h-[40px] rounded-lg border px-3 py-1.5 text-xs font-medium capitalize ${
                      prefs.lineSpacing === spacing
                        ? 'border-[var(--am-accent)] bg-[var(--am-accent-soft)] text-[var(--am-accent)] font-semibold'
                        : 'border-[var(--am-border)] bg-[var(--am-surface)] text-[var(--am-text)]'
                    }`}
                  >
                    {spacing}
                  </button>
                ))}
              </div>
            </fieldset>

            <fieldset>
              <legend className="text-sm font-semibold text-[var(--am-text)]">
                Letter & Word Spacing
              </legend>
              <div className="mt-2 grid grid-cols-2 gap-2">
                {(['normal', 'wide'] as const).map((spacing) => (
                  <button
                    key={spacing}
                    type="button"
                    aria-pressed={prefs.letterSpacing === spacing}
                    onClick={() => dispatch({ type: 'SET_LETTER_SPACING', spacing })}
                    className={`min-h-[40px] rounded-lg border px-3 py-1.5 text-xs font-medium capitalize ${
                      prefs.letterSpacing === spacing
                        ? 'border-[var(--am-accent)] bg-[var(--am-accent-soft)] text-[var(--am-accent)] font-semibold'
                        : 'border-[var(--am-border)] bg-[var(--am-surface)] text-[var(--am-text)]'
                    }`}
                  >
                    {spacing === 'wide' ? 'Wide (Dyslexia-Friendly)' : 'Standard'}
                  </button>
                ))}
              </div>
            </fieldset>
          </div>
        </div>

        {/* Motion & Privacy Toggles */}
        <div className="mt-8 grid gap-4 border-t border-[var(--am-border)] pt-6 md:grid-cols-2">
          <div className="flex items-center justify-between gap-4 rounded-xl border border-[var(--am-border)] bg-[var(--am-surface-muted)] p-4">
            <div>
              <h2 className="text-sm font-semibold text-[var(--am-text)]">Reduced Motion</h2>
              <p className="mt-0.5 text-xs text-[var(--am-text-muted)]">
                Disables smooth scrolling and transitions across the platform.
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={prefs.reducedMotion}
              onClick={() => {
                dispatch({ type: 'TOGGLE_REDUCED_MOTION' });
                announce(`Reduced motion ${prefs.reducedMotion ? 'disabled' : 'enabled'}.`);
              }}
              className={`min-h-[38px] min-w-[68px] rounded-lg border px-3 py-1.5 text-xs font-semibold ${
                prefs.reducedMotion
                  ? 'border-[var(--am-accent)] bg-[var(--am-accent)] text-[var(--am-accent-ink)]'
                  : 'border-[var(--am-border-strong)] bg-[var(--am-surface)] text-[var(--am-text)]'
              }`}
            >
              {prefs.reducedMotion ? 'On' : 'Off'}
            </button>
          </div>

          <div className="flex items-center justify-between gap-4 rounded-xl border border-[var(--am-border)] bg-[var(--am-surface-muted)] p-4">
            <div>
              <div className="flex items-center gap-1.5">
                <Shield className="h-4 w-4 text-[var(--am-accent)]" aria-hidden="true" />
                <h2 className="text-sm font-semibold text-[var(--am-text)]">
                  Document Privacy Mode
                </h2>
              </div>
              <p className="mt-0.5 text-xs text-[var(--am-text-muted)]">
                Keeps all document text strictly in volatile tab memory with zero persistence.
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={prefs.privacyMode}
              onClick={() => {
                dispatch({ type: 'TOGGLE_PRIVACY_MODE' });
                announce(`Document Privacy Mode ${prefs.privacyMode ? 'off' : 'active'}.`);
              }}
              className={`min-h-[38px] min-w-[68px] rounded-lg border px-3 py-1.5 text-xs font-semibold ${
                prefs.privacyMode
                  ? 'border-[var(--am-accent)] bg-[var(--am-accent)] text-[var(--am-accent-ink)]'
                  : 'border-[var(--am-border-strong)] bg-[var(--am-surface)] text-[var(--am-text)]'
              }`}
            >
              {prefs.privacyMode ? 'Active' : 'Off'}
            </button>
          </div>
        </div>
      </section>

      {/* Live Preview Sample & Keyboard Navigation Guide */}
      <div className="grid gap-6 md:grid-cols-2">
        <section className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5">
          <h2 className="text-base font-semibold text-[var(--am-text)]">Live Reading Preview</h2>
          <p className="mt-2 text-sm text-[var(--am-text-secondary)]">
            Applicants must submit Form HEFA-14 and their official transcript before December 18, 2026 at 5:00 PM EST. Use the text size, spacing, and contrast controls above until this paragraph is effortless to read.
          </p>
        </section>

        <section className="rounded-xl border border-[var(--am-border)] bg-[var(--am-surface)] p-5">
          <div className="flex items-center gap-2">
            <Keyboard className="h-4 w-4 text-[var(--am-accent)]" aria-hidden="true" />
            <h2 className="text-base font-semibold text-[var(--am-text)]">
              Keyboard & Screen Reader Support
            </h2>
          </div>
          <ul className="mt-2.5 space-y-1.5 text-xs text-[var(--am-text-secondary)]">
            <li>• Press Tab on page load to access the &ldquo;Skip to main content&rdquo; link.</li>
            <li>• All tabs, switches, checkboxes, and dialogs support Tab, Space, Enter, and Escape.</li>
            <li>• Status updates, errors, and completions announce automatically via ARIA live regions.</li>
            <li>• Text-to-speech and voice input are strictly optional with complete text alternatives.</li>
          </ul>
        </section>
      </div>
    </div>
  );
}
