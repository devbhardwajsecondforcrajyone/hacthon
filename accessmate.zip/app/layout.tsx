import type { Metadata } from 'next';
import { JetBrains_Mono, Plus_Jakarta_Sans, Public_Sans } from 'next/font/google';
import './globals.css';
import { AccessibilityProvider } from '@/contexts/AccessibilityContext';
import { DocumentSessionProvider } from '@/contexts/DocumentSessionContext';

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['500', '600', '700'],
  variable: '--font-display',
  display: 'swap',
});

const publicSans = Public_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-body',
  display: 'swap',
});

const jetBrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'ACCESSMATE — Universal Document Understanding & Accessibility Platform',
  description:
    'AI-powered universal document understanding and accessibility platform that transforms complex documents into simple language, multilingual translations, verified deadlines, audio reading, and actionable checklists.',
  openGraph: {
    title: 'ACCESSMATE — Universal Document Understanding & Accessibility Platform',
    description:
      'Make complicated documents understandable, accessible, multilingual, and actionable.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'ACCESSMATE — Universal Document Understanding & Accessibility Platform',
    description:
      'Make complicated documents understandable, accessible, multilingual, and actionable.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      className={`${plusJakartaSans.variable} ${publicSans.variable} ${jetBrainsMono.variable}`}
      suppressHydrationWarning
    >
      <body suppressHydrationWarning>
        <a href="#main-content" className="skip-link">
          Skip to main content
        </a>
        <AccessibilityProvider>
          <DocumentSessionProvider>{children}</DocumentSessionProvider>
        </AccessibilityProvider>
      </body>
    </html>
  );
}
