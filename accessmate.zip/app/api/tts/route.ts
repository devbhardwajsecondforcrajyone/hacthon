import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { APP_CONFIG } from '@/lib/config';
import { GeminiServiceError, synthesizeSpeechWithGemini } from '@/lib/server/gemini';
import { getClientRateLimitKey, serverRateLimiter } from '@/lib/server/rate-limit';

const TTSRequestSchema = z.object({
  text: z.string().trim().min(2).max(APP_CONFIG.limits.maxTtsCharacters),
  voiceName: z.enum(['Kore', 'Puck', 'Charon', 'Fenrir', 'Zephyr']).default('Kore'),
  style: z.string().max(180).optional(),
});

export async function POST(req: NextRequest) {
  const rateDecision = serverRateLimiter.check(
    getClientRateLimitKey(req, 'tts'),
    APP_CONFIG.rateLimits.tts
  );
  if (!rateDecision.allowed) {
    return NextResponse.json(
      { error: 'Speech generation rate limit reached. Try browser speech or wait a moment.', code: 'RATE_LIMITED' },
      { status: 429, headers: { 'Retry-After': String(rateDecision.retryAfterSeconds) } }
    );
  }

  try {
    const body = await req.json().catch(() => null);
    const parsed = TTSRequestSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Invalid text-to-speech input.', code: 'INVALID_REQUEST' },
        { status: 400 }
      );
    }

    const result = await synthesizeSpeechWithGemini(parsed.data);
    return NextResponse.json(
      {
        audioBase64: result.base64Wav,
        mimeType: 'audio/wav',
        meta: {
          modelUsed: result.modelUsed,
          durationMs: result.durationMs,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    if (error instanceof GeminiServiceError) {
      return NextResponse.json(
        { error: error.message, code: error.code },
        { status: error.statusCode }
      );
    }
    return NextResponse.json(
      { error: 'AI voice synthesis is temporarily unavailable. Use the built-in browser reader.', code: 'TTS_ERROR' },
      { status: 500 }
    );
  }
}
