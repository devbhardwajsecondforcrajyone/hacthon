import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { APP_CONFIG } from '@/lib/config';
import { answerDocumentQuestionWithGemini, GeminiServiceError } from '@/lib/server/gemini';
import { getClientRateLimitKey, serverRateLimiter } from '@/lib/server/rate-limit';
import { logServerEvent } from '@/lib/server/logger';

const QARequestSchema = z.object({
  question: z
    .string()
    .trim()
    .min(2, 'Please enter a clear question about the document.')
    .max(APP_CONFIG.limits.maxQuestionLength, 'Question is too long.'),
  fullText: z
    .string()
    .min(APP_CONFIG.limits.minMeaningfulCharacters)
    .max(APP_CONFIG.limits.maxTextCharacters + 5000),
  includeSearchContext: z.boolean().default(false),
});

export async function POST(req: NextRequest) {
  const rateDecision = serverRateLimiter.check(
    getClientRateLimitKey(req, 'qa'),
    APP_CONFIG.rateLimits.qa
  );
  if (!rateDecision.allowed) {
    return NextResponse.json(
      { error: 'Too many questions in a short period. Please wait a moment.', code: 'RATE_LIMITED' },
      { status: 429, headers: { 'Retry-After': String(rateDecision.retryAfterSeconds) } }
    );
  }

  try {
    const body = await req.json().catch(() => null);
    const parsed = QARequestSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        {
          error: parsed.error.issues[0]?.message ?? 'Invalid question request.',
          code: 'INVALID_REQUEST',
        },
        { status: 400 }
      );
    }

    const result = await answerDocumentQuestionWithGemini({
      question: parsed.data.question,
      fullText: parsed.data.fullText,
      includeSearchContext: parsed.data.includeSearchContext,
    });

    logServerEvent('info', 'qa_success', {
      foundInDocument: result.answer.foundInDocument,
      usedSearchGrounding: Boolean(result.answer.externalWebContext),
      durationMs: result.durationMs,
    });

    return NextResponse.json(
      {
        answer: result.answer,
        meta: {
          modelUsed: result.modelUsed,
          durationMs: result.durationMs,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    if (error instanceof GeminiServiceError) {
      return NextResponse.json(
        { error: error.message, code: error.code },
        { status: error.statusCode }
      );
    }
    return NextResponse.json(
      { error: 'Could not answer this question right now. Please retry.', code: 'QA_ERROR' },
      { status: 500 }
    );
  }
}
