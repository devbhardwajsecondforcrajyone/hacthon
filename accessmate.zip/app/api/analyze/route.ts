import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { APP_CONFIG } from '@/lib/config';
import { analyzeDocumentWithGemini, GeminiServiceError } from '@/lib/server/gemini';
import { getClientRateLimitKey, serverRateLimiter } from '@/lib/server/rate-limit';
import { logServerEvent } from '@/lib/server/logger';

const AnalyzeRequestSchema = z.object({
  fileName: z.string().min(1).max(160),
  fullText: z
    .string()
    .min(APP_CONFIG.limits.minMeaningfulCharacters, 'Document text is too short to analyze.')
    .max(APP_CONFIG.limits.maxTextCharacters + 5000, 'Document exceeds maximum character limit.'),
  pages: z
    .array(
      z.object({
        pageNumber: z.number().int().positive(),
        text: z.string(),
        charCount: z.number().int().nonnegative(),
      })
    )
    .min(1)
    .max(APP_CONFIG.limits.maxPdfPages),
  readingLevel: z.enum(['simple', 'standard', 'detailed']).default('simple'),
  deepReasoning: z.boolean().default(false),
});

export async function POST(req: NextRequest) {
  const rateDecision = serverRateLimiter.check(
    getClientRateLimitKey(req, 'analyze'),
    APP_CONFIG.rateLimits.analyze
  );
  if (!rateDecision.allowed) {
    return NextResponse.json(
      {
        error: 'Analysis rate limit reached. Please wait a few seconds before trying again.',
        code: 'RATE_LIMITED',
      },
      {
        status: 429,
        headers: { 'Retry-After': String(rateDecision.retryAfterSeconds) },
      }
    );
  }

  try {
    const body = await req.json().catch(() => null);
    const parsed = AnalyzeRequestSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        {
          error: parsed.error.issues[0]?.message ?? 'Invalid analysis request payload.',
          code: 'INVALID_REQUEST',
        },
        { status: 400 }
      );
    }

    const result = await analyzeDocumentWithGemini({
      pages: parsed.data.pages,
      fullText: parsed.data.fullText,
      readingLevel: parsed.data.readingLevel,
      deepReasoning: parsed.data.deepReasoning,
      fileName: parsed.data.fileName,
    });

    logServerEvent('info', 'analyze_success', {
      readingLevel: parsed.data.readingLevel,
      chunksProcessed: result.chunksProcessed,
      durationMs: result.durationMs,
      verificationRate: result.groundingVerification.verificationRate,
    });

    return NextResponse.json(
      {
        analysis: result.analysis,
        meta: {
          modelUsed: result.modelUsed,
          thinkingLevel: result.thinkingLevel,
          chunksProcessed: result.chunksProcessed,
          durationMs: result.durationMs,
          cached: false,
          readingLevel: parsed.data.readingLevel,
          groundingVerification: result.groundingVerification,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    if (error instanceof GeminiServiceError) {
      return NextResponse.json(
        { error: error.message, code: error.code },
        { status: error.statusCode }
      );
    }
    logServerEvent('error', 'analyze_unexpected_error', {
      name: error instanceof Error ? error.name : 'unknown',
    });
    return NextResponse.json(
      { error: 'Document analysis could not be completed. Please try again.', code: 'ANALYSIS_ERROR' },
      { status: 500 }
    );
  }
}
