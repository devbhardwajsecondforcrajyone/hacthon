import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { APP_CONFIG, getLanguageByCode } from '@/lib/config';
import { DocumentAnalysisSchema } from '@/lib/types';
import { GeminiServiceError, translateAnalysisWithGemini } from '@/lib/server/gemini';
import { getClientRateLimitKey, serverRateLimiter } from '@/lib/server/rate-limit';
import { logServerEvent } from '@/lib/server/logger';

const TranslateRequestSchema = z.object({
  analysis: DocumentAnalysisSchema,
  targetLanguageCode: z.string().min(2).max(10),
});

export async function POST(req: NextRequest) {
  const rateDecision = serverRateLimiter.check(
    getClientRateLimitKey(req, 'translate'),
    APP_CONFIG.rateLimits.translate
  );
  if (!rateDecision.allowed) {
    return NextResponse.json(
      { error: 'Translation rate limit reached. Please wait a moment.', code: 'RATE_LIMITED' },
      { status: 429, headers: { 'Retry-After': String(rateDecision.retryAfterSeconds) } }
    );
  }

  try {
    const body = await req.json().catch(() => null);
    const parsed = TranslateRequestSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Invalid translation request payload.', code: 'INVALID_REQUEST' },
        { status: 400 }
      );
    }

    const lang = getLanguageByCode(parsed.data.targetLanguageCode);
    if (!lang) {
      return NextResponse.json(
        {
          error: `Language "${parsed.data.targetLanguageCode}" is not currently supported.`,
          code: 'UNSUPPORTED_LANGUAGE',
        },
        { status: 400 }
      );
    }

    const result = await translateAnalysisWithGemini({
      analysis: parsed.data.analysis,
      targetLanguageCode: lang.code,
    });

    logServerEvent('info', 'translate_success', {
      targetLanguageCode: lang.code,
      durationMs: result.durationMs,
    });

    return NextResponse.json(
      {
        translation: result.translation,
        meta: {
          modelUsed: result.modelUsed,
          durationMs: result.durationMs,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    if (error instanceof GeminiServiceError) {
      return NextResponse.json(
        { error: error.message, code: error.code },
        { status: error.statusCode }
      );
    }
    return NextResponse.json(
      {
        error: 'Translation failed. The original language summary remains available.',
        code: 'TRANSLATION_ERROR',
      },
      { status: 500 }
    );
  }
}
