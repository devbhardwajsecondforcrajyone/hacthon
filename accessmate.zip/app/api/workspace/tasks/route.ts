import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { APP_CONFIG } from '@/lib/config';
import { getClientRateLimitKey, serverRateLimiter } from '@/lib/server/rate-limit';

const TasksExportSchema = z.object({
  items: z
    .array(
      z.object({
        title: z.string().trim().min(1).max(200),
        notes: z.string().max(1500).default(''),
        dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional(),
      })
    )
    .min(1)
    .max(25),
});

export async function POST(req: NextRequest) {
  const rateDecision = serverRateLimiter.check(
    getClientRateLimitKey(req, 'workspace-tasks'),
    APP_CONFIG.rateLimits.workspace
  );
  if (!rateDecision.allowed) {
    return NextResponse.json(
      { error: 'Workspace rate limit reached. Please wait a moment.' },
      { status: 429, headers: { 'Retry-After': String(rateDecision.retryAfterSeconds) } }
    );
  }

  const authHeader = req.headers.get('authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ') || authHeader.length < 20) {
    return NextResponse.json(
      { error: 'Google Tasks authorization required. Sign in with Google first.' },
      { status: 401 }
    );
  }

  const body = await req.json().catch(() => null);
  const parsed = TasksExportSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? 'Invalid tasks export request.' },
      { status: 400 }
    );
  }

  try {
    let createdCount = 0;
    for (const item of parsed.data.items) {
      const payload: Record<string, string> = {
        title: item.title,
        notes: item.notes,
      };
      if (item.dueDate) {
        payload.due = `${item.dueDate}T00:00:00.000Z`;
      }
      const res = await fetch('https://tasks.googleapis.com/tasks/v1/lists/@default/tasks', {
        method: 'POST',
        headers: {
          Authorization: authHeader,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        return NextResponse.json(
          {
            error:
              res.status === 401 || res.status === 403
                ? 'Google Tasks permission expired or was denied. Please sign in again.'
                : `Exported ${createdCount} task(s), then encountered an error from Google Tasks.`,
            createdCount,
          },
          { status: res.status === 401 || res.status === 403 ? 401 : 502 }
        );
      }
      createdCount++;
    }

    return NextResponse.json({ createdCount }, { status: 201 });
  } catch {
    return NextResponse.json(
      { error: 'Network error connecting to Google Tasks.' },
      { status: 502 }
    );
  }
}
