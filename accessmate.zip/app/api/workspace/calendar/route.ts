import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { APP_CONFIG } from '@/lib/config';
import { getClientRateLimitKey, serverRateLimiter } from '@/lib/server/rate-limit';

const CalendarEventSchema = z.object({
  summary: z.string().trim().min(1).max(200),
  description: z.string().max(1500).default(''),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'An exact YYYY-MM-DD date is required.'),
});

function addOneDay(isoDate: string): string {
  const [y, m, d] = isoDate.split('-').map(Number);
  const next = new Date(Date.UTC(y, m - 1, d + 1));
  return next.toISOString().slice(0, 10);
}

export async function POST(req: NextRequest) {
  const rateDecision = serverRateLimiter.check(
    getClientRateLimitKey(req, 'workspace-calendar'),
    APP_CONFIG.rateLimits.workspace
  );
  if (!rateDecision.allowed) {
    return NextResponse.json(
      { error: 'Workspace rate limit reached. Please wait a moment.' },
      { status: 429, headers: { 'Retry-After': String(rateDecision.retryAfterSeconds) } }
    );
  }

  const authHeader = req.headers.get('authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ') || authHeader.length < 20) {
    return NextResponse.json(
      { error: 'Google Calendar authorization required. Sign in with Google first.' },
      { status: 401 }
    );
  }

  const body = await req.json().catch(() => null);
  const parsed = CalendarEventSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? 'Invalid calendar event details.' },
      { status: 400 }
    );
  }

  try {
    const res = await fetch(
      'https://www.googleapis.com/calendar/v3/calendars/primary/events',
      {
        method: 'POST',
        headers: {
          Authorization: authHeader,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          summary: parsed.data.summary,
          description: parsed.data.description,
          start: { date: parsed.data.date },
          end: { date: addOneDay(parsed.data.date) },
        }),
      }
    );

    if (!res.ok) {
      return NextResponse.json(
        {
          error:
            res.status === 401 || res.status === 403
              ? 'Google Calendar permission expired or was denied. Please sign in again.'
              : 'Google Calendar could not save this event right now.',
        },
        { status: res.status === 401 || res.status === 403 ? 401 : 502 }
      );
    }

    const created = (await res.json()) as { id?: string; htmlLink?: string };
    return NextResponse.json(
      {
        id: created.id ?? null,
        htmlLink: created.htmlLink ?? null,
      },
      { status: 201 }
    );
  } catch {
    return NextResponse.json(
      { error: 'Network error connecting to Google Calendar.' },
      { status: 502 }
    );
  }
}
