import { NextRequest, NextResponse } from 'next/server';
import { APP_CONFIG } from '@/lib/config';
import { GeminiServiceError, transcribeVoiceCommandWithGemini } from '@/lib/server/gemini';
import { getClientRateLimitKey, serverRateLimiter } from '@/lib/server/rate-limit';

const ALLOWED_AUDIO_MIMES = new Set([
  'audio/webm',
  'audio/webm;codecs=opus',
  'audio/mp4',
  'audio/mpeg',
  'audio/wav',
  'audio/ogg',
]);

const MAX_AUDIO_BYTES = 4 * 1024 * 1024; // 4 MB short voice command limit

export async function POST(req: NextRequest) {
  const rateDecision = serverRateLimiter.check(
    getClientRateLimitKey(req, 'transcribe'),
    APP_CONFIG.rateLimits.transcribe
  );
  if (!rateDecision.allowed) {
    return NextResponse.json(
      { error: 'Voice transcription rate limit reached. Please type your command instead.', code: 'RATE_LIMITED' },
      { status: 429, headers: { 'Retry-After': String(rateDecision.retryAfterSeconds) } }
    );
  }

  try {
    const formData = await req.formData();
    const audio = formData.get('audio');
    if (!(audio instanceof File)) {
      return NextResponse.json({ error: 'No audio recording provided.', code: 'NO_AUDIO' }, { status: 400 });
    }
    if (audio.size === 0 || audio.size > MAX_AUDIO_BYTES) {
      return NextResponse.json(
        { error: 'Voice recording must be between 1 byte and 4 MB.', code: 'INVALID_AUDIO_SIZE' },
        { status: 400 }
      );
    }

    const baseMime = (audio.type || 'audio/webm').split(';')[0].trim().toLowerCase();
    if (!ALLOWED_AUDIO_MIMES.has(audio.type.toLowerCase()) && !ALLOWED_AUDIO_MIMES.has(baseMime)) {
      return NextResponse.json(
        { error: 'Unsupported audio recording format.', code: 'UNSUPPORTED_AUDIO_MIME' },
        { status: 400 }
      );
    }

    const buffer = Buffer.from(await audio.arrayBuffer());
    const result = await transcribeVoiceCommandWithGemini({
      base64Audio: buffer.toString('base64'),
      mimeType: baseMime,
    });

    return NextResponse.json(
      {
        transcript: result.transcript,
        meta: {
          modelUsed: result.modelUsed,
          durationMs: result.durationMs,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    if (error instanceof GeminiServiceError) {
      return NextResponse.json(
        { error: error.message, code: error.code },
        { status: error.statusCode }
      );
    }
    return NextResponse.json(
      { error: 'Could not transcribe voice recording. Use the text input instead.', code: 'TRANSCRIBE_ERROR' },
      { status: 500 }
    );
  }
}
