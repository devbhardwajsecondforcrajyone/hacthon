import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { APP_CONFIG } from '@/lib/config';
import { validateUploadedFile } from '@/lib/document/validation';
import {
  buildExtractedDocument,
  DocumentExtractionError,
  extractFromPastedText,
  extractTextFromDocxBuffer,
  extractTextFromPdfBuffer,
  extractTextFromTxtBuffer,
} from '@/lib/document/extraction';
import { extractImageDocumentWithGemini, GeminiServiceError } from '@/lib/server/gemini';
import { getClientRateLimitKey, serverRateLimiter } from '@/lib/server/rate-limit';
import { logServerEvent } from '@/lib/server/logger';

const PasteBodySchema = z.object({
  text: z.string().min(1, 'Please enter or paste document text to analyze.'),
  title: z.string().max(120).optional(),
});

export async function POST(req: NextRequest) {
  const rateDecision = serverRateLimiter.check(
    getClientRateLimitKey(req, 'extract'),
    APP_CONFIG.rateLimits.extract
  );
  if (!rateDecision.allowed) {
    return NextResponse.json(
      {
        error: 'Too many document extraction requests. Please wait a moment before trying again.',
        code: 'RATE_LIMITED',
      },
      {
        status: 429,
        headers: { 'Retry-After': String(rateDecision.retryAfterSeconds) },
      }
    );
  }

  try {
    const contentType = req.headers.get('content-type') ?? '';

    // Branch A: Pasted text JSON payload
    if (contentType.includes('application/json')) {
      const body = await req.json().catch(() => null);
      const parsed = PasteBodySchema.safeParse(body);
      if (!parsed.success) {
        return NextResponse.json(
          {
            error: parsed.error.issues[0]?.message ?? 'Invalid text submission.',
            code: 'INVALID_INPUT',
          },
          { status: 400 }
        );
      }

      const document = extractFromPastedText(parsed.data.text, parsed.data.title);
      logServerEvent('info', 'extract_paste_success', {
        charCount: document.charCount,
        extractionTimeMs: document.extractionTimeMs,
        warningCount: document.warnings.length,
      });

      return NextResponse.json({ document }, { status: 200 });
    }

    // Branch B: Multipart file upload (PDF, TXT, DOCX, or Image)
    if (contentType.includes('multipart/form-data')) {
      const formData = await req.formData();
      const uploaded = formData.get('file');

      if (!(uploaded instanceof File)) {
        return NextResponse.json(
          { error: 'No document file was attached to the upload request.', code: 'NO_FILE' },
          { status: 400 }
        );
      }

      const arrayBuffer = await uploaded.arrayBuffer();
      const bytes = new Uint8Array(arrayBuffer);

      const validation = validateUploadedFile({
        fileName: uploaded.name,
        mimeType: uploaded.type,
        sizeBytes: uploaded.size,
        bytes,
      });

      if (!validation.valid || !validation.sourceType) {
        logServerEvent('warn', 'extract_upload_rejected', {
          errorCode: validation.errorCode ?? 'UNKNOWN',
          sizeBytes: uploaded.size,
        });
        return NextResponse.json(
          {
            error: validation.errorMessage ?? 'Unsupported or invalid file.',
            code: validation.errorCode ?? 'INVALID_FILE',
          },
          { status: 400 }
        );
      }

      let document;
      if (validation.sourceType === 'pdf') {
        document = await extractTextFromPdfBuffer(bytes, validation.sanitizedFileName);
      } else if (validation.sourceType === 'docx') {
        document = await extractTextFromDocxBuffer(bytes, validation.sanitizedFileName);
      } else if (validation.sourceType === 'txt') {
        document = extractTextFromTxtBuffer(bytes, validation.sanitizedFileName);
      } else {
        // Image document OCR via Gemini Vision (server-side only)
        const start = performance.now();
        const base64Data = Buffer.from(bytes).toString('base64');
        const mimeType = uploaded.type || 'image/jpeg';
        const ocr = await extractImageDocumentWithGemini({
          base64Data,
          mimeType,
          fileName: validation.sanitizedFileName,
        });
        document = buildExtractedDocument({
          fileName: validation.sanitizedFileName,
          sourceType: 'image',
          mimeType,
          sizeBytes: uploaded.size,
          rawPages: [{ pageNumber: 1, text: ocr.text }],
          extractionStartMs: start,
        });
      }

      logServerEvent('info', 'extract_file_success', {
        sourceType: document.sourceType,
        pageCount: document.pageCount,
        charCount: document.charCount,
        extractionTimeMs: document.extractionTimeMs,
        warningCount: document.warnings.length,
      });

      return NextResponse.json({ document }, { status: 200 });
    }

    return NextResponse.json(
      { error: 'Unsupported request content type.', code: 'UNSUPPORTED_CONTENT_TYPE' },
      { status: 415 }
    );
  } catch (error) {
    if (error instanceof DocumentExtractionError) {
      return NextResponse.json(
        { error: error.message, code: error.code },
        { status: error.statusCode }
      );
    }
    if (error instanceof GeminiServiceError) {
      return NextResponse.json(
        { error: error.message, code: error.code },
        { status: error.statusCode }
      );
    }
    logServerEvent('error', 'extract_unexpected_error', {
      name: error instanceof Error ? error.name : 'unknown',
    });
    return NextResponse.json(
      {
        error: 'Unable to process this document right now. Try a text-based PDF, DOCX, TXT, or paste the content.',
        code: 'EXTRACTION_FAILED',
      },
      { status: 500 }
    );
  }
}
