'use client';

import React from 'react';
import { AppShell } from '@/components/layout/AppShell';
import { useDocumentSession } from '@/contexts/DocumentSessionContext';
import { DashboardView } from '@/components/dashboard/DashboardView';
import { DocumentWorkspace } from '@/components/document/DocumentWorkspace';
import { TranslationPanel } from '@/components/document/TranslationPanel';
import { ActionChecklistPanel } from '@/components/checklist/ActionChecklistPanel';
import { AccessibilityControlCenter } from '@/components/accessibility/AccessibilityControlCenter';
import { EvaluationAndPerformanceView } from '@/components/evaluation/EvaluationAndPerformanceView';
import { AboutAccessmateView } from '@/components/about/AboutAccessmateView';

export default function HomePage() {
  const { activeNav } = useDocumentSession();

  return (
    <AppShell>
      {activeNav === 'dashboard' && <DashboardView />}
      {activeNav === 'workspace' && <DocumentWorkspace />}
      {activeNav === 'translations' && <TranslationPanel />}
      {activeNav === 'checklist' && <ActionChecklistPanel />}
      {activeNav === 'accessibility' && <AccessibilityControlCenter />}
      {activeNav === 'evaluation' && <EvaluationAndPerformanceView />}
      {activeNav === 'about' && <AboutAccessmateView />}
    </AppShell>
  );
}
