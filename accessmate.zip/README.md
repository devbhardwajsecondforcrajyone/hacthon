# ACCESSMATE — AI-Powered Universal Document Understanding & Accessibility Platform

**ACCESSMATE makes complicated information understandable, accessible, multilingual, and actionable.**

ACCESSMATE transforms dense notices, application forms, medical instructions, scholarship renewals, and public-service documents into plain-language summaries, verified source excerpts, translations across 13 languages (including Arabic RTL), extracted deadlines, accessible Text-to-Speech, and traceable action checklists.

---

## Core Capabilities

1. **Smart Document Upload & Extraction**
   - Drag-and-drop or browse PDF (up to 30 pages), DOCX, TXT, or clear document photos (PNG, JPG, WebP), or paste text directly.
   - Server-side validation of extension, MIME type, binary magic-byte file signature, size limit (8 MB), and page limit.
   - Automatic scanned-PDF detection and Document Quality & Extraction Warnings.

2. **AI-Powered Simple Language Summarization & Comparison**
   - Three reading levels: **Simple**, **Standard**, and **Detailed**, plus optional **Deep Reasoning Mode** (`ThinkingLevel.HIGH`).
   - Structured breakdown: overview, key points, instructions, requirements, warnings, responsibilities, required documents, conditions, uncertainties, and missing information.
   - Side-by-side **Original Text vs. Simplified Explanation** comparison mode.

3. **Source Evidence & Verification Panel**
   - Every major AI statement, deadline, and task includes a verbatim source quote and page number.
   - Programmatic excerpt verification checks whether each citation appears in the extracted document text.

4. **Multilingual Translation (13 Languages + RTL)**
   - English, Hindi, Bengali, Tamil, Telugu, Marathi, Gujarati, Kannada, Malayalam, Punjabi, French, Spanish, and Arabic (with automatic right-to-left presentation).
   - Preserves dates, numbers, monetary values, and official names; includes a clear non-certified translation disclaimer.

5. **Deadline & Important Information Extraction**
   - Separates document publication dates from real deadlines, flags ambiguous/relative dates for user verification, and extracts contacts and required documents.
   - Optional confirmation-gated export to **Google Calendar**.

6. **Document-to-Action Checklist**
   - Converts explicit instructions into checkable tasks with progress tracking, reset, copy, print, confirmation-gated export to **Google Tasks**, and formatted note export for **Google Keep**.

7. **Accessible Text-to-Speech & Optional Voice Interaction**
   - Client-side browser SpeechSynthesis (Play, Pause, Resume, Stop, speed control, voice picker, active section highlight) plus optional server-side **Gemini Neural Audio** (`gemini-3.8-flash-lite-tts`).
   - Optional voice commands via Web Speech API or server-side transcription (`gemini-3.5-transcribe`), with full keyboard/text alternatives.

8. **WCAG 2.2 AA Accessibility Control Center**
   - Live High-Clarity Light, Midnight Navy Dark, Comfortable Reading, and High-Contrast themes.
   - Font scaling (85%–145%), adjustable line & letter spacing, reduced motion toggle, unmistakable focus indicators, skip-to-content link, and ARIA live announcements.

9. **AI Accuracy Evaluation Engine & Real Performance Telemetry**
   - Built-in synthetic ground-truth corpus (Public Service, Healthcare, Ambiguous Dates, Adversarial Prompt-Injection) with deterministic accuracy & safety checks and real session timing metrics.

---

## Security & Privacy Summary

- `GEMINI_API_KEY` is used strictly server-side (`lib/server/gemini.ts`) and never exposed to browser bundles.
- All document text is treated as untrusted data inside per-request randomized boundary tags to resist prompt injection.
- Server endpoints validate all inputs with Zod and enforce sliding-window rate limiting (`429 Retry-After`).
- Uploaded documents are processed in temporary session memory only (no server database persistence) with one-click **Delete Document & Clear Session**.
- Google Workspace OAuth tokens are held strictly in client JS memory (never `localStorage`/`sessionStorage`), and every Calendar or Tasks write requires explicit user confirmation.

---

## Running Locally & Testing

```bash
# Install dependencies
npm install

# Run development server on port 3000
npm run dev

# Run automated unit, security, and API integration tests
npx --yes tsx --test tests/*.test.ts

# Run linter and production build
npm run lint
npm run build
```

Configure `GEMINI_API_KEY` in your server environment (see `.env.example` for placeholder variable names).

---

## Additional Documentation

- `docs/ARCHITECTURE.md` — System architecture, data flows, AI service boundaries, and security controls.
- `docs/TESTING.md` — Automated test coverage, synthetic ground-truth methodology, and browser verification details.
- `docs/JUDGING_CRITERIA_REPORT.md` — Honest six-criteria verification report with actual test results and known limitations.
