export const APP_CONFIG = {
  appName: 'ACCESSMATE',
  tagline: 'ACCESSMATE makes complicated information understandable, accessible, multilingual, and actionable.',
  limits: {
    maxFileSizeBytes: 8 * 1024 * 1024, // 8 MB
    maxPdfPages: 30,
    maxTextCharacters: 120_000,
    minMeaningfulCharacters: 25,
    chunkTargetCharacters: 14_000,
    chunkOverlapCharacters: 400,
    maxChunksPerDocument: 8,
    maxQuestionLength: 600,
    maxTtsCharacters: 3_500,
    requestTimeoutMs: 55_000,
    deepReasoningTimeoutMs: 90_000,
    scannedPdfCharsPerPageThreshold: 35,
  },
  rateLimits: {
    extract: { maxRequests: 20, windowMs: 60_000 },
    analyze: { maxRequests: 15, windowMs: 60_000 },
    translate: { maxRequests: 25, windowMs: 60_000 },
    qa: { maxRequests: 30, windowMs: 60_000 },
    tts: { maxRequests: 20, windowMs: 60_000 },
    transcribe: { maxRequests: 20, windowMs: 60_000 },
    workspace: { maxRequests: 20, windowMs: 60_000 },
  },
  models: {
    // Free-tier-capable Gemini 4 & 3.x models selected per project configuration
    reasoning: 'gemini-4-hydrogen',
    fast: 'gemini-3.1-flash-lite',
    vision: 'gemini-4-hydrogen',
    searchGrounded: 'gemini-4-hydrogen',
    tts: 'gemini-3.8-flash-lite-tts',
    transcribe: 'gemini-3.5-transcribe',
  },
  allowedExtensions: ['.pdf', '.txt', '.docx', '.png', '.jpg', '.jpeg', '.webp'] as const,
  allowedMimeTypes: [
    'application/pdf',
    'text/plain',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'image/png',
    'image/jpeg',
    'image/webp',
  ] as const,
} as const;

export interface SupportedLanguage {
  code: string;
  name: string;
  nativeName: string;
  bcp47: string;
  dir: 'ltr' | 'rtl';
}

export const SUPPORTED_LANGUAGES: readonly SupportedLanguage[] = [
  { code: 'en', name: 'English', nativeName: 'English', bcp47: 'en-US', dir: 'ltr' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', bcp47: 'hi-IN', dir: 'ltr' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', bcp47: 'bn-IN', dir: 'ltr' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', bcp47: 'ta-IN', dir: 'ltr' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', bcp47: 'te-IN', dir: 'ltr' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', bcp47: 'mr-IN', dir: 'ltr' },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી', bcp47: 'gu-IN', dir: 'ltr' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', bcp47: 'kn-IN', dir: 'ltr' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം', bcp47: 'ml-IN', dir: 'ltr' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', bcp47: 'pa-IN', dir: 'ltr' },
  { code: 'fr', name: 'French', nativeName: 'Français', bcp47: 'fr-FR', dir: 'ltr' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', bcp47: 'es-ES', dir: 'ltr' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', bcp47: 'ar-SA', dir: 'rtl' },
] as const;

export type ReadingLevel = 'simple' | 'standard' | 'detailed';

export const READING_LEVELS: readonly {
  id: ReadingLevel;
  label: string;
  description: string;
}[] = [
  {
    id: 'simple',
    label: 'Simple',
    description: 'Everyday vocabulary, short sentences, and step-by-step clarity.',
  },
  {
    id: 'standard',
    label: 'Standard',
    description: 'Clear explanations retaining all key terms, rules, and figures.',
  },
  {
    id: 'detailed',
    label: 'Detailed',
    description: 'Comprehensive breakdown preserving original terminology and conditions.',
  },
] as const;

export function getLanguageByCode(code: string): SupportedLanguage | undefined {
  return SUPPORTED_LANGUAGES.find((lang) => lang.code === code);
}
