import { z } from 'zod';
import type { ReadingLevel } from './config';

export type NavSection =
  | 'dashboard'
  | 'workspace'
  | 'translations'
  | 'checklist'
  | 'accessibility'
  | 'evaluation'
  | 'about';

export type WorkspaceTab =
  | 'overview'
  | 'comparison'
  | 'evidence'
  | 'translation'
  | 'deadlines'
  | 'checklist'
  | 'qa'
  | 'listen';

export type ThemeMode = 'light' | 'dark' | 'comfortable' | 'high-contrast';

export interface AccessibilityPreferences {
  theme: ThemeMode;
  fontScale: number; // 0.85 to 1.5
  lineSpacing: 'normal' | 'relaxed' | 'spacious';
  letterSpacing: 'normal' | 'wide';
  reducedMotion: boolean;
  privacyMode: boolean; // Auto-clear session on close, disable local history
}

export interface DocumentPage {
  pageNumber: number;
  text: string;
  charCount: number;
}

export interface DocumentQualityWarning {
  id: string;
  severity: 'info' | 'warning' | 'critical';
  code:
    | 'SCANNED_PDF_DETECTED'
    | 'LOW_TEXT_DENSITY'
    | 'TRUNCATED_DOCUMENT'
    | 'PROMPT_INJECTION_PATTERN'
    | 'IMAGE_OCR_USED'
    | 'AMBIGUOUS_DATES_PRESENT'
    | 'MISSING_DEADLINES'
    | 'CHUNKED_ANALYSIS';
  title: string;
  message: string;
  recommendation: string;
}

export interface ExtractedDocument {
  id: string;
  fileName: string;
  sourceType: 'pdf' | 'txt' | 'docx' | 'image' | 'paste';
  mimeType: string;
  sizeBytes: number;
  pageCount: number;
  pages: DocumentPage[];
  fullText: string;
  contentHash: string;
  charCount: number;
  wordCount: number;
  estimatedTokens: number;
  extractionTimeMs: number;
  warnings: DocumentQualityWarning[];
  truncated: boolean;
  extractedAt: string;
}

// Strict Zod schemas for server-validated AI responses

export const EvidenceItemSchema = z.object({
  statement: z.string().min(1),
  sourceExcerpt: z.string().min(1),
  pageNumber: z.number().int().positive().nullable(),
  category: z.enum(['fact', 'instruction', 'requirement', 'warning', 'responsibility', 'condition', 'document']),
});

export const ComparisonSegmentSchema = z.object({
  sectionTitle: z.string().min(1),
  originalExcerpt: z.string().min(1),
  simplifiedExplanation: z.string().min(1),
  pageNumber: z.number().int().positive().nullable(),
});

export const DeadlineItemSchema = z.object({
  id: z.string().min(1),
  originalText: z.string().min(1),
  normalizedDate: z.string().nullable(), // ISO YYYY-MM-DD only when unambiguous
  dateType: z.enum([
    'submission_deadline',
    'application_date',
    'appointment_date',
    'payment_date',
    'examination_date',
    'validity_period',
    'renewal_date',
    'other_important_date',
  ]),
  label: z.string().min(1),
  sourceExcerpt: z.string().min(1),
  pageNumber: z.number().int().positive().nullable(),
  confidence: z.enum(['high', 'medium', 'low']),
  needsVerification: z.boolean(),
  verificationReason: z.string().nullable(),
});

export const ActionChecklistItemSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  explanation: z.string().min(1),
  sourceExcerpt: z.string().min(1),
  pageNumber: z.number().int().positive().nullable(),
  dueDate: z.string().nullable(),
  priority: z.enum(['high', 'medium', 'low']),
  requiredDocuments: z.array(z.string()).default([]),
});

export const ContactInfoSchema = z.object({
  label: z.string().min(1),
  value: z.string().min(1),
  sourceExcerpt: z.string().min(1),
  pageNumber: z.number().int().positive().nullable(),
});

export const DocumentAnalysisSchema = z.object({
  documentOverview: z.string().min(1),
  detectedLanguage: z.string().min(1),
  readingLevel: z.enum(['simple', 'standard', 'detailed']),
  summary: z.string().min(1),
  keyPoints: z.array(EvidenceItemSchema),
  importantInstructions: z.array(EvidenceItemSchema),
  keyRequirements: z.array(EvidenceItemSchema),
  importantWarnings: z.array(EvidenceItemSchema),
  responsibilities: z.array(EvidenceItemSchema),
  requiredDocuments: z.array(z.string()),
  relevantConditions: z.array(EvidenceItemSchema),
  comparisonSegments: z.array(ComparisonSegmentSchema),
  deadlines: z.array(DeadlineItemSchema),
  contactInformation: z.array(ContactInfoSchema),
  actionChecklist: z.array(ActionChecklistItemSchema),
  uncertainties: z.array(z.string()),
  missingInformation: z.array(z.string()),
});

export type EvidenceItem = z.infer<typeof EvidenceItemSchema>;
export type ComparisonSegment = z.infer<typeof ComparisonSegmentSchema>;
export type DeadlineItem = z.infer<typeof DeadlineItemSchema>;
export type ActionChecklistItem = z.infer<typeof ActionChecklistItemSchema>;
export type ContactInfo = z.infer<typeof ContactInfoSchema>;
export type DocumentAnalysis = z.infer<typeof DocumentAnalysisSchema>;

export const TranslatedContentSchema = z.object({
  targetLanguageCode: z.string().min(2),
  targetLanguageName: z.string().min(2),
  direction: z.enum(['ltr', 'rtl']),
  disclaimer: z.string().min(1),
  documentOverview: z.string().min(1),
  summary: z.string().min(1),
  keyPoints: z.array(z.string()),
  importantInstructions: z.array(z.string()),
  importantWarnings: z.array(z.string()),
  checklistItems: z.array(
    z.object({
      id: z.string(),
      title: z.string().min(1),
      explanation: z.string().min(1),
      dueDate: z.string().nullable(),
    })
  ),
  deadlinesSummary: z.array(
    z.object({
      id: z.string(),
      label: z.string().min(1),
      originalText: z.string().min(1),
    })
  ),
});

export type TranslatedContent = z.infer<typeof TranslatedContentSchema>;

export const QAResponseSchema = z.object({
  foundInDocument: z.boolean(),
  directAnswer: z.string().min(1),
  quotedEvidence: z.array(
    z.object({
      excerpt: z.string().min(1),
      pageNumber: z.number().int().positive().nullable(),
    })
  ),
  generalExplanation: z.string().nullable(),
  externalWebContext: z
    .object({
      summary: z.string(),
      sources: z.array(
        z.object({
          title: z.string(),
          uri: z.string(),
        })
      ),
    })
    .nullable()
    .optional(),
});

export type QAResponse = z.infer<typeof QAResponseSchema>;

export interface QAMessage {
  id: string;
  question: string;
  usedSearchGrounding: boolean;
  response: QAResponse;
  durationMs: number;
  createdAt: string;
}

export interface PerformanceMetric {
  id: string;
  operation: 'extract' | 'analyze' | 'translate' | 'qa' | 'tts' | 'transcribe';
  durationMs: number;
  cached: boolean;
  modelUsed?: string;
  inputChars: number;
  outputChars: number;
  chunksProcessed?: number;
  timestamp: string;
}

export interface AnalyzeApiResponse {
  analysis: DocumentAnalysis;
  meta: {
    modelUsed: string;
    thinkingLevel: 'HIGH' | 'LOW' | 'STANDARD';
    chunksProcessed: number;
    durationMs: number;
    cached: boolean;
    readingLevel: ReadingLevel;
    groundingVerification: {
      totalCitations: number;
      verifiedCitations: number;
      verificationRate: number;
    };
  };
}
