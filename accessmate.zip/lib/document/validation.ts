import { APP_CONFIG } from '../config';
import type { DocumentPage, DocumentQualityWarning } from '../types';

export interface FileValidationResult {
  valid: boolean;
  sourceType?: 'pdf' | 'txt' | 'docx' | 'image';
  sanitizedFileName: string;
  errorCode?:
    | 'EMPTY_FILE'
    | 'FILE_TOO_LARGE'
    | 'UNSUPPORTED_EXTENSION'
    | 'UNSUPPORTED_MIME'
    | 'INVALID_SIGNATURE'
    | 'BINARY_TEXT_FILE';
  errorMessage?: string;
}

const PROMPT_INJECTION_PATTERNS: readonly { pattern: RegExp; label: string }[] = [
  {
    pattern: /ignore\s+(all\s+)?(previous|prior|above)\s+(instructions|prompts|rules)/i,
    label: 'Instruction override attempt',
  },
  {
    pattern: /reveal\s+(your\s+)?(system\s+prompt|api\s*key|secret|environment|credentials)/i,
    label: 'Credential or prompt exfiltration attempt',
  },
  {
    pattern: /you\s+are\s+now\s+(a|an|in)\s+(developer|admin|unrestricted|jailbreak)/i,
    label: 'Role hijacking attempt',
  },
  {
    pattern: /<\s*script\b[^>]*>|javascript\s*:|on(load|error|click)\s*=/i,
    label: 'Embedded active script markup',
  },
  {
    pattern: /disregard\s+(the\s+)?(document|safety|system)\s+(guidelines|instructions)/i,
    label: 'Safety bypass attempt',
  },
];

/**
 * Sanitizes an untrusted filename by stripping directory traversal sequences,
 * control characters, and unsafe punctuation while preserving readability.
 */
export function sanitizeFileName(rawName: string): string {
  const base = rawName.split(/[\\/]/).pop() ?? 'document';
  const cleaned = base
    .replace(/[\u0000-\u001f\u007f<>:"|?*]/g, '')
    .replace(/\.{2,}/g, '.')
    .trim();

  if (!cleaned || cleaned === '.') {
    return 'uploaded-document.txt';
  }
  return cleaned.slice(0, 120);
}

/**
 * Extracts lowercase extension including leading dot.
 */
export function getFileExtension(fileName: string): string {
  const idx = fileName.lastIndexOf('.');
  if (idx <= 0 || idx === fileName.length - 1) return '';
  return fileName.slice(idx).toLowerCase();
}

/**
 * Inspects binary magic bytes to verify that the file content genuinely matches
 * its declared extension and MIME type (defense against spoofed uploads).
 */
export function verifyFileSignature(
  bytes: Uint8Array,
  expectedType: 'pdf' | 'txt' | 'docx' | 'image',
  mimeType: string
): boolean {
  if (bytes.length === 0) return false;

  if (expectedType === 'pdf') {
    // %PDF-
    return (
      bytes.length >= 5 &&
      bytes[0] === 0x25 &&
      bytes[1] === 0x50 &&
      bytes[2] === 0x44 &&
      bytes[3] === 0x46 &&
      bytes[4] === 0x2d
    );
  }

  if (expectedType === 'docx') {
    // ZIP container magic bytes: PK\x03\x04
    return (
      bytes.length >= 4 &&
      bytes[0] === 0x50 &&
      bytes[1] === 0x4b &&
      bytes[2] === 0x03 &&
      bytes[3] === 0x04
    );
  }

  if (expectedType === 'image') {
    if (mimeType === 'image/png') {
      return (
        bytes.length >= 8 &&
        bytes[0] === 0x89 &&
        bytes[1] === 0x50 &&
        bytes[2] === 0x4e &&
        bytes[3] === 0x47
      );
    }
    if (mimeType === 'image/jpeg') {
      return bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
    }
    if (mimeType === 'image/webp') {
      // RIFF....WEBP
      return (
        bytes.length >= 12 &&
        bytes[0] === 0x52 &&
        bytes[1] === 0x49 &&
        bytes[2] === 0x46 &&
        bytes[3] === 0x46 &&
        bytes[8] === 0x57 &&
        bytes[9] === 0x45 &&
        bytes[10] === 0x42 &&
        bytes[11] === 0x50
      );
    }
    return false;
  }

  // TXT: reject NUL bytes and excessive non-printable control chars
  const sampleLength = Math.min(bytes.length, 4096);
  let suspiciousControls = 0;
  for (let i = 0; i < sampleLength; i++) {
    const b = bytes[i];
    if (b === 0x00) return false;
    if (b < 0x09 || (b > 0x0d && b < 0x20)) {
      suspiciousControls++;
    }
  }
  return suspiciousControls / sampleLength < 0.05;
}

/**
 * Full server-side and client-side upload validator covering filename,
 * extension, MIME type, size bounds, and magic-byte signature verification.
 */
export function validateUploadedFile(params: {
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  bytes: Uint8Array;
}): FileValidationResult {
  const sanitizedFileName = sanitizeFileName(params.fileName);

  if (params.sizeBytes <= 0 || params.bytes.length === 0) {
    return {
      valid: false,
      sanitizedFileName,
      errorCode: 'EMPTY_FILE',
      errorMessage: 'The selected file is empty. Upload a readable document or paste text instead.',
    };
  }

  if (params.sizeBytes > APP_CONFIG.limits.maxFileSizeBytes) {
    const maxMb = Math.round(APP_CONFIG.limits.maxFileSizeBytes / (1024 * 1024));
    return {
      valid: false,
      sanitizedFileName,
      errorCode: 'FILE_TOO_LARGE',
      errorMessage: `This file exceeds the ${maxMb} MB safety limit. Split the document or paste the relevant sections.`,
    };
  }

  const ext = getFileExtension(sanitizedFileName);
  const allowedExts: readonly string[] = APP_CONFIG.allowedExtensions;
  if (!allowedExts.includes(ext)) {
    return {
      valid: false,
      sanitizedFileName,
      errorCode: 'UNSUPPORTED_EXTENSION',
      errorMessage: `Unsupported file format (${ext || 'unknown'}). Upload a PDF, TXT, DOCX, or clear document photo (PNG, JPG, WebP).`,
    };
  }

  let sourceType: 'pdf' | 'txt' | 'docx' | 'image';
  let expectedMime = params.mimeType;

  if (ext === '.pdf') {
    sourceType = 'pdf';
    if (params.mimeType && params.mimeType !== 'application/pdf') {
      return {
        valid: false,
        sanitizedFileName,
        errorCode: 'UNSUPPORTED_MIME',
        errorMessage: 'The file MIME type does not match a PDF document.',
      };
    }
    expectedMime = 'application/pdf';
  } else if (ext === '.txt') {
    sourceType = 'txt';
    if (
      params.mimeType &&
      params.mimeType !== 'text/plain' &&
      params.mimeType !== 'application/octet-stream'
    ) {
      return {
        valid: false,
        sanitizedFileName,
        errorCode: 'UNSUPPORTED_MIME',
        errorMessage: 'The file MIME type does not match a plain text file.',
      };
    }
    expectedMime = 'text/plain';
  } else if (ext === '.docx') {
    sourceType = 'docx';
    if (
      params.mimeType &&
      params.mimeType !==
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' &&
      params.mimeType !== 'application/zip'
    ) {
      return {
        valid: false,
        sanitizedFileName,
        errorCode: 'UNSUPPORTED_MIME',
        errorMessage: 'The file MIME type does not match a DOCX document.',
      };
    }
    expectedMime = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
  } else {
    sourceType = 'image';
    const mimeForExt: Record<string, string> = {
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.webp': 'image/webp',
    };
    expectedMime = mimeForExt[ext];
    if (params.mimeType && params.mimeType !== expectedMime) {
      return {
        valid: false,
        sanitizedFileName,
        errorCode: 'UNSUPPORTED_MIME',
        errorMessage: 'The uploaded image MIME type does not match its file extension.',
      };
    }
  }

  if (!verifyFileSignature(params.bytes, sourceType, expectedMime)) {
    return {
      valid: false,
      sanitizedFileName,
      errorCode: sourceType === 'txt' ? 'BINARY_TEXT_FILE' : 'INVALID_SIGNATURE',
      errorMessage:
        sourceType === 'txt'
          ? 'The text file appears to contain binary data rather than readable plain text.'
          : 'The file signature does not match its extension. The file may be corrupted or mislabeled.',
    };
  }

  return {
    valid: true,
    sourceType,
    sanitizedFileName,
  };
}

/**
 * Normalizes untrusted document text while preserving line structure and removing
 * invisible control characters that could interfere with reading or parsing.
 */
export function sanitizeDocumentText(raw: string): string {
  return raw
    .replace(/\u0000/g, '')
    .replace(/[\u0001-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, ' ')
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(/\n{4,}/g, '\n\n\n')
    .trim();
}

/**
 * Scans untrusted document text for embedded prompt-injection or active script patterns.
 * Does NOT alter the meaning of the document, but alerts the user and reinforces AI isolation.
 */
export function detectPromptInjectionSignals(text: string): string[] {
  const detected: string[] = [];
  for (const item of PROMPT_INJECTION_PATTERNS) {
    if (item.pattern.test(text)) {
      detected.push(item.label);
    }
  }
  return detected;
}

/**
 * Generates actionable Document Quality & Extraction Warnings based on extraction
 * density, truncation, scanned-PDF detection, and untrusted input signals.
 */
export function buildDocumentQualityWarnings(params: {
  sourceType: 'pdf' | 'txt' | 'docx' | 'image' | 'paste';
  pages: DocumentPage[];
  fullText: string;
  truncated: boolean;
  originalCharCount: number;
}): DocumentQualityWarning[] {
  const warnings: DocumentQualityWarning[] = [];

  if (params.sourceType === 'pdf' && params.pages.length > 0) {
    const avgChars = params.fullText.length / params.pages.length;
    const emptyPages = params.pages.filter(
      (p) => p.text.trim().length < APP_CONFIG.limits.scannedPdfCharsPerPageThreshold
    );
    if (avgChars < APP_CONFIG.limits.scannedPdfCharsPerPageThreshold) {
      warnings.push({
        id: 'warn-scanned-pdf',
        severity: 'critical',
        code: 'SCANNED_PDF_DETECTED',
        title: 'Scanned or image-only PDF detected',
        message:
          'Very little selectable text was found in this PDF. Optical text recognition (OCR) is required to read scanned pages accurately.',
        recommendation:
          'Upload a clear photo/screenshot of each page using Image Upload, try a text-based PDF, or paste the document text directly.',
      });
    } else if (emptyPages.length > 0) {
      warnings.push({
        id: 'warn-low-density-pages',
        severity: 'warning',
        code: 'LOW_TEXT_DENSITY',
        title: `${emptyPages.length} page(s) have minimal extractable text`,
        message: `Page(s) ${emptyPages.map((p) => p.pageNumber).join(', ')} may contain scanned images, diagrams, or signatures that standard PDF text extraction cannot read.`,
        recommendation: 'Review those pages directly or upload photos of them for visual analysis.',
      });
    }
  }

  if (params.sourceType === 'image') {
    warnings.push({
      id: 'warn-image-ocr',
      severity: 'info',
      code: 'IMAGE_OCR_USED',
      title: 'Text extracted from image via AI vision',
      message:
        'Image text recognition can occasionally misread smudged characters, handwriting, or small footnotes.',
      recommendation:
        'Verify exact numbers, IDs, and dates against your original photo before taking action.',
    });
  }

  if (params.truncated) {
    warnings.push({
      id: 'warn-truncated',
      severity: 'warning',
      code: 'TRUNCATED_DOCUMENT',
      title: 'Document exceeded maximum character budget',
      message: `Original text had ${params.originalCharCount.toLocaleString()} characters and was bounded to ${APP_CONFIG.limits.maxTextCharacters.toLocaleString()} characters for reliable processing.`,
      recommendation:
        'Analyze remaining sections separately so no deadlines or conditions on later pages are missed.',
    });
  }

  const injectionSignals = detectPromptInjectionSignals(params.fullText);
  if (injectionSignals.length > 0) {
    warnings.push({
      id: 'warn-injection',
      severity: 'warning',
      code: 'PROMPT_INJECTION_PATTERN',
      title: 'Untrusted instruction-like patterns isolated',
      message: `Detected patterns resembling embedded prompts or scripts (${injectionSignals.join(', ')}). ACCESSMATE treats all document text strictly as data and blocks embedded instructions.`,
      recommendation:
        'Verify the source of this document and confirm extracted outputs in the Evidence Verification panel.',
    });
  }

  return warnings;
}

/**
 * Validates external URLs (such as Google Search grounding links) so only safe
 * http/https URLs can ever be rendered in anchor hrefs.
 */
export function isSafeHttpUrl(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}
