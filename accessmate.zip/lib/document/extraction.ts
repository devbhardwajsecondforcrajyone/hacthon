import { extractText, getDocumentProxy } from 'unpdf';
import mammoth from 'mammoth';
import { APP_CONFIG } from '../config';
import type { DocumentPage, ExtractedDocument } from '../types';
import {
  buildDocumentQualityWarnings,
  sanitizeDocumentText,
  sanitizeFileName,
} from './validation';
import { computeContentHash, countWords, estimateTokenCount } from './chunking';

export class DocumentExtractionError extends Error {
  constructor(
    public readonly code:
      | 'EMPTY_DOCUMENT'
      | 'PAGE_LIMIT_EXCEEDED'
      | 'PDF_PARSE_FAILED'
      | 'DOCX_PARSE_FAILED'
      | 'SCANNED_PDF_UNREADABLE'
      | 'IMAGE_OCR_FAILED',
    message: string,
    public readonly statusCode: number = 400
  ) {
    super(message);
    this.name = 'DocumentExtractionError';
  }
}

/**
 * Builds a normalized ExtractedDocument payload from extracted per-page text,
 * enforcing character limits and computing extraction warnings + metrics.
 */
export function buildExtractedDocument(params: {
  fileName: string;
  sourceType: 'pdf' | 'txt' | 'docx' | 'image' | 'paste';
  mimeType: string;
  sizeBytes: number;
  rawPages: { pageNumber: number; text: string }[];
  extractionStartMs: number;
}): ExtractedDocument {
  const cleanedPages: DocumentPage[] = params.rawPages.map((p) => {
    const text = sanitizeDocumentText(p.text);
    return {
      pageNumber: p.pageNumber,
      text,
      charCount: text.length,
    };
  });

  const combinedRaw = cleanedPages
    .map((p) => (cleanedPages.length > 1 ? `[Page ${p.pageNumber}]\n${p.text}` : p.text))
    .join('\n\n')
    .trim();

  const originalCharCount = combinedRaw.length;
  let truncated = false;
  let boundedText = combinedRaw;

  if (boundedText.length > APP_CONFIG.limits.maxTextCharacters) {
    boundedText = boundedText.slice(0, APP_CONFIG.limits.maxTextCharacters);
    truncated = true;
  }

  // Bound per-page content proportionally when truncated
  let running = 0;
  const boundedPages: DocumentPage[] = [];
  for (const page of cleanedPages) {
    if (running >= APP_CONFIG.limits.maxTextCharacters) break;
    const remaining = APP_CONFIG.limits.maxTextCharacters - running;
    const slice = page.text.slice(0, remaining);
    boundedPages.push({
      pageNumber: page.pageNumber,
      text: slice,
      charCount: slice.length,
    });
    running += slice.length;
  }

  const warnings = buildDocumentQualityWarnings({
    sourceType: params.sourceType,
    pages: boundedPages,
    fullText: boundedText,
    truncated,
    originalCharCount,
  });

  if (
    params.sourceType === 'pdf' &&
    boundedText.replace(/\[Page \d+\]/g, '').trim().length < APP_CONFIG.limits.minMeaningfulCharacters
  ) {
    throw new DocumentExtractionError(
      'SCANNED_PDF_UNREADABLE',
      'Unable to extract readable text from this PDF. It appears to be a scanned or image-only PDF requiring optical text recognition (OCR). Try a text-based PDF, upload a clear page image, or paste the document text.',
      422
    );
  }

  if (boundedText.trim().length < APP_CONFIG.limits.minMeaningfulCharacters) {
    throw new DocumentExtractionError(
      'EMPTY_DOCUMENT',
      'The document does not contain enough readable text to analyze. Provide at least a few sentences of content.',
      400
    );
  }

  const extractionTimeMs = Math.max(1, Math.round(performance.now() - params.extractionStartMs));

  return {
    id: `doc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    fileName: sanitizeFileName(params.fileName),
    sourceType: params.sourceType,
    mimeType: params.mimeType,
    sizeBytes: params.sizeBytes,
    pageCount: Math.max(1, boundedPages.length),
    pages: boundedPages,
    fullText: boundedText,
    contentHash: computeContentHash(boundedText),
    charCount: boundedText.length,
    wordCount: countWords(boundedText),
    estimatedTokens: estimateTokenCount(boundedText),
    extractionTimeMs,
    warnings,
    truncated,
    extractedAt: new Date().toISOString(),
  };
}

/**
 * Extracts per-page text from a PDF buffer using `unpdf` (pure JS, no native binaries).
 */
export async function extractTextFromPdfBuffer(
  bytes: Uint8Array,
  fileName: string
): Promise<ExtractedDocument> {
  const start = performance.now();
  try {
    const pdf = await getDocumentProxy(new Uint8Array(bytes));
    const totalPages = pdf.numPages;

    if (totalPages > APP_CONFIG.limits.maxPdfPages) {
      await pdf.cleanup?.();
      throw new DocumentExtractionError(
        'PAGE_LIMIT_EXCEEDED',
        `This PDF has ${totalPages} pages, which exceeds the ${APP_CONFIG.limits.maxPdfPages}-page safety limit. Upload a shorter section or paste the key pages.`,
        400
      );
    }

    const { text: pageTexts } = await extractText(pdf, { mergePages: false });
    await pdf.cleanup?.();

    const pagesArray = Array.isArray(pageTexts) ? pageTexts : [String(pageTexts ?? '')];
    const rawPages = pagesArray.map((text, index) => ({
      pageNumber: index + 1,
      text: String(text ?? ''),
    }));

    return buildExtractedDocument({
      fileName,
      sourceType: 'pdf',
      mimeType: 'application/pdf',
      sizeBytes: bytes.byteLength,
      rawPages,
      extractionStartMs: start,
    });
  } catch (err) {
    if (err instanceof DocumentExtractionError) {
      throw err;
    }
    throw new DocumentExtractionError(
      'PDF_PARSE_FAILED',
      'Unable to parse this PDF file. It may be password-protected, encrypted, or corrupted. Try a standard unencrypted PDF or paste the text directly.',
      422
    );
  }
}

/**
 * Extracts readable text from a DOCX file using `mammoth`.
 */
export async function extractTextFromDocxBuffer(
  bytes: Uint8Array,
  fileName: string
): Promise<ExtractedDocument> {
  const start = performance.now();
  try {
    const buffer = Buffer.from(bytes);
    const result = await mammoth.extractRawText({ buffer });
    const rawText = result.value ?? '';

    return buildExtractedDocument({
      fileName,
      sourceType: 'docx',
      mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      sizeBytes: bytes.byteLength,
      rawPages: [{ pageNumber: 1, text: rawText }],
      extractionStartMs: start,
    });
  } catch (err) {
    if (err instanceof DocumentExtractionError) {
      throw err;
    }
    throw new DocumentExtractionError(
      'DOCX_PARSE_FAILED',
      'Unable to extract text from this DOCX file. Ensure it is a valid Word (.docx) document or paste the text directly.',
      422
    );
  }
}

/**
 * Extracts text from a plain UTF-8 TXT buffer.
 */
export function extractTextFromTxtBuffer(
  bytes: Uint8Array,
  fileName: string
): ExtractedDocument {
  const start = performance.now();
  const decoder = new TextDecoder('utf-8', { fatal: false });
  const rawText = decoder.decode(bytes);
  return buildExtractedDocument({
    fileName,
    sourceType: 'txt',
    mimeType: 'text/plain',
    sizeBytes: bytes.byteLength,
    rawPages: [{ pageNumber: 1, text: rawText }],
    extractionStartMs: start,
  });
}

/**
 * Normalizes pasted plain text into an ExtractedDocument.
 */
export function extractFromPastedText(rawText: string, title?: string): ExtractedDocument {
  const start = performance.now();
  const safeName = title?.trim() ? `${sanitizeFileName(title)}.txt` : 'Pasted_Document.txt';
  const sizeBytes = Buffer.byteLength(rawText, 'utf8');
  return buildExtractedDocument({
    fileName: safeName,
    sourceType: 'paste',
    mimeType: 'text/plain',
    sizeBytes,
    rawPages: [{ pageNumber: 1, text: rawText }],
    extractionStartMs: start,
  });
}
