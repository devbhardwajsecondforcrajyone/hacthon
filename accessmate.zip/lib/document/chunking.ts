import { APP_CONFIG } from '../config';
import type { DocumentPage } from '../types';

export interface DocumentChunk {
  chunkIndex: number;
  startPage: number;
  endPage: number;
  text: string;
  charCount: number;
  estimatedTokens: number;
}

/**
 * Estimates approximate token count using a conservative 4-chars-per-token heuristic.
 */
export function estimateTokenCount(text: string): number {
  if (!text) return 0;
  return Math.ceil(text.length / 4);
}

/**
 * Counts words in extracted text cleanly.
 */
export function countWords(text: string): number {
  const trimmed = text.trim();
  if (!trimmed) return 0;
  return trimmed.split(/\s+/).length;
}

/**
 * Computes a deterministic, non-cryptographic 64-bit hex content fingerprint
 * (works synchronously in both Node.js and browsers without exposing raw text).
 */
export function computeContentHash(text: string): string {
  let h1 = 0xdeadbeef ^ text.length;
  let h2 = 0x41c6ce57 ^ text.length;
  for (let i = 0; i < text.length; i++) {
    const ch = text.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(14, '0');
}

/**
 * Splits a multi-page document into controlled, page-annotated chunks while
 * preserving exact `[Page N]` markers so Gemini can cite accurate page numbers.
 */
export function chunkDocumentPages(
  pages: DocumentPage[],
  targetChars: number = APP_CONFIG.limits.chunkTargetCharacters,
  maxChunks: number = APP_CONFIG.limits.maxChunksPerDocument
): { chunks: DocumentChunk[]; truncatedByChunkLimit: boolean } {
  const chunks: DocumentChunk[] = [];
  let buffer = '';
  let startPage = pages[0]?.pageNumber ?? 1;
  let endPage = startPage;
  let truncatedByChunkLimit = false;

  const flushChunk = () => {
    const trimmed = buffer.trim();
    if (!trimmed) return;
    if (chunks.length >= maxChunks) {
      truncatedByChunkLimit = true;
      return;
    }
    chunks.push({
      chunkIndex: chunks.length,
      startPage,
      endPage,
      text: trimmed,
      charCount: trimmed.length,
      estimatedTokens: estimateTokenCount(trimmed),
    });
  };

  for (const page of pages) {
    const pageBody = page.text.trim();
    if (!pageBody) continue;
    const annotatedPage = `[Page ${page.pageNumber}]\n${pageBody}`;

    // If a single page itself exceeds targetChars, split it along paragraph/sentence boundaries
    if (annotatedPage.length > targetChars) {
      if (buffer.trim()) {
        flushChunk();
        buffer = '';
      }
      let offset = 0;
      while (offset < pageBody.length) {
        if (chunks.length >= maxChunks) {
          truncatedByChunkLimit = true;
          break;
        }
        let end = Math.min(offset + targetChars - 32, pageBody.length);
        if (end < pageBody.length) {
          const lastBreak = Math.max(
            pageBody.lastIndexOf('\n\n', end),
            pageBody.lastIndexOf('. ', end),
            pageBody.lastIndexOf('\n', end)
          );
          if (lastBreak > offset + Math.floor(targetChars * 0.5)) {
            end = lastBreak + 1;
          }
        }
        const slice = `[Page ${page.pageNumber}]\n${pageBody.slice(offset, end).trim()}`;
        chunks.push({
          chunkIndex: chunks.length,
          startPage: page.pageNumber,
          endPage: page.pageNumber,
          text: slice,
          charCount: slice.length,
          estimatedTokens: estimateTokenCount(slice),
        });
        offset = end;
      }
      startPage = page.pageNumber + 1;
      endPage = startPage;
      continue;
    }

    if (buffer.length > 0 && buffer.length + annotatedPage.length + 2 > targetChars) {
      flushChunk();
      buffer = annotatedPage;
      startPage = page.pageNumber;
      endPage = page.pageNumber;
    } else {
      if (!buffer) {
        startPage = page.pageNumber;
      }
      buffer = buffer ? `${buffer}\n\n${annotatedPage}` : annotatedPage;
      endPage = page.pageNumber;
    }
  }

  if (buffer.trim()) {
    flushChunk();
  }

  return { chunks, truncatedByChunkLimit };
}

/**
 * Verifies whether a quoted source excerpt actually appears (exact or whitespace-normalized)
 * in the extracted document text so users can see real grounding verification.
 */
export function verifyExcerptAgainstDocument(excerpt: string, fullText: string): {
  verified: boolean;
  matchType: 'exact' | 'normalized' | 'unverified';
} {
  const cleanExcerpt = excerpt.trim();
  if (!cleanExcerpt || !fullText) {
    return { verified: false, matchType: 'unverified' };
  }
  if (fullText.includes(cleanExcerpt)) {
    return { verified: true, matchType: 'exact' };
  }

  const normalize = (s: string) =>
    s
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s]/gu, ' ')
      .replace(/\s+/g, ' ')
      .trim();

  const normExcerpt = normalize(cleanExcerpt);
  const normDoc = normalize(fullText);

  if (normExcerpt.length >= 12 && normDoc.includes(normExcerpt)) {
    return { verified: true, matchType: 'normalized' };
  }

  // Token overlap fallback for excerpts with minor punctuation/hyphenation differences
  const words = normExcerpt.split(' ').filter((w) => w.length > 2);
  if (words.length >= 4) {
    const matched = words.filter((w) => normDoc.includes(w)).length;
    if (matched / words.length >= 0.8) {
      return { verified: true, matchType: 'normalized' };
    }
  }

  return { verified: false, matchType: 'unverified' };
}
