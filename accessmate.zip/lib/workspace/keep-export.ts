import type { DocumentAnalysis } from '../types';

export interface KeepNoteExportPayload {
  title: string;
  body: string;
  itemCount: number;
}

/**
 * Formats a document summary, deadlines, and action checklist into a clean,
 * readable note formatted for Google Keep.
 *
 * Note: The Google Keep REST API (keep.googleapis.com) is enterprise-only and
 * requires Workspace domain-wide delegation. This formatter provides a reliable,
 * privacy-preserving alternative for consumer accounts.
 */
export function formatDocumentForGoogleKeep(
  fileName: string,
  analysis: DocumentAnalysis,
  completedIds: ReadonlySet<string>
): KeepNoteExportPayload {
  const lines: string[] = [];
  lines.push(`Document: ${fileName}`);
  lines.push(`Reading Level: ${analysis.readingLevel.toUpperCase()}`);
  lines.push('');
  lines.push('OVERVIEW');
  lines.push(analysis.documentOverview);
  lines.push('');

  if (analysis.deadlines.length > 0) {
    lines.push('IMPORTANT DATES');
    for (const d of analysis.deadlines) {
      const normalized = d.normalizedDate ? ` (${d.normalizedDate})` : ' (Verify exact date)';
      const pageRef = d.pageNumber ? ` [Page ${d.pageNumber}]` : '';
      lines.push(`- ${d.label}: ${d.originalText}${normalized}${pageRef}`);
    }
    lines.push('');
  }

  if (analysis.actionChecklist.length > 0) {
    lines.push('ACTION CHECKLIST');
    for (const item of analysis.actionChecklist) {
      const box = completedIds.has(item.id) ? '[x]' : '[ ]';
      const due = item.dueDate ? ` (Due: ${item.dueDate})` : '';
      lines.push(`${box} ${item.title}${due} — ${item.explanation}`);
    }
    lines.push('');
  }

  if (analysis.uncertainties.length > 0) {
    lines.push('ITEMS TO VERIFY');
    for (const u of analysis.uncertainties) {
      lines.push(`- ${u}`);
    }
  }

  return {
    title: `ACCESSMATE: ${fileName}`,
    body: lines.join('\n').trim(),
    itemCount: analysis.actionChecklist.length + analysis.deadlines.length,
  };
}
