import type { AccessibilityPreferences, ThemeMode } from '../types';

export const ACCESSIBILITY_STORAGE_KEY = 'accessmate_a11y_prefs_v1';

export const DEFAULT_ACCESSIBILITY_PREFERENCES: AccessibilityPreferences = {
  theme: 'light',
  fontScale: 1,
  lineSpacing: 'normal',
  letterSpacing: 'normal',
  reducedMotion: false,
  privacyMode: true,
};

export const FONT_SCALE_MIN = 0.85;
export const FONT_SCALE_MAX = 1.45;
export const FONT_SCALE_STEP = 0.1;

export type AccessibilityAction =
  | { type: 'SET_THEME'; theme: ThemeMode }
  | { type: 'INCREASE_FONT' }
  | { type: 'DECREASE_FONT' }
  | { type: 'SET_FONT_SCALE'; scale: number }
  | { type: 'SET_LINE_SPACING'; spacing: AccessibilityPreferences['lineSpacing'] }
  | { type: 'SET_LETTER_SPACING'; spacing: AccessibilityPreferences['letterSpacing'] }
  | { type: 'TOGGLE_REDUCED_MOTION'; enabled?: boolean }
  | { type: 'TOGGLE_PRIVACY_MODE'; enabled?: boolean }
  | { type: 'RESET' };

export function clampFontScale(value: number): number {
  const clamped = Math.min(FONT_SCALE_MAX, Math.max(FONT_SCALE_MIN, value));
  return Math.round(clamped * 100) / 100;
}

export function accessibilityReducer(
  state: AccessibilityPreferences,
  action: AccessibilityAction
): AccessibilityPreferences {
  switch (action.type) {
    case 'SET_THEME':
      return { ...state, theme: action.theme };
    case 'INCREASE_FONT':
      return { ...state, fontScale: clampFontScale(state.fontScale + FONT_SCALE_STEP) };
    case 'DECREASE_FONT':
      return { ...state, fontScale: clampFontScale(state.fontScale - FONT_SCALE_STEP) };
    case 'SET_FONT_SCALE':
      return { ...state, fontScale: clampFontScale(action.scale) };
    case 'SET_LINE_SPACING':
      return { ...state, lineSpacing: action.spacing };
    case 'SET_LETTER_SPACING':
      return { ...state, letterSpacing: action.spacing };
    case 'TOGGLE_REDUCED_MOTION':
      return {
        ...state,
        reducedMotion:
          typeof action.enabled === 'boolean' ? action.enabled : !state.reducedMotion,
      };
    case 'TOGGLE_PRIVACY_MODE':
      return {
        ...state,
        privacyMode:
          typeof action.enabled === 'boolean' ? action.enabled : !state.privacyMode,
      };
    case 'RESET':
      return { ...DEFAULT_ACCESSIBILITY_PREFERENCES };
    default:
      return state;
  }
}

export function parseStoredPreferences(raw: string | null): AccessibilityPreferences {
  if (!raw) return DEFAULT_ACCESSIBILITY_PREFERENCES;
  try {
    const parsed = JSON.parse(raw) as Partial<AccessibilityPreferences>;
    const validThemes: ThemeMode[] = ['light', 'dark', 'comfortable', 'high-contrast'];
    return {
      theme: validThemes.includes(parsed.theme as ThemeMode)
        ? (parsed.theme as ThemeMode)
        : DEFAULT_ACCESSIBILITY_PREFERENCES.theme,
      fontScale:
        typeof parsed.fontScale === 'number' && Number.isFinite(parsed.fontScale)
          ? clampFontScale(parsed.fontScale)
          : DEFAULT_ACCESSIBILITY_PREFERENCES.fontScale,
      lineSpacing:
        parsed.lineSpacing === 'normal' ||
        parsed.lineSpacing === 'relaxed' ||
        parsed.lineSpacing === 'spacious'
          ? parsed.lineSpacing
          : DEFAULT_ACCESSIBILITY_PREFERENCES.lineSpacing,
      letterSpacing:
        parsed.letterSpacing === 'normal' || parsed.letterSpacing === 'wide'
          ? parsed.letterSpacing
          : DEFAULT_ACCESSIBILITY_PREFERENCES.letterSpacing,
      reducedMotion:
        typeof parsed.reducedMotion === 'boolean'
          ? parsed.reducedMotion
          : DEFAULT_ACCESSIBILITY_PREFERENCES.reducedMotion,
      privacyMode:
        typeof parsed.privacyMode === 'boolean'
          ? parsed.privacyMode
          : DEFAULT_ACCESSIBILITY_PREFERENCES.privacyMode,
    };
  } catch {
    return DEFAULT_ACCESSIBILITY_PREFERENCES;
  }
}

export function getLineHeightValue(spacing: AccessibilityPreferences['lineSpacing']): string {
  switch (spacing) {
    case 'relaxed':
      return '1.8';
    case 'spacious':
      return '2.0';
    default:
      return '1.6';
  }
}
