export interface RateLimitConfig {
  maxRequests: number;
  windowMs: number;
}

export interface RateLimitDecision {
  allowed: boolean;
  remaining: number;
  retryAfterSeconds: number;
}

interface BucketEntry {
  timestamps: number[];
}

/**
 * Sliding-window in-memory rate limiter for protecting server-side AI and
 * upload endpoints against abuse and accidental request floods.
 */
export class SlidingWindowRateLimiter {
  private readonly buckets = new Map<string, BucketEntry>();
  private lastCleanup = Date.now();

  check(key: string, config: RateLimitConfig, nowMs: number = Date.now()): RateLimitDecision {
    const windowStart = nowMs - config.windowMs;
    const entry = this.buckets.get(key) ?? { timestamps: [] };
    entry.timestamps = entry.timestamps.filter((t) => t > windowStart);

    if (entry.timestamps.length >= config.maxRequests) {
      const oldest = entry.timestamps[0] ?? nowMs;
      const retryAfterMs = Math.max(1000, oldest + config.windowMs - nowMs);
      this.buckets.set(key, entry);
      this.maybeCleanup(nowMs, config.windowMs);
      return {
        allowed: false,
        remaining: 0,
        retryAfterSeconds: Math.ceil(retryAfterMs / 1000),
      };
    }

    entry.timestamps.push(nowMs);
    this.buckets.set(key, entry);
    this.maybeCleanup(nowMs, config.windowMs);

    return {
      allowed: true,
      remaining: Math.max(0, config.maxRequests - entry.timestamps.length),
      retryAfterSeconds: 0,
    };
  }

  private maybeCleanup(nowMs: number, windowMs: number): void {
    if (nowMs - this.lastCleanup < Math.max(60_000, windowMs)) return;
    this.lastCleanup = nowMs;
    const cutoff = nowMs - windowMs;
    for (const [key, entry] of this.buckets.entries()) {
      entry.timestamps = entry.timestamps.filter((t) => t > cutoff);
      if (entry.timestamps.length === 0) {
        this.buckets.delete(key);
      }
    }
  }

  reset(): void {
    this.buckets.clear();
  }
}

export const serverRateLimiter = new SlidingWindowRateLimiter();

/**
 * Extracts a normalized client identifier from incoming request headers
 * without logging sensitive personal data.
 */
export function getClientRateLimitKey(req: Request, routeName: string): string {
  const forwarded = req.headers.get('x-forwarded-for');
  const firstIp = forwarded?.split(',')[0]?.trim() || req.headers.get('x-real-ip') || 'local-client';
  return `${routeName}:${firstIp}`;
}
