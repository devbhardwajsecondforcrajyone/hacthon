const SENSITIVE_KEY_PATTERN = /(key|token|secret|password|authorization|text|document|content|excerpt|prompt|email|phone)/i;
const API_KEY_VALUE_PATTERN = /AIza[0-9A-Za-z_-]{16,}|Bearer\s+[A-Za-z0-9._-]+/gi;

/**
 * Redacts credentials, tokens, and document content from structured log metadata
 * so ACCESSMATE never logs original document text, PII, or API keys.
 */
export function redactLogPayload(
  meta: Record<string, unknown>
): Record<string, string | number | boolean | null> {
  const safe: Record<string, string | number | boolean | null> = {};
  for (const [key, value] of Object.entries(meta)) {
    if (SENSITIVE_KEY_PATTERN.test(key)) {
      safe[key] = '[REDACTED]';
      continue;
    }
    if (typeof value === 'string') {
      safe[key] = value.replace(API_KEY_VALUE_PATTERN, '[REDACTED]').slice(0, 160);
    } else if (typeof value === 'number' || typeof value === 'boolean' || value === null) {
      safe[key] = value;
    } else {
      safe[key] = '[OMITTED_OBJECT]';
    }
  }
  return safe;
}

export function logServerEvent(
  level: 'info' | 'warn' | 'error',
  event: string,
  meta: Record<string, unknown> = {}
): void {
  const entry = {
    ts: new Date().toISOString(),
    level,
    event,
    meta: redactLogPayload(meta),
  };
  if (level === 'error') {
    console.error(JSON.stringify(entry));
  } else if (level === 'warn') {
    console.warn(JSON.stringify(entry));
  } else {
    console.info(JSON.stringify(entry));
  }
}
