'use client';

import React, { createContext, useContext, useEffect, useReducer } from 'react';
import type { AccessibilityPreferences } from '@/lib/types';
import {
  ACCESSIBILITY_STORAGE_KEY,
  accessibilityReducer,
  DEFAULT_ACCESSIBILITY_PREFERENCES,
  getLineHeightValue,
  parseStoredPreferences,
  type AccessibilityAction,
} from '@/lib/accessibility/preferences';

interface AccessibilityContextValue {
  prefs: AccessibilityPreferences;
  dispatch: React.Dispatch<AccessibilityAction>;
}

const AccessibilityContext = createContext<AccessibilityContextValue | null>(null);

export function AccessibilityProvider({ children }: { children: React.ReactNode }) {
  const [prefs, dispatch] = useReducer(
    accessibilityReducer,
    DEFAULT_ACCESSIBILITY_PREFERENCES
  );

  // Hydrate saved non-sensitive display preferences and OS reduced-motion preference on mount
  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(ACCESSIBILITY_STORAGE_KEY);
      if (stored) {
        const parsed = parseStoredPreferences(stored);
        dispatch({ type: 'SET_THEME', theme: parsed.theme });
        dispatch({ type: 'SET_FONT_SCALE', scale: parsed.fontScale });
        dispatch({ type: 'SET_LINE_SPACING', spacing: parsed.lineSpacing });
        dispatch({ type: 'SET_LETTER_SPACING', spacing: parsed.letterSpacing });
        dispatch({ type: 'TOGGLE_REDUCED_MOTION', enabled: parsed.reducedMotion });
        dispatch({ type: 'TOGGLE_PRIVACY_MODE', enabled: parsed.privacyMode });
      } else if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) {
        dispatch({ type: 'TOGGLE_REDUCED_MOTION', enabled: true });
      }
    } catch {
      // Ignore storage access errors in restricted browsing modes
    }
  }, []);

  // Apply real visual/behavioral changes directly to <html>
  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('dark', 'theme-comfortable', 'theme-high-contrast', 'reduced-motion');

    if (prefs.theme === 'dark') {
      root.classList.add('dark');
    } else if (prefs.theme === 'comfortable') {
      root.classList.add('theme-comfortable');
    } else if (prefs.theme === 'high-contrast') {
      root.classList.add('theme-high-contrast');
    }

    if (prefs.reducedMotion) {
      root.classList.add('reduced-motion');
    }

    root.style.setProperty('--am-font-scale', String(prefs.fontScale));
    root.style.setProperty('--am-line-height', getLineHeightValue(prefs.lineSpacing));
    root.style.setProperty(
      '--am-letter-spacing',
      prefs.letterSpacing === 'wide' ? '0.04em' : '0em'
    );
    root.style.setProperty(
      '--am-word-spacing',
      prefs.letterSpacing === 'wide' ? '0.12em' : '0em'
    );

    try {
      window.localStorage.setItem(ACCESSIBILITY_STORAGE_KEY, JSON.stringify(prefs));
    } catch {
      // Non-fatal
    }
  }, [prefs]);

  return (
    <AccessibilityContext.Provider value={{ prefs, dispatch }}>
      {children}
    </AccessibilityContext.Provider>
  );
}

export function useAccessibility(): AccessibilityContextValue {
  const ctx = useContext(AccessibilityContext);
  if (!ctx) {
    throw new Error('useAccessibility must be used inside AccessibilityProvider.');
  }
  return ctx;
}
