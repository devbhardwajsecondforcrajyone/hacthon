'use client';

import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import type { User } from 'firebase/auth';
import type { ReadingLevel } from '@/lib/config';
import type {
  AnalyzeApiResponse,
  DocumentAnalysis,
  ExtractedDocument,
  NavSection,
  PerformanceMetric,
  QAMessage,
  TranslatedContent,
  WorkspaceTab,
} from '@/lib/types';
import {
  getWorkspaceAccessToken,
  initWorkspaceAuth,
  signInWithGoogleWorkspace,
  signOutWorkspace,
} from '@/lib/workspace/firebase-auth';

export interface ProcessingStatus {
  phase: 'idle' | 'extracting' | 'analyzing' | 'translating' | 'answering';
  message: string;
}

interface DocumentSessionContextValue {
  activeNav: NavSection;
  setActiveNav: (nav: NavSection) => void;
  activeTab: WorkspaceTab;
  setActiveTab: (tab: WorkspaceTab) => void;

  document: ExtractedDocument | null;
  readingLevel: ReadingLevel;
  deepReasoning: boolean;
  setDeepReasoning: (enabled: boolean) => void;

  analysis: DocumentAnalysis | null;
  analysisMeta: AnalyzeApiResponse['meta'] | null;
  selectedLanguageCode: string;
  translation: TranslatedContent | null;
  completedChecklistIds: Set<string>;
  qaMessages: QAMessage[];
  metrics: PerformanceMetric[];

  status: ProcessingStatus;
  errorMessage: string | null;
  announcement: string;
  clearError: () => void;
  announce: (msg: string) => void;

  processUploadedFile: (file: File) => Promise<void>;
  processPastedText: (text: string, title?: string) => Promise<void>;
  switchReadingLevel: (level: ReadingLevel) => Promise<void>;
  reanalyzeCurrentDocument: (overrideDeep?: boolean) => Promise<void>;
  translateToLanguage: (langCode: string) => Promise<void>;
  askDocumentQuestion: (question: string, includeSearchContext: boolean) => Promise<void>;
  cancelActiveRequest: () => void;

  toggleChecklistItem: (id: string) => void;
  resetChecklist: () => void;
  clearSession: () => void;

  // Workspace Auth (strictly in-memory token)
  workspaceUser: User | null;
  workspaceToken: string | null;
  isSigningInWorkspace: boolean;
  workspaceAuthError: string | null;
  connectGoogleWorkspace: () => Promise<string | null>;
  disconnectGoogleWorkspace: () => Promise<void>;
}

const DocumentSessionContext = createContext<DocumentSessionContextValue | null>(null);

export function DocumentSessionProvider({ children }: { children: React.ReactNode }) {
  const [activeNav, setActiveNav] = useState<NavSection>('dashboard');
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('overview');

  const [document, setDocument] = useState<ExtractedDocument | null>(null);
  const [readingLevel, setReadingLevel] = useState<ReadingLevel>('simple');
  const [deepReasoning, setDeepReasoning] = useState<boolean>(false);

  const [analysis, setAnalysis] = useState<DocumentAnalysis | null>(null);
  const [analysisMeta, setAnalysisMeta] = useState<AnalyzeApiResponse['meta'] | null>(null);
  const [selectedLanguageCode, setSelectedLanguageCode] = useState<string>('en');
  const [translation, setTranslation] = useState<TranslatedContent | null>(null);

  const [completedChecklistIds, setCompletedChecklistIds] = useState<Set<string>>(new Set());
  const [qaMessages, setQaMessages] = useState<QAMessage[]>([]);
  const [metrics, setMetrics] = useState<PerformanceMetric[]>([]);

  const [status, setStatus] = useState<ProcessingStatus>({ phase: 'idle', message: '' });
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [announcement, setAnnouncement] = useState<string>('');

  // Workspace Auth state
  const [workspaceUser, setWorkspaceUser] = useState<User | null>(null);
  const [workspaceToken, setWorkspaceToken] = useState<string | null>(null);
  const [isSigningInWorkspace, setIsSigningInWorkspace] = useState<boolean>(false);
  const [workspaceAuthError, setWorkspaceAuthError] = useState<string | null>(null);

  // Privacy-safe in-memory session caches (wiped on document change or Clear Session)
  const analysisCacheRef = useRef<Map<string, AnalyzeApiResponse>>(new Map());
  const translationCacheRef = useRef<Map<string, TranslatedContent>>(new Map());
  const abortControllerRef = useRef<AbortController | null>(null);

  const announce = useCallback((msg: string) => {
    setAnnouncement('');
    window.setTimeout(() => setAnnouncement(msg), 40);
  }, []);

  const recordMetric = useCallback((metric: Omit<PerformanceMetric, 'id' | 'timestamp'>) => {
    setMetrics((prev) => [
      {
        ...metric,
        id: `m_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        timestamp: new Date().toISOString(),
      },
      ...prev.slice(0, 29),
    ]);
  }, []);

  const clearError = useCallback(() => setErrorMessage(null), []);

  const cancelActiveRequest = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
      setStatus({ phase: 'idle', message: '' });
      announce('Operation cancelled.');
    }
  }, [announce]);

  useEffect(() => {
    const unsubscribe = initWorkspaceAuth(
      (user, token) => {
        setWorkspaceUser(user);
        setWorkspaceToken(token);
      },
      () => {
        setWorkspaceUser(null);
        setWorkspaceToken(null);
      }
    );
    return () => {
      unsubscribe();
      abortControllerRef.current?.abort();
    };
  }, []);

  const runAnalysisForDoc = useCallback(
    async (
      doc: ExtractedDocument,
      targetLevel: ReadingLevel,
      useDeepReasoning: boolean
    ) => {
      const cacheKey = `${doc.contentHash}:${targetLevel}:${useDeepReasoning ? 'deep' : 'std'}`;
      const cached = analysisCacheRef.current.get(cacheKey);
      if (cached) {
        setAnalysis(cached.analysis);
        setAnalysisMeta({ ...cached.meta, cached: true });
        setReadingLevel(targetLevel);
        setTranslation(null);
        setSelectedLanguageCode('en');
        recordMetric({
          operation: 'analyze',
          durationMs: 1,
          cached: true,
          modelUsed: cached.meta.modelUsed,
          inputChars: doc.charCount,
          outputChars: JSON.stringify(cached.analysis).length,
          chunksProcessed: cached.meta.chunksProcessed,
        });
        announce(`Loaded cached ${targetLevel} explanation.`);
        return;
      }

      abortControllerRef.current?.abort();
      const controller = new AbortController();
      abortControllerRef.current = controller;

      setErrorMessage(null);
      setStatus({
        phase: 'analyzing',
        message: useDeepReasoning
          ? `Running deep reasoning analysis (${targetLevel} reading level)...`
          : `Analyzing document at ${targetLevel} reading level...`,
      });

      try {
        const res = await fetch('/api/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify({
            fileName: doc.fileName,
            fullText: doc.fullText,
            pages: doc.pages,
            readingLevel: targetLevel,
            deepReasoning: useDeepReasoning,
          }),
        });

        const payload = (await res.json().catch(() => ({}))) as Partial<AnalyzeApiResponse> & {
          error?: string;
        };

        if (!res.ok || !payload.analysis || !payload.meta) {
          throw new Error(
            payload.error || 'Could not complete AI analysis. Please try again.'
          );
        }

        const fullResult: AnalyzeApiResponse = {
          analysis: payload.analysis,
          meta: payload.meta,
        };

        analysisCacheRef.current.set(cacheKey, fullResult);
        setAnalysis(fullResult.analysis);
        setAnalysisMeta(fullResult.meta);
        setReadingLevel(targetLevel);
        setTranslation(null);
        setSelectedLanguageCode('en');
        setCompletedChecklistIds(new Set());

        recordMetric({
          operation: 'analyze',
          durationMs: fullResult.meta.durationMs,
          cached: false,
          modelUsed: fullResult.meta.modelUsed,
          inputChars: doc.charCount,
          outputChars: JSON.stringify(fullResult.analysis).length,
          chunksProcessed: fullResult.meta.chunksProcessed,
        });

        announce(
          `Document analyzed. Found ${fullResult.analysis.deadlines.length} important date(s) and ${fullResult.analysis.actionChecklist.length} action item(s).`
        );
      } catch (error) {
        if ((error as Error)?.name === 'AbortError') return;
        const msg =
          error instanceof Error ? error.message : 'Unexpected error analyzing document.';
        setErrorMessage(msg);
        announce(`Error: ${msg}`);
      } finally {
        if (abortControllerRef.current === controller) {
          abortControllerRef.current = null;
          setStatus({ phase: 'idle', message: '' });
        }
      }
    },
    [announce, recordMetric]
  );

  const resetDocumentCaches = useCallback(() => {
    analysisCacheRef.current.clear();
    translationCacheRef.current.clear();
    setAnalysis(null);
    setAnalysisMeta(null);
    setTranslation(null);
    setSelectedLanguageCode('en');
    setCompletedChecklistIds(new Set());
    setQaMessages([]);
  }, []);

  const processUploadedFile = useCallback(
    async (file: File) => {
      abortControllerRef.current?.abort();
      const controller = new AbortController();
      abortControllerRef.current = controller;

      setErrorMessage(null);
      setStatus({
        phase: 'extracting',
        message: `Validating signature and extracting readable text from ${file.name}...`,
      });

      try {
        const formData = new FormData();
        formData.append('file', file);

        const res = await fetch('/api/extract', {
          method: 'POST',
          body: formData,
          signal: controller.signal,
        });

        const payload = (await res.json().catch(() => ({}))) as {
          document?: ExtractedDocument;
          error?: string;
        };

        if (!res.ok || !payload.document) {
          throw new Error(payload.error || 'Could not extract text from this file.');
        }

        const extracted = payload.document;
        resetDocumentCaches();
        setDocument(extracted);
        recordMetric({
          operation: 'extract',
          durationMs: extracted.extractionTimeMs,
          cached: false,
          inputChars: extracted.sizeBytes,
          outputChars: extracted.charCount,
        });

        setActiveNav('workspace');
        setActiveTab('overview');
        await runAnalysisForDoc(extracted, readingLevel, deepReasoning);
      } catch (error) {
        if ((error as Error)?.name === 'AbortError') return;
        const msg = error instanceof Error ? error.message : 'File processing failed.';
        setErrorMessage(msg);
        announce(`Error: ${msg}`);
        setStatus({ phase: 'idle', message: '' });
      }
    },
    [announce, deepReasoning, readingLevel, recordMetric, resetDocumentCaches, runAnalysisForDoc]
  );

  const processPastedText = useCallback(
    async (text: string, title?: string) => {
      if (!text.trim()) {
        const msg = 'Please paste or enter document text before starting analysis.';
        setErrorMessage(msg);
        announce(`Error: ${msg}`);
        return;
      }

      abortControllerRef.current?.abort();
      const controller = new AbortController();
      abortControllerRef.current = controller;

      setErrorMessage(null);
      setStatus({
        phase: 'extracting',
        message: 'Validating and structuring document text...',
      });

      try {
        const res = await fetch('/api/extract', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify({ text, title }),
        });

        const payload = (await res.json().catch(() => ({}))) as {
          document?: ExtractedDocument;
          error?: string;
        };

        if (!res.ok || !payload.document) {
          throw new Error(payload.error || 'Could not process pasted text.');
        }

        const extracted = payload.document;
        resetDocumentCaches();
        setDocument(extracted);
        recordMetric({
          operation: 'extract',
          durationMs: extracted.extractionTimeMs,
          cached: false,
          inputChars: extracted.sizeBytes,
          outputChars: extracted.charCount,
        });

        setActiveNav('workspace');
        setActiveTab('overview');
        await runAnalysisForDoc(extracted, readingLevel, deepReasoning);
      } catch (error) {
        if ((error as Error)?.name === 'AbortError') return;
        const msg = error instanceof Error ? error.message : 'Text extraction failed.';
        setErrorMessage(msg);
        announce(`Error: ${msg}`);
        setStatus({ phase: 'idle', message: '' });
      }
    },
    [announce, deepReasoning, readingLevel, recordMetric, resetDocumentCaches, runAnalysisForDoc]
  );

  const switchReadingLevel = useCallback(
    async (level: ReadingLevel) => {
      setReadingLevel(level);
      if (document) {
        await runAnalysisForDoc(document, level, deepReasoning);
      }
    },
    [deepReasoning, document, runAnalysisForDoc]
  );

  const reanalyzeCurrentDocument = useCallback(
    async (overrideDeep?: boolean) => {
      if (!document) return;
      const nextDeep = typeof overrideDeep === 'boolean' ? overrideDeep : deepReasoning;
      if (typeof overrideDeep === 'boolean') {
        setDeepReasoning(overrideDeep);
      }
      await runAnalysisForDoc(document, readingLevel, nextDeep);
    },
    [deepReasoning, document, readingLevel, runAnalysisForDoc]
  );

  const translateToLanguage = useCallback(
    async (langCode: string) => {
      if (!document || !analysis) return;

      setSelectedLanguageCode(langCode);
      if (langCode === 'en' && analysis.detectedLanguage.toLowerCase().includes('english')) {
        setTranslation(null);
        announce('Showing original English analysis.');
        return;
      }

      const cacheKey = `${document.contentHash}:${readingLevel}:${langCode}`;
      const cached = translationCacheRef.current.get(cacheKey);
      if (cached) {
        setTranslation(cached);
        recordMetric({
          operation: 'translate',
          durationMs: 1,
          cached: true,
          inputChars: analysis.summary.length,
          outputChars: cached.summary.length,
        });
        announce(`Loaded cached ${cached.targetLanguageName} translation.`);
        return;
      }

      abortControllerRef.current?.abort();
      const controller = new AbortController();
      abortControllerRef.current = controller;

      setErrorMessage(null);
      setStatus({
        phase: 'translating',
        message: 'Translating summary, instructions, and checklist while preserving exact dates and numbers...',
      });

      try {
        const res = await fetch('/api/translate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify({
            analysis,
            targetLanguageCode: langCode,
          }),
        });

        const payload = (await res.json().catch(() => ({}))) as {
          translation?: TranslatedContent;
          meta?: { modelUsed: string; durationMs: number };
          error?: string;
        };

        if (!res.ok || !payload.translation) {
          throw new Error(
            payload.error || 'Translation failed. The original language summary remains visible.'
          );
        }

        translationCacheRef.current.set(cacheKey, payload.translation);
        setTranslation(payload.translation);
        recordMetric({
          operation: 'translate',
          durationMs: payload.meta?.durationMs ?? 0,
          cached: false,
          modelUsed: payload.meta?.modelUsed,
          inputChars: analysis.summary.length,
          outputChars: payload.translation.summary.length,
        });
        announce(`Translated document into ${payload.translation.targetLanguageName}.`);
      } catch (error) {
        if ((error as Error)?.name === 'AbortError') return;
        const msg = error instanceof Error ? error.message : 'Translation failed.';
        setErrorMessage(msg);
        announce(`Error: ${msg}`);
      } finally {
        if (abortControllerRef.current === controller) {
          abortControllerRef.current = null;
          setStatus({ phase: 'idle', message: '' });
        }
      }
    },
    [analysis, announce, document, readingLevel, recordMetric]
  );

  const askDocumentQuestion = useCallback(
    async (question: string, includeSearchContext: boolean) => {
      if (!document) return;
      const trimmed = question.trim();
      if (!trimmed) return;

      abortControllerRef.current?.abort();
      const controller = new AbortController();
      abortControllerRef.current = controller;

      setErrorMessage(null);
      setStatus({
        phase: 'answering',
        message: includeSearchContext
          ? 'Checking document evidence and optional public web context...'
          : 'Searching document text for verified answer...',
      });

      try {
        const res = await fetch('/api/qa', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify({
            question: trimmed,
            fullText: document.fullText,
            includeSearchContext,
          }),
        });

        const payload = (await res.json().catch(() => ({}))) as {
          answer?: QAMessage['response'];
          meta?: { modelUsed: string; durationMs: number };
          error?: string;
        };

        if (!res.ok || !payload.answer) {
          throw new Error(payload.error || 'Could not answer this question.');
        }

        const msgEntry: QAMessage = {
          id: `qa_${Date.now()}`,
          question: trimmed,
          usedSearchGrounding: includeSearchContext,
          response: payload.answer,
          durationMs: payload.meta?.durationMs ?? 0,
          createdAt: new Date().toISOString(),
        };

        setQaMessages((prev) => [msgEntry, ...prev]);
        recordMetric({
          operation: 'qa',
          durationMs: msgEntry.durationMs,
          cached: false,
          modelUsed: payload.meta?.modelUsed,
          inputChars: trimmed.length,
          outputChars: payload.answer.directAnswer.length,
        });
        announce(
          payload.answer.foundInDocument
            ? 'Answer found in document.'
            : 'Information not found in the uploaded document.'
        );
      } catch (error) {
        if ((error as Error)?.name === 'AbortError') return;
        const msg = error instanceof Error ? error.message : 'Question failed.';
        setErrorMessage(msg);
        announce(`Error: ${msg}`);
      } finally {
        if (abortControllerRef.current === controller) {
          abortControllerRef.current = null;
          setStatus({ phase: 'idle', message: '' });
        }
      }
    },
    [announce, document, recordMetric]
  );

  const toggleChecklistItem = useCallback((id: string) => {
    setCompletedChecklistIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }, []);

  const resetChecklist = useCallback(() => {
    setCompletedChecklistIds(new Set());
    announce('Checklist progress reset.');
  }, [announce]);

  const clearSession = useCallback(() => {
    abortControllerRef.current?.abort();
    abortControllerRef.current = null;
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    resetDocumentCaches();
    setDocument(null);
    setErrorMessage(null);
    setStatus({ phase: 'idle', message: '' });
    setActiveNav('dashboard');
    setActiveTab('overview');
    announce('Document deleted and session cleared from memory.');
  }, [announce, resetDocumentCaches]);

  const connectGoogleWorkspace = useCallback(async (): Promise<string | null> => {
    const existing = getWorkspaceAccessToken();
    if (existing) {
      setWorkspaceToken(existing);
      return existing;
    }
    setIsSigningInWorkspace(true);
    setWorkspaceAuthError(null);
    try {
      const res = await signInWithGoogleWorkspace();
      setWorkspaceUser(res.user);
      setWorkspaceToken(res.accessToken);
      announce('Connected Google Calendar and Google Tasks.');
      return res.accessToken;
    } catch (error) {
      const msg =
        error instanceof Error
          ? error.message
          : 'Google sign-in was cancelled or failed.';
      setWorkspaceAuthError(msg);
      return null;
    } finally {
      setIsSigningInWorkspace(false);
    }
  }, [announce]);

  const disconnectGoogleWorkspace = useCallback(async () => {
    await signOutWorkspace();
    setWorkspaceUser(null);
    setWorkspaceToken(null);
    announce('Signed out of Google Workspace.');
  }, [announce]);

  return (
    <DocumentSessionContext.Provider
      value={{
        activeNav,
        setActiveNav,
        activeTab,
        setActiveTab,
        document,
        readingLevel,
        deepReasoning,
        setDeepReasoning,
        analysis,
        analysisMeta,
        selectedLanguageCode,
        translation,
        completedChecklistIds,
        qaMessages,
        metrics,
        status,
        errorMessage,
        announcement,
        clearError,
        announce,
        processUploadedFile,
        processPastedText,
        switchReadingLevel,
        reanalyzeCurrentDocument,
        translateToLanguage,
        askDocumentQuestion,
        cancelActiveRequest,
        toggleChecklistItem,
        resetChecklist,
        clearSession,
        workspaceUser,
        workspaceToken,
        isSigningInWorkspace,
        workspaceAuthError,
        connectGoogleWorkspace,
        disconnectGoogleWorkspace,
      }}
    >
      {children}
    </DocumentSessionContext.Provider>
  );
}

export function useDocumentSession(): DocumentSessionContextValue {
  const ctx = useContext(DocumentSessionContext);
  if (!ctx) {
    throw new Error('useDocumentSession must be used inside DocumentSessionProvider.');
  }
  return ctx;
}
