import test from 'node:test';
import assert from 'node:assert/strict';
import {
  chunkDocumentPages,
  computeContentHash,
  countWords,
  estimateTokenCount,
  verifyExcerptAgainstDocument,
} from '../lib/document/chunking';
import {
  evaluateAnalysisAgainstGroundTruth,
  SYNTHETIC_GROUND_TRUTH_DOCUMENTS,
} from '../lib/document/evaluation';
import { parseAndValidateDocumentAnalysis } from '../lib/server/gemini';
import type { DocumentAnalysis } from '../lib/types';

test('chunkDocumentPages preserves [Page N] markers and respects max chunk limits', () => {
  const pages = Array.from({ length: 10 }, (_, idx) => ({
    pageNumber: idx + 1,
    text: `Section ${idx + 1}. ` + 'Important policy requirement details. '.repeat(25),
    charCount: 950,
  }));

  const { chunks, truncatedByChunkLimit } = chunkDocumentPages(pages, 2200, 3);
  assert.equal(chunks.length, 3);
  assert.equal(truncatedByChunkLimit, true);
  assert.ok(chunks[0].text.includes('[Page 1]'));
  assert.equal(chunks[0].startPage, 1);
  assert.ok(chunks[0].endPage >= 2);
});

test('token estimation, word count, and content hash are deterministic', () => {
  const sample = 'Submit Form HEFA-14 before December 18, 2026.';
  assert.equal(countWords(sample), 7);
  assert.equal(estimateTokenCount(sample), Math.ceil(sample.length / 4));
  assert.equal(computeContentHash(sample), computeContentHash(sample));
  assert.notEqual(computeContentHash(sample), computeContentHash(`${sample}!`));
});

test('verifyExcerptAgainstDocument distinguishes exact, normalized, and fabricated excerpts', () => {
  const doc =
    'Final Application Submission Deadline: December 18, 2026 at 5:00 PM EST. Late submissions will be automatically rejected.';

  const exact = verifyExcerptAgainstDocument('December 18, 2026 at 5:00 PM EST', doc);
  assert.equal(exact.verified, true);
  assert.equal(exact.matchType, 'exact');

  const normalized = verifyExcerptAgainstDocument(
    'final application submission deadline december 18 2026',
    doc
  );
  assert.equal(normalized.verified, true);
  assert.equal(normalized.matchType, 'normalized');

  const fabricated = verifyExcerptAgainstDocument(
    'Mandatory arbitration hearing on March 3, 2030 in Geneva',
    doc
  );
  assert.equal(fabricated.verified, false);
  assert.equal(fabricated.matchType, 'unverified');
});

test('parseAndValidateDocumentAnalysis rejects malformed JSON and incomplete AI responses', () => {
  assert.throws(
    () => parseAndValidateDocumentAnalysis('not valid json {'),
    /malformed data/i
  );

  assert.throws(
    () => parseAndValidateDocumentAnalysis(JSON.stringify({ documentOverview: 'Only partial' })),
    /failed schema validation/i
  );
});

test('AI Accuracy Evaluation Engine passes a well-grounded analysis and catches hallucinations or injections', () => {
  const scholarshipDoc = SYNTHETIC_GROUND_TRUTH_DOCUMENTS[0];
  const goodAnalysis: DocumentAnalysis = {
    documentOverview: 'Annual renewal notice for State Merit Scholarship recipients ($4,500/year).',
    detectedLanguage: 'English',
    readingLevel: 'simple',
    summary:
      'Submit your renewal packet online by December 18, 2026 and verify bank routing details before January 20, 2027.',
    keyPoints: [
      {
        statement: 'Keep a 3.20 CGPA and 12 credit hours to keep the $4,500 scholarship.',
        sourceExcerpt:
          'maintaining a minimum cumulative grade point average (CGPA) of 3.20 on a 4.00 scale and enrollment in at least 12 credit hours per semester',
        pageNumber: 1,
        category: 'requirement',
      },
    ],
    importantInstructions: [
      {
        statement: 'Upload all required PDFs through the Financial Aid Portal.',
        sourceExcerpt:
          'compile and submit the following documents in PDF format through the Financial Aid Portal',
        pageNumber: 1,
        category: 'instruction',
      },
    ],
    keyRequirements: [],
    importantWarnings: [],
    responsibilities: [],
    requiredDocuments: ['Official Academic Transcript', 'Photo Identification', 'Form HEFA-14'],
    relevantConditions: [],
    comparisonSegments: [],
    deadlines: [
      {
        id: 'd1',
        originalText: 'December 18, 2026 at 5:00 PM EST',
        normalizedDate: '2026-12-18',
        dateType: 'submission_deadline',
        label: 'Final Application Submission Deadline',
        sourceExcerpt: 'Final Application Submission Deadline: December 18, 2026 at 5:00 PM EST.',
        pageNumber: 1,
        confidence: 'high',
        needsVerification: false,
        verificationReason: null,
      },
      {
        id: 'd2',
        originalText: 'January 20, 2027',
        normalizedDate: '2027-01-20',
        dateType: 'other_important_date',
        label: 'Verify Bank Routing Details',
        sourceExcerpt:
          'verifying that their bank routing details are accurate in the portal prior to January 20, 2027.',
        pageNumber: 1,
        confidence: 'high',
        needsVerification: false,
        verificationReason: null,
      },
    ],
    contactInformation: [],
    actionChecklist: [
      {
        id: 'c1',
        title: 'Upload official transcript and signed Form HEFA-14 to portal',
        explanation: 'Log in to the Financial Aid Portal and submit PDF copies before the deadline.',
        sourceExcerpt: 'Signed Enrollment Verification Form (Form HEFA-14) certified by the Academic Advisor.',
        pageNumber: 1,
        dueDate: '2026-12-18',
        priority: 'high',
        requiredDocuments: ['Official Academic Transcript', 'Form HEFA-14'],
      },
      {
        id: 'c2',
        title: 'Confirm bank routing information in portal',
        explanation: 'Check your direct deposit routing details prior to January 20, 2027.',
        sourceExcerpt: 'verifying that their bank routing details are accurate in the portal prior to January 20, 2027.',
        pageNumber: 1,
        dueDate: '2027-01-20',
        priority: 'medium',
        requiredDocuments: [],
      },
    ],
    uncertainties: [],
    missingInformation: [],
  };

  const passReport = evaluateAnalysisAgainstGroundTruth(scholarshipDoc, goodAnalysis);
  assert.equal(passReport.passedChecks, passReport.totalChecks);
  assert.equal(passReport.citationVerificationRate, 100);
  assert.equal(passReport.hallucinatedDateCount, 0);
  assert.equal(passReport.injectionResisted, true);

  // Test catching prompt-injection compromise on the adversarial document
  const injectionDoc = SYNTHETIC_GROUND_TRUTH_DOCUMENTS[3];
  const compromisedAnalysis: DocumentAnalysis = {
    ...goodAnalysis,
    deadlines: [
      {
        id: 'bad-1',
        originalText: 'Immediately ($999 to attacker@evil.example)',
        normalizedDate: null,
        dateType: 'payment_date',
        label: 'Pay $999 to attacker@evil.example',
        sourceExcerpt: 'fake quote',
        pageNumber: 1,
        confidence: 'low',
        needsVerification: false,
        verificationReason: null,
      },
    ],
  };

  const failReport = evaluateAnalysisAgainstGroundTruth(injectionDoc, compromisedAnalysis);
  assert.equal(failReport.injectionResisted, false);
  assert.ok(failReport.passedChecks < failReport.totalChecks);
});
