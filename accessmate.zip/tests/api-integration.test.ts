import test from 'node:test';
import assert from 'node:assert/strict';
import { NextRequest } from 'next/server';
import { POST as extractPost } from '../app/api/extract/route';
import { POST as analyzePost } from '../app/api/analyze/route';
import { POST as translatePost } from '../app/api/translate/route';
import { POST as qaPost } from '../app/api/qa/route';
import { POST as calendarPost } from '../app/api/workspace/calendar/route';
import { POST as tasksPost } from '../app/api/workspace/tasks/route';
import { serverRateLimiter } from '../lib/server/rate-limit';

test.beforeEach(() => {
  serverRateLimiter.reset();
});

test('POST /api/extract processes valid pasted text and returns normalized document', async () => {
  const req = new NextRequest('http://localhost:3000/api/extract', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      title: 'Public Notice',
      text: 'Applicants must submit Form HEFA-14 and an official transcript before December 18, 2026.',
    }),
  });

  const res = await extractPost(req);
  assert.equal(res.status, 200);
  const body = (await res.json()) as { document: { fileName: string; wordCount: number; contentHash: string } };
  assert.equal(body.document.fileName, 'Public Notice.txt');
  assert.ok(body.document.wordCount >= 10);
  assert.ok(body.document.contentHash.length > 0);
});

test('POST /api/extract rejects empty paste text and spoofed PDF uploads', async () => {
  const emptyReq = new NextRequest('http://localhost:3000/api/extract', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: '   ' }),
  });
  const emptyRes = await extractPost(emptyReq);
  assert.equal(emptyRes.status, 400);

  const formData = new FormData();
  const spoofedFile = new File(['<script>alert(1)</script>'], 'evil.pdf', {
    type: 'application/pdf',
  });
  formData.append('file', spoofedFile);

  const uploadReq = new NextRequest('http://localhost:3000/api/extract', {
    method: 'POST',
    body: formData,
  });
  const uploadRes = await extractPost(uploadReq);
  assert.equal(uploadRes.status, 400);
  const errBody = (await uploadRes.json()) as { code: string };
  assert.equal(errBody.code, 'INVALID_SIGNATURE');
});

test('POST /api/analyze rejects invalid payloads before touching Gemini', async () => {
  const req = new NextRequest('http://localhost:3000/api/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      fileName: 'short.txt',
      fullText: 'Too short',
      pages: [{ pageNumber: 1, text: 'Too short', charCount: 9 }],
      readingLevel: 'simple',
    }),
  });
  const res = await analyzePost(req);
  assert.equal(res.status, 400);
});

test('POST /api/translate rejects unsupported language codes cleanly', async () => {
  const minimalAnalysis = {
    documentOverview: 'Overview',
    detectedLanguage: 'English',
    readingLevel: 'simple',
    summary: 'Summary',
    keyPoints: [],
    importantInstructions: [],
    keyRequirements: [],
    importantWarnings: [],
    responsibilities: [],
    requiredDocuments: [],
    relevantConditions: [],
    comparisonSegments: [],
    deadlines: [],
    contactInformation: [],
    actionChecklist: [],
    uncertainties: [],
    missingInformation: [],
  };

  const req = new NextRequest('http://localhost:3000/api/translate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      analysis: minimalAnalysis,
      targetLanguageCode: 'xx-unsupported',
    }),
  });
  const res = await translatePost(req);
  assert.equal(res.status, 400);
});

test('POST /api/qa validates minimum question length', async () => {
  const req = new NextRequest('http://localhost:3000/api/qa', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      question: '?',
      fullText: 'This is a valid document with more than twenty five characters.',
      includeSearchContext: false,
    }),
  });
  const res = await qaPost(req);
  assert.equal(res.status, 400);
});

test('POST /api/workspace/calendar and /api/workspace/tasks require Bearer authentication', async () => {
  const calReq = new NextRequest('http://localhost:3000/api/workspace/calendar', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ summary: 'Test', date: '2026-12-18' }),
  });
  const calRes = await calendarPost(calReq);
  assert.equal(calRes.status, 401);

  const taskReq = new NextRequest('http://localhost:3000/api/workspace/tasks', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ items: [{ title: 'Submit Form' }] }),
  });
  const taskRes = await tasksPost(taskReq);
  assert.equal(taskRes.status, 401);
});
