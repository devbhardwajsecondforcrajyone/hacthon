import test from 'node:test';
import assert from 'node:assert/strict';
import {
  accessibilityReducer,
  DEFAULT_ACCESSIBILITY_PREFERENCES,
  FONT_SCALE_MAX,
  FONT_SCALE_MIN,
  parseStoredPreferences,
} from '../lib/accessibility/preferences';
import { SlidingWindowRateLimiter } from '../lib/server/rate-limit';
import { redactLogPayload } from '../lib/server/logger';
import { formatDocumentForGoogleKeep } from '../lib/workspace/keep-export';
import {
  DocumentExtractionError,
  extractFromPastedText,
  extractTextFromTxtBuffer,
} from '../lib/document/extraction';
import type { DocumentAnalysis } from '../lib/types';

test('accessibilityReducer updates theme, font scale bounds, spacing, reduced motion, and reset', () => {
  let state = DEFAULT_ACCESSIBILITY_PREFERENCES;

  state = accessibilityReducer(state, { type: 'SET_THEME', theme: 'high-contrast' });
  assert.equal(state.theme, 'high-contrast');

  for (let i = 0; i < 20; i++) {
    state = accessibilityReducer(state, { type: 'INCREASE_FONT' });
  }
  assert.equal(state.fontScale, FONT_SCALE_MAX);

  for (let i = 0; i < 30; i++) {
    state = accessibilityReducer(state, { type: 'DECREASE_FONT' });
  }
  assert.equal(state.fontScale, FONT_SCALE_MIN);

  state = accessibilityReducer(state, { type: 'SET_LINE_SPACING', spacing: 'spacious' });
  state = accessibilityReducer(state, { type: 'SET_LETTER_SPACING', spacing: 'wide' });
  state = accessibilityReducer(state, { type: 'TOGGLE_REDUCED_MOTION', enabled: true });
  assert.equal(state.lineSpacing, 'spacious');
  assert.equal(state.letterSpacing, 'wide');
  assert.equal(state.reducedMotion, true);

  state = accessibilityReducer(state, { type: 'RESET' });
  assert.deepEqual(state, DEFAULT_ACCESSIBILITY_PREFERENCES);
});

test('parseStoredPreferences safely recovers from corrupted or out-of-range storage values', () => {
  assert.deepEqual(parseStoredPreferences('{broken json'), DEFAULT_ACCESSIBILITY_PREFERENCES);
  const parsed = parseStoredPreferences(
    JSON.stringify({ theme: 'invalid-theme', fontScale: 99, reducedMotion: true })
  );
  assert.equal(parsed.theme, 'light');
  assert.equal(parsed.fontScale, FONT_SCALE_MAX);
  assert.equal(parsed.reducedMotion, true);
});

test('SlidingWindowRateLimiter enforces request ceilings and resets after the window passes', () => {
  const limiter = new SlidingWindowRateLimiter();
  const cfg = { maxRequests: 2, windowMs: 10_000 };

  const r1 = limiter.check('client-1', cfg, 1000);
  const r2 = limiter.check('client-1', cfg, 2000);
  const r3 = limiter.check('client-1', cfg, 3000);

  assert.equal(r1.allowed, true);
  assert.equal(r2.allowed, true);
  assert.equal(r3.allowed, false);
  assert.ok(r3.retryAfterSeconds >= 8);

  // After window expires
  const r4 = limiter.check('client-1', cfg, 12_500);
  assert.equal(r4.allowed, true);
});

test('redactLogPayload strips API keys, bearer tokens, document content, and PII fields', () => {
  const safe = redactLogPayload({
    apiKey: 'AIzaSyFakeSecretValue1234567890',
    authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.secret',
    documentText: 'Private patient medical record',
    email: 'patient@example.com',
    note: 'Failed with AIzaSyFakeSecretValue1234567890 inline',
    durationMs: 245,
  });

  assert.equal(safe.apiKey, '[REDACTED]');
  assert.equal(safe.authorization, '[REDACTED]');
  assert.equal(safe.documentText, '[REDACTED]');
  assert.equal(safe.email, '[REDACTED]');
  assert.equal(safe.note, 'Failed with [REDACTED] inline');
  assert.equal(safe.durationMs, 245);
});

test('extractFromPastedText and extractTextFromTxtBuffer extract text and reject empty inputs', () => {
  const doc = extractFromPastedText(
    'Submit Form HEFA-14 and your transcript by December 18, 2026 to retain eligibility.',
    'Scholarship Notice'
  );
  assert.equal(doc.fileName, 'Scholarship Notice.txt');
  assert.equal(doc.pageCount, 1);
  assert.ok(doc.wordCount >= 10);
  assert.ok(doc.contentHash.length > 0);

  const bytes = new TextEncoder().encode(
    'Clinic appointment on December 4, 2026 at 10:30 AM. Fast for 6 hours before arrival.'
  );
  const txtDoc = extractTextFromTxtBuffer(bytes, 'clinic.txt');
  assert.equal(txtDoc.sourceType, 'txt');
  assert.equal(txtDoc.fileName, 'clinic.txt');

  assert.throws(
    () => extractFromPastedText('short'),
    (err: unknown) => err instanceof DocumentExtractionError && err.code === 'EMPTY_DOCUMENT'
  );
});

test('formatDocumentForGoogleKeep builds structured note with checked/unchecked items', () => {
  const analysis: DocumentAnalysis = {
    documentOverview: 'Renewal required by December 20, 2026.',
    detectedLanguage: 'English',
    readingLevel: 'simple',
    summary: 'Bring ID and utility bill.',
    keyPoints: [],
    importantInstructions: [],
    keyRequirements: [],
    importantWarnings: [],
    responsibilities: [],
    requiredDocuments: [],
    relevantConditions: [],
    comparisonSegments: [],
    deadlines: [
      {
        id: 'd1',
        originalText: 'December 20, 2026',
        normalizedDate: '2026-12-20',
        dateType: 'renewal_date',
        label: 'Card Renewal',
        sourceExcerpt: 'by December 20, 2026',
        pageNumber: 1,
        confidence: 'high',
        needsVerification: false,
        verificationReason: null,
      },
    ],
    contactInformation: [],
    actionChecklist: [
      {
        id: 't1',
        title: 'Bring utility bill',
        explanation: 'Needed as proof of local address.',
        sourceExcerpt: 'recent utility bill',
        pageNumber: 1,
        dueDate: '2026-12-20',
        priority: 'high',
        requiredDocuments: [],
      },
    ],
    uncertainties: ['Exact branch hours not listed.'],
    missingInformation: [],
  };

  const payload = formatDocumentForGoogleKeep('library.txt', analysis, new Set(['t1']));
  assert.equal(payload.title, 'ACCESSMATE: library.txt');
  assert.ok(payload.body.includes('[x] Bring utility bill (Due: 2026-12-20)'));
  assert.ok(payload.body.includes('Card Renewal: December 20, 2026 (2026-12-20)'));
  assert.ok(payload.body.includes('Exact branch hours not listed.'));
});
